<script lang="ts">
    import { Collapse, Nav, Navbar, NavbarBrand, NavbarToggler, NavItem, NavLink } from "sveltestrap";

    let isOpen = false;

    function handleUpdate(event) {
        isOpen = event.detail.isOpen;
    }

    export let tabs: Array<string>;

    export let activeTab;
    function tabClick(t: string) {
        activeTab = t;
    }
</script>

<Navbar color="primary" dark expand="md">
    <NavbarBrand on:click={() => alert("hej")}>Library Demo</NavbarBrand>
    <NavbarToggler on:click={() => (isOpen = !isOpen)} />
    <Collapse {isOpen} navbar expand="md" on:update={handleUpdate}>
        <Nav class="ms-auto" navbar>
            {#each tabs as tab}
                <NavItem>
                    <NavLink on:click={() => tabClick(tab)}>{tab}</NavLink>
                </NavItem>
            {/each}
        </Nav>
    </Collapse>
</Navbar>

<style>
</style>
