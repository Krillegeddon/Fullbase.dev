export class JMaxModalController {
    title: string;

    id: string;
    heading: string;
    isOpen: boolean = false;
    domObject = null;

    top: number;
    left: number;
    height: number;
    width: number;

    constructor(id: string, title: string) {
        this.id = id;
        this.title = title;
    }

    OpenModal() {
        console.log("JMaxModalController.OpenModal");

        if (localStorage.getItem("Mod_" + this.id + "_width")) {
            this.width = parseInt(localStorage.getItem("Mod_" + this.id + "_width"));
            this.height = parseInt(localStorage.getItem("Mod_" + this.id + "_height"));
            this.left = parseInt(localStorage.getItem("Mod_" + this.id + "_top"));
            this.top = parseInt(localStorage.getItem("Mod_" + this.id + "_left"));
            console.log("From localstorage");
            console.log("width: " + this.width);
            console.log("height: " + this.height);
            console.log("left: " + this.left);
            console.log("top: " + this.top);
        } else {
            if (!this.width) {
                this.width = 100;
                this.height = 100;
                this.left = 50;
                this.top = 50;
            }
        }
        this.domObject.style.display = "block";
        this.isOpen = true;

        // If position of modal is above top, then make it at the top.
        if (this.top < 0) this.top = 0;

        // If position of modal makes edges go outside of window, then put it in top left corner...
        if (this.left + this.width > this.domObject.offsetWidth - 20) {
            this.left = 10;
        }
        if (this.top + this.top > this.domObject.offsetHeight - 20) {
            this.top = 10;
        }

        // If size of modal is larger than screen - then maximize it.
        if (this.width > this.domObject.offsetWidth) {
            this.width = this.domObject.offsetWidth - 20;
            this.left = 10;
        }
        if (this.height > this.domObject.offsetHeight) {
            this.height = this.domObject.offsetHeight - 20;
            this.top = 10;
        }

        this.domObject.children[0].style = "left:" + this.left + "px;top:" + this.top + "px;height:" + this.height + "px; width:" +
            this.width + "px;position:fixed;border: 1px solid #888;padding:0px;"
        console.log("JMaxModalController.OpenModal.DONE");
    }

    CloseModal() {
        this.isOpen = false;
        this.domObject.style.display = "none";
    }

    SetSize(width: number, height: number) {
        console.log(this.id + ", width: " + width + ", height: " + height);
        this.width = width;
        this.height = height;
        localStorage.setItem("Mod_" + this.id + "_width", this.width.toString());
        localStorage.setItem("Mod_" + this.id + "_height", this.height.toString());
    }

    SetPosition(left: number, top: number) {
        console.log(this.id + ", left: " + left + ", top: " + top);
        this.left = left;
        this.top = top;
        localStorage.setItem("Mod_" + this.id + "_top", this.left.toString());
        localStorage.setItem("Mod_" + this.id + "_left", this.top.toString());
    }

}