<script lang="ts">
	export let value: Date;
	export let css: string;

	let datePartLocal: string;
	let timePartLocal: string;
	let outputValue: string;
	let valueAsString: string;

	console.log("DateTime: " + value);

	function PadZeroes(i: number): string {
		if (i < 10) return "0" + i.toString();
		else return i.toString();
	}

	$: valueAsString = value
		? value.getFullYear() +
		  "-" +
		  PadZeroes(value.getMonth() + 1) +
		  "-" +
		  PadZeroes(value.getDate()) +
		  "T" +
		  PadZeroes(value.getHours()) +
		  ":" +
		  PadZeroes(value.getMinutes()) +
		  ":" +
		  PadZeroes(value.getSeconds())
		: "T";
	$: datePartLocal = valueAsString ? valueAsString.split("T")[0] : "";
	$: timePartLocal = valueAsString ? valueAsString.split("T")[1] : "";
	$: outputValue = datePartLocal + "X" + timePartLocal;
	function copy() {
		value = new Date(datePartLocal + " " + timePartLocal);
	}
</script>

<table>
	<tr>
		<td style="width:50px;">
			<input type="date" class={css} bind:value={datePartLocal} on:blur={copy} />
		</td>
		<td> &nbsp; </td>
		<td>
			<input type="time" class={css} bind:value={timePartLocal} on:blur={copy} />
		</td>
	</tr>
</table>
