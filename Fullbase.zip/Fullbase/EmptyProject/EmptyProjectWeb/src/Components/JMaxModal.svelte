<script lang="ts">
    import { JMaxModalController } from "./JMaxModalConroller";

    export let title: string;
    export let id: string;
    export let controller: JMaxModalController = new JMaxModalController(id, title);

    import { Container, Row, Col } from "sveltestrap";

    // Get the <span> element that closes the modal
    var span;

    // When the user clicks on <span> (x), close the modal
    function spnCloseClick() {
        controller.CloseModal();
    }

    const handleKeydown = (event) => {
        if (event.key === "Escape") {
            event.preventDefault();
            controller.CloseModal();
        }
    };

    let m = { x: 0, y: 0 };
    let clicked = { x: 0, y: 0 };
    let moveX,
        moveY: number = 0;
    let isMoving: boolean = false;
    let isResizing: boolean = false;
    let newLeft, newTop, newWidth, newHeight: number;
    let leftStart, topStart, widthStart, heightStart: number;
    let table;
    let trMover, trResizer;

    function handleMouseMove_Move(event) {
        if (!isMoving) return;

        let x0: number = clicked.x;
        let y0: number = clicked.y;
        let xNow: number = event.clientX;
        let yNow: number = event.clientY;

        moveX = xNow - x0;
        moveY = yNow - y0;
        newLeft = leftStart * 1 + moveX * 1;
        newTop = topStart * 1 + moveY * 1;

        table.style.left = newLeft + "px";
        table.style.top = newTop + "px";
    }

    function handleMouseDown_Move(event) {
        isMoving = true;
        clicked.x = event.clientX;
        clicked.y = event.clientY;

        table = trMover.parentNode;
        leftStart = table.style.left.replace("px", "") * 1;
        topStart = table.style.top.replace("px", "") * 1;
    }

    function handleMouseUp_Move(event) {
        if (isMoving) {
            isMoving = false;
            controller.SetPosition(newLeft, newTop);
        }
    }

    function handleMouseMove_Resize(event) {
        if (!isResizing) return;

        let x0: number = clicked.x;
        let y0: number = clicked.y;
        let xNow: number = event.clientX;
        let yNow: number = event.clientY;

        moveX = xNow - x0;
        moveY = yNow - y0;
        newWidth = widthStart * 1 + moveX * 1;
        newHeight = heightStart * 1 + moveY * 1;

        table.style.width = newWidth + "px";
        table.style.height = newHeight + "px";
    }

    function handleMouseDown_Resize(event) {
        isResizing = true;
        clicked.x = event.clientX;
        clicked.y = event.clientY;

        table = trMover.parentNode;
        widthStart = table.offsetWidth;
        heightStart = table.offsetHeight;
    }

    function handleMouseUp_Resize(event) {
        if (!isResizing) return;
        isResizing = false;
        controller.SetSize(newWidth, newHeight);
    }

    function handleMouseMove(event) {
        if (isMoving) handleMouseMove_Move(event);
        if (isResizing) handleMouseMove_Resize(event);
    }

    function handleMouseUp_Window(event) {
        handleMouseUp_Move(event);
        handleMouseUp_Resize(event);
    }
</script>

<svelte:window on:keydown={handleKeydown} on:mousemove={handleMouseMove} on:mouseup={handleMouseUp_Window} />

<!-- The Modal -->
<div id={controller.id} class="modal" bind:this={controller.domObject}>
    <!-- Modal content, styles are set by controller -->
    <table class="bg-secondary" style="opacity:1;">
        <tr style="height:20px;cursor:pointer;user-select:none;" bind:this={trMover} class="bg-primary btn-primary">
            <td style="align:right;padding-top:0px;padding-left:10px;" on:mousedown={handleMouseDown_Move}>
                {title}
            </td>
            <td style="vertical-align:top;">
                <span bind:this={span} on:click={spnCloseClick} style="cursor:pointer;float:right;padding-right:5px;">X</span>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="vertical-align:top;">
                <slot />
            </td>
        </tr>
        <tr style="height:10px;user-select:none;" bind:this={trResizer}>
            <td style="text-align:right;vertical-align:top;" colspan="2">
                <span style="height:10px;cursor:pointer;user-select:none;" on:mousedown={handleMouseDown_Resize}
                    >&nbsp;&nbsp;/&nbsp;&nbsp;</span
                >
            </td>
        </tr>
    </table>
</div>

<style>
    .modal {
        opacity: 1;
        display: none; /* Hidden by default */
        position: fixed; /* Stay in place */
        z-index: 100; /* Sit on top */
        left: 0;
        top: 0;
        width: 100%; /* Full width */
        height: 100%; /* Full height */
        overflow: auto; /* Enable scroll if needed */
    }
</style>
