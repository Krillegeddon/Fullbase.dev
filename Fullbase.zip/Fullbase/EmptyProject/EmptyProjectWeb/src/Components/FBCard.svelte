<script lang="ts">
    import {
        Col,
        Container,
        Row,
        Form,
        FormGroup,
        FormText,
        Input,
        Label,
        Button,
        Icon,
        Table,
        Spinner,
        Card,
        CardHeader,
        CardTitle,
        CardBody,
        Modal,
        ModalHeader,
        ModalBody,
        ModalFooter,
    } from "sveltestrap";
</script>

<Card class="m-1 p-0 mt-2">
    <CardHeader>
        <CardTitle class="m-0 p-0">
            <slot name="title" />
        </CardTitle>
    </CardHeader>
    <CardBody class="m-2 p-0 mt-2">
        <slot name="body" />
    </CardBody>
</Card>
