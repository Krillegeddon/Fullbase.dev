<script lang="ts">
    import type { NumberClause } from "../WebApi";

    export let name: string = "";
    export let value: NumberClause;
</script>

{name}: <input type="number" bind:value={value.exactMatch} />

<style>
</style>
