<script lang="ts">
    import type { IntClause } from "../WebApi";

    export let name: string = "";
    export let value: IntClause;
</script>

{name}: <input type="number" bind:value={value.exactMatch} />

<style>
</style>
