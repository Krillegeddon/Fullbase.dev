<script lang="ts">
    import { onMount } from "svelte";
    import type { loop_guard } from "svelte/internal";

    export let css: any;
    export let objects: Array<any>;
    export let value: any;
    export let isReadOnly: boolean;
    let sel: any;

    $: value && valueChangedOutside();
    async function valueChangedOutside() {
        setSelectedValue();
    }

    async function setSelectedValue() {
        if (!sel) return;
        for (var i = 0; i < objects.length; i++) {
            if (value.myKey === objects[i].myKey) {
                sel.selectedIndex = i;
                objects[i] = value;
                return;
            } else {
            }
        }
    }

    async function startup() {
        console.log("FBselect.startup()");
        if (!value) {
            value = objects[0];
        }
        setSelectedValue();
    }

    onMount(async () => {
        startup();
    });

    //startup();

    function onChange() {
        value = objects[sel.selectedIndex];
    }
    let selectedIndex;
</script>

<!-- svelte-ignore a11y-no-onchange -->
<select bind:this={sel} on:change={onChange} class={css} disabled={isReadOnly}>
    {#each objects as object}
        <slot {object} />
    {/each}
</select>
