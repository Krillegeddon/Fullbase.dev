<script lang="ts">
    import type { StringClause } from "../WebApi";

    export let name: string = "";
    export let value: StringClause;
</script>

{name}: <input type="text" bind:value={value.exactMatch} />

<style>
</style>
