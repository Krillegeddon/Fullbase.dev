<script lang="ts">
    import { onMount } from "svelte";
    import { Table } from "sveltestrap";
    import { fetchers, AuthorLookupSearchRequest, AuthorLookupSearchResponse, AuthorVm } from "../WebApi";

    let value = "";
    export let selectedObject: any;

    onMount(async () => {
        if (selectedObject == null) {
            value = "";
            return;
        }
        value = selectedObject.firstName + " " + selectedObject.lastName;
    });

    var searchResult: AuthorLookupSearchResponse = null;

    async function onKeydown() {
        if (value.length < 2) {
            searchResult = null;
            myPopup.style.display = "none";
            return;
        }
        myPopup.style.display = "";
        var req = new AuthorLookupSearchRequest();
        req.quickSearch = value;
        searchResult = await fetchers.GetAuthorLookupSearch(req);
    }

    var cumulativeOffset = function (element) {
        var top = 0,
            left = 0;
        do {
            top += element.offsetTop || 0;
            left += element.offsetLeft || 0;
            element = element.offsetParent;
        } while (element);

        return {
            top: top,
            left: left,
        };
    };

    let myInput: any;
    let myPopup: any;
    let isShown = false;
    function onFocus() {
        isShown = true;
        var rect = myInput.getBoundingClientRect();
        var pos = cumulativeOffset(myInput);
        console.log(window.scrollY);
        console.log(myInput.style.left);

        if (value.length >= 2) myPopup.style.display = "";

        var x = myInput.offsetLeft;
        var y = myInput.offsetTop * 1 + rect.height * 1;
        var width = rect.width;
        console.log("X: " + x + ", Y: " + y);
        myPopup.style.left = x + "px";
        myPopup.style.top = y + "px";
        myPopup.style.minWidth = width + "px";
        myPopup.style.minHeight = "200" + "px";
    }

    function hide() {
        myPopup.style.display = "none";
    }

    function onBlur() {
        isShown = false;
        setTimeout(hide, 300);
    }

    $: selectedObject && redraw();
    function redraw() {
        value = selectedObject.firstName + " " + selectedObject.lastName;
    }

    function onSelect(o: AuthorVm) {
        selectedObject = o;
        value = selectedObject.firstName + " " + selectedObject.lastName;
    }
</script>

<input
    id="myid"
    type="text"
    bind:value
    on:keyup={onKeydown}
    on:focus={onFocus}
    on:blur={onBlur}
    autocomplete="false"
    bind:this={myInput}
    class="form-control"
/>

<div
    bind:this={myPopup}
    class="popover fade bs-popover-bottom show"
    role="tooltip"
    x-placement="bottom"
    data-popper-placement="bottom"
    style="position: absolute; inset: 0px auto auto 0px; margin: 0px; display:none;"
>
    <div>
        {#if searchResult}
            <Table hover>
                <tbody>
                    {#each searchResult.authors as row}
                        <tr on:click={() => onSelect(row)} style="cursor:pointer">
                            <td>{row.firstName} {row.lastName}</td>
                        </tr>
                    {/each}
                </tbody>
            </Table>
        {/if}
    </div>
</div>
