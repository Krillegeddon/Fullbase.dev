<script lang="ts">
    import {
        Col,
        Container,
        Row,
        Form,
        FormGroup,
        FormText,
        Input,
        Label,
        Button,
        Icon,
        Table,
        Spinner,
        Card,
        CardHeader,
        CardTitle,
        CardBody,
        Modal,
        ModalHeader,
        ModalBody,
        ModalFooter,
    } from "sveltestrap";
</script>

<Col>
    <FormGroup>
        <Label>
            <slot name="title" />
        </Label>
        <slot name="form" />
    </FormGroup>
</Col>
