import { UserAuthentication } from "./UserAuthentication";

export class TransferBase {
    isSuccess: boolean;
    errorMessage: string;
    stackTrace: string;

    // Properties for normalization/denormalization
    normalizer: Normalizer;
    userAuthentication: UserAuthentication
}


export class DtoBase {
    isDeleted: boolean;
    isTainted: boolean;
    myKey: string;
}

export class IntClause {
        exactMatch?: number;
        moreThan?: number;
        lessThan?: number;
        //anyOf: Array<number>;
}

export class DateTimeClause {
        exactMatch?: Date;
        moreThan?: Date;
        lessThan?: Date;
        //anyOf: Array<number>;
}


export class StringClause {
        exactMatch?: string;
        containsMatch?: string;
        startsWithMatch?: string;
        //anyOf: Array<string>;
}

export class BoolClause {
        exactMatch?: boolean;
}

export class KeyValuePair {
    key: string;
    value: any;
}

// Assumes that server sends datetime on UTC format
function GetLocalFromUtc(dateinX) {
    var datein = dateinX.toString().replace("Z", ""); // Sometimes, newtonsoft adds a Z at the end and sometimes not...
    var dateRaw = new Date(datein);
    dateRaw = new Date(Date.UTC(
        dateRaw.getFullYear(),
        dateRaw.getMonth(),
        dateRaw.getDate(),
        dateRaw.getHours(),
        dateRaw.getMinutes(),
        dateRaw.getSeconds(),
    ));
    return dateRaw;
}


export class Dictionary {
    kvps: Array<KeyValuePair>;

    containsKey(key: string): boolean {
        if (!this.kvps)
            this.kvps = new Array<KeyValuePair>();

        for (var i = 0; i < this.kvps.length; i++) {
            if (this.kvps[i].key == key) {
                return true;
            }
        }
        return false;
    }

    add(key: string, value: any) {
        if (!this.kvps)
            this.kvps = new Array<KeyValuePair>();

        for (var i = 0; i < this.kvps.length; i++) {
            if (this.kvps[i].key == key) {
                this.kvps[i].value = value;
            }
        }
        var kvp = new KeyValuePair();
        kvp.key = key;
        kvp.value = value;
        this.kvps.push(kvp);
    }

    get(key: string): any {
        if (!this.kvps)
            this.kvps = new Array<KeyValuePair>();

        for (var i = 0; i < this.kvps.length; i++) {
            if (this.kvps[i].key == key) {
                return this.kvps[i].value;
            }
        }
        return null;
    }
}








    export class NormKey {
        key: string;
        object: any;
        jansson: string;
        isDenormalized: boolean;
        isNormalized: boolean;
    }

    export class Normalizer {
        dtoObjects: Array<NormKey>;
        iscasted: boolean;

        constructor() {
            this.dtoObjects = new Array<NormKey>();
            this.iscasted = false;
        }

        CastDtoObjects(dtoObjects: Array<NormKey>) {
        if (this.iscasted)
            return;
        this.iscasted = true;
            for (var i = 0; i<dtoObjects.length ; i++) {
                //console.log(dtoObjects[i]);
                var v = dtoObjects[i];
            var ttemp = v.key;
            var sp = ttemp.split("_");
            var idx = "_" + sp[sp.length - 1];
            var t = ttemp.replace(idx, "");

                if (t == "Client")
                    v.object = JSON.parse(v.jansson) as ClientDto; // this.JsonAux_Deserialize_ClientDto(v.jansson);

                if (t == "Department")
                    v.object = JSON.parse(v.jansson) as DepartmentDto; // this.JsonAux_Deserialize_DepartmentDto(v.jansson);

                if (t == "Gender")
                    v.object = JSON.parse(v.jansson) as GenderDto; // this.JsonAux_Deserialize_GenderDto(v.jansson);

                if (t == "Person")
                    v.object = JSON.parse(v.jansson) as PersonDto; // this.JsonAux_Deserialize_PersonDto(v.jansson);

                if (t == "Project")
                    v.object = JSON.parse(v.jansson) as ProjectDto; // this.JsonAux_Deserialize_ProjectDto(v.jansson);

                if (t == "ProjectType")
                    v.object = JSON.parse(v.jansson) as ProjectTypeDto; // this.JsonAux_Deserialize_ProjectTypeDto(v.jansson);

                if (t == "Project_Client")
                    v.object = JSON.parse(v.jansson) as Project_ClientDto; // this.JsonAux_Deserialize_Project_ClientDto(v.jansson);

                if (t == "Project_Person_Role")
                    v.object = JSON.parse(v.jansson) as Project_Person_RoleDto; // this.JsonAux_Deserialize_Project_Person_RoleDto(v.jansson);

                if (t == "Role")
                    v.object = JSON.parse(v.jansson) as RoleDto; // this.JsonAux_Deserialize_RoleDto(v.jansson);

                if (t == "ViewProjectAug")
                    v.object = JSON.parse(v.jansson) as ViewProjectAugDto; // this.JsonAux_Deserialize_ViewProjectAugDto(v.jansson);

                if (t == "Author")
                    v.object = JSON.parse(v.jansson) as AuthorDto; // this.JsonAux_Deserialize_AuthorDto(v.jansson);

                if (t == "Book")
                    v.object = JSON.parse(v.jansson) as BookDto; // this.JsonAux_Deserialize_BookDto(v.jansson);

                if (t == "Country")
                    v.object = JSON.parse(v.jansson) as CountryDto; // this.JsonAux_Deserialize_CountryDto(v.jansson);

                if (t == "Genre")
                    v.object = JSON.parse(v.jansson) as GenreDto; // this.JsonAux_Deserialize_GenreDto(v.jansson);

                if (t == "Rating")
                    v.object = JSON.parse(v.jansson) as RatingDto; // this.JsonAux_Deserialize_RatingDto(v.jansson);

                v.jansson = null;
            }
        }

        /* ***   Normalizers.ts   *** */

        JsonAux_Deserialize_ClientDto(json: string) : ClientDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadClient(client: ClientDto) : ClientDto 
        {
            // Normalizer - Load - Header.cs
            if (client == null)
                return null;
            client.myKey = "Client_" + client.clientId;
            var retObj = new ClientDto();
            retObj.myKey = "Client_" + client.clientId;

            var obj = this.dtoObjects.find(p => p.key == client.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as ClientDto;
            }
            else {
                var nk = new NormKey();
                nk.key = client.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            retObj.project_Clients = new Array<Project_ClientDto>();
            for (var i = 0; i < client?.project_Clients?.length ; i++)
            {
                var xProject_ClientsItem = client.project_Clients[i];
                retObj.project_Clients.push(this.LoadProject_Client(xProject_ClientsItem));
            }

            // Normalizer - Load - Id field.cs

            retObj.clientId = client.clientId;

            // Normalizer - Load - Ref fields.cs

            retObj.personId = client.personId;
            retObj.keyAccountManager = this.LoadPerson(client.keyAccountManager);

            // Normalizer - Load - Data fields.cs

            retObj.clientName = client.clientName;

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeClient(client: ClientDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (client == null)
                return;
            client.myKey = "Client_" + client.clientId;

            var obj = normalizer.dtoObjects.find(p => p.key == client.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = client.myKey;
                nk.object = client;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            for (var i = 0; i < client?.project_Clients?.length ; i++)
            {
                var xProject_ClientsItem = client.project_Clients[i];
                this.NormalizeProject_Client(xProject_ClientsItem, this);
            }

            // Normalizer - Normalize - Ref fields.ts

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (client.keyAccountManager) {
                client.personId = client.keyAccountManager.personId;
            }

            var client_keyAccountManager = client.keyAccountManager;
            client.keyAccountManager = null;
            this.NormalizePerson(client_keyAccountManager, this);

        }

        // Normalizer - Denormalize.cs
        DenormalizeClient(client: ClientDto, dtoObjects: Array<NormKey>) : ClientDto
        {
            // Normalizer - Denormalize - Header.cs
            if (client == null)
                return null;
            client.myKey = "Client_" + client.clientId;

            var retObj: ClientDto = null;

            var obj = this.dtoObjects.find(p => p.key == client.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as ClientDto;
                retObj.myKey = "Client_" + client.clientId;

            }



            // Normalizer - Denormalize - Child tables.cs

            for (var i = 0; i< client?.project_Clients?.length; i++)
            {
                retObj.project_Clients[i] = this.DenormalizeProject_Client(client.project_Clients[i], dtoObjects);
            }

            // Normalizer - Denormalize - Ref fields.cs

            {
                var xKeyAccountManager: PersonDto = null;
                for (var iiKeyAccountManager = 0; iiKeyAccountManager < this.dtoObjects.length; iiKeyAccountManager++) {
                    if (this.dtoObjects[iiKeyAccountManager].key == "Person_" + client.personId) {
                        xKeyAccountManager = this.dtoObjects[iiKeyAccountManager].object;
                    }
                }

                retObj.keyAccountManager = this.DenormalizePerson(xKeyAccountManager, dtoObjects);
            }

            return retObj;
        }

        JsonAux_Deserialize_DepartmentDto(json: string) : DepartmentDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadDepartment(department: DepartmentDto) : DepartmentDto 
        {
            // Normalizer - Load - Header.cs
            if (department == null)
                return null;
            department.myKey = "Department_" + department.departmentId;
            var retObj = new DepartmentDto();
            retObj.myKey = "Department_" + department.departmentId;

            var obj = this.dtoObjects.find(p => p.key == department.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as DepartmentDto;
            }
            else {
                var nk = new NormKey();
                nk.key = department.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            retObj.persons = new Array<PersonDto>();
            for (var i = 0; i < department?.persons?.length ; i++)
            {
                var xPersonsItem = department.persons[i];
                retObj.persons.push(this.LoadPerson(xPersonsItem));
            }

            // Normalizer - Load - Id field.cs

            retObj.departmentId = department.departmentId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.departmentName = department.departmentName;

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeDepartment(department: DepartmentDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (department == null)
                return;
            department.myKey = "Department_" + department.departmentId;

            var obj = normalizer.dtoObjects.find(p => p.key == department.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = department.myKey;
                nk.object = department;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            for (var i = 0; i < department?.persons?.length ; i++)
            {
                var xPersonsItem = department.persons[i];
                this.NormalizePerson(xPersonsItem, this);
            }

            // Normalizer - Normalize - Ref fields.ts

        }

        // Normalizer - Denormalize.cs
        DenormalizeDepartment(department: DepartmentDto, dtoObjects: Array<NormKey>) : DepartmentDto
        {
            // Normalizer - Denormalize - Header.cs
            if (department == null)
                return null;
            department.myKey = "Department_" + department.departmentId;

            var retObj: DepartmentDto = null;

            var obj = this.dtoObjects.find(p => p.key == department.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as DepartmentDto;
                retObj.myKey = "Department_" + department.departmentId;

            }



            // Normalizer - Denormalize - Child tables.cs

            for (var i = 0; i< department?.persons?.length; i++)
            {
                retObj.persons[i] = this.DenormalizePerson(department.persons[i], dtoObjects);
            }

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }

        JsonAux_Deserialize_GenderDto(json: string) : GenderDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadGender(gender: GenderDto) : GenderDto 
        {
            // Normalizer - Load - Header.cs
            if (gender == null)
                return null;
            gender.myKey = "Gender_" + gender.genderId;
            var retObj = new GenderDto();
            retObj.myKey = "Gender_" + gender.genderId;

            var obj = this.dtoObjects.find(p => p.key == gender.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as GenderDto;
            }
            else {
                var nk = new NormKey();
                nk.key = gender.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            retObj.persons = new Array<PersonDto>();
            for (var i = 0; i < gender?.persons?.length ; i++)
            {
                var xPersonsItem = gender.persons[i];
                retObj.persons.push(this.LoadPerson(xPersonsItem));
            }

            // Normalizer - Load - Id field.cs

            retObj.genderId = gender.genderId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.genderDescription = gender.genderDescription;

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeGender(gender: GenderDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (gender == null)
                return;
            gender.myKey = "Gender_" + gender.genderId;

            var obj = normalizer.dtoObjects.find(p => p.key == gender.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = gender.myKey;
                nk.object = gender;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            for (var i = 0; i < gender?.persons?.length ; i++)
            {
                var xPersonsItem = gender.persons[i];
                this.NormalizePerson(xPersonsItem, this);
            }

            // Normalizer - Normalize - Ref fields.ts

        }

        // Normalizer - Denormalize.cs
        DenormalizeGender(gender: GenderDto, dtoObjects: Array<NormKey>) : GenderDto
        {
            // Normalizer - Denormalize - Header.cs
            if (gender == null)
                return null;
            gender.myKey = "Gender_" + gender.genderId;

            var retObj: GenderDto = null;

            var obj = this.dtoObjects.find(p => p.key == gender.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as GenderDto;
                retObj.myKey = "Gender_" + gender.genderId;

            }



            // Normalizer - Denormalize - Child tables.cs

            for (var i = 0; i< gender?.persons?.length; i++)
            {
                retObj.persons[i] = this.DenormalizePerson(gender.persons[i], dtoObjects);
            }

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }

        JsonAux_Deserialize_PersonDto(json: string) : PersonDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadPerson(person: PersonDto) : PersonDto 
        {
            // Normalizer - Load - Header.cs
            if (person == null)
                return null;
            person.myKey = "Person_" + person.personId;
            var retObj = new PersonDto();
            retObj.myKey = "Person_" + person.personId;

            var obj = this.dtoObjects.find(p => p.key == person.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as PersonDto;
            }
            else {
                var nk = new NormKey();
                nk.key = person.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            retObj.clients = new Array<ClientDto>();
            for (var i = 0; i < person?.clients?.length ; i++)
            {
                var xClientsItem = person.clients[i];
                retObj.clients.push(this.LoadClient(xClientsItem));
            }

            retObj.employees = new Array<PersonDto>();
            for (var i = 0; i < person?.employees?.length ; i++)
            {
                var xEmployeesItem = person.employees[i];
                retObj.employees.push(this.LoadPerson(xEmployeesItem));
            }

            retObj.project_Person_Roles = new Array<Project_Person_RoleDto>();
            for (var i = 0; i < person?.project_Person_Roles?.length ; i++)
            {
                var xProject_Person_RolesItem = person.project_Person_Roles[i];
                retObj.project_Person_Roles.push(this.LoadProject_Person_Role(xProject_Person_RolesItem));
            }

            // Normalizer - Load - Id field.cs

            retObj.personId = person.personId;

            // Normalizer - Load - Ref fields.cs

            retObj.departmentId = person.departmentId;
            retObj.department = this.LoadDepartment(person.department);

            retObj.genderId = person.genderId;
            retObj.gender = this.LoadGender(person.gender);

            retObj.managerId = person.managerId;
            retObj.manager = this.LoadPerson(person.manager);

            // Normalizer - Load - Data fields.cs

            retObj.userName = person.userName;

            retObj.salary = person.salary;

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizePerson(person: PersonDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (person == null)
                return;
            person.myKey = "Person_" + person.personId;

            var obj = normalizer.dtoObjects.find(p => p.key == person.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = person.myKey;
                nk.object = person;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            for (var i = 0; i < person?.clients?.length ; i++)
            {
                var xClientsItem = person.clients[i];
                this.NormalizeClient(xClientsItem, this);
            }

            for (var i = 0; i < person?.employees?.length ; i++)
            {
                var xEmployeesItem = person.employees[i];
                this.NormalizePerson(xEmployeesItem, this);
            }

            for (var i = 0; i < person?.project_Person_Roles?.length ; i++)
            {
                var xProject_Person_RolesItem = person.project_Person_Roles[i];
                this.NormalizeProject_Person_Role(xProject_Person_RolesItem, this);
            }

            // Normalizer - Normalize - Ref fields.ts

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (person.department) {
                person.departmentId = person.department.departmentId;
            }

            var person_department = person.department;
            person.department = null;
            this.NormalizeDepartment(person_department, this);

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (person.gender) {
                person.genderId = person.gender.genderId;
            }

            var person_gender = person.gender;
            person.gender = null;
            this.NormalizeGender(person_gender, this);

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (person.manager) {
                person.managerId = person.manager.personId;
            }

            var person_manager = person.manager;
            person.manager = null;
            this.NormalizePerson(person_manager, this);

        }

        // Normalizer - Denormalize.cs
        DenormalizePerson(person: PersonDto, dtoObjects: Array<NormKey>) : PersonDto
        {
            // Normalizer - Denormalize - Header.cs
            if (person == null)
                return null;
            person.myKey = "Person_" + person.personId;

            var retObj: PersonDto = null;

            var obj = this.dtoObjects.find(p => p.key == person.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as PersonDto;
                retObj.myKey = "Person_" + person.personId;

            }



            // Normalizer - Denormalize - Child tables.cs

            for (var i = 0; i< person?.clients?.length; i++)
            {
                retObj.clients[i] = this.DenormalizeClient(person.clients[i], dtoObjects);
            }

            for (var i = 0; i< person?.employees?.length; i++)
            {
                retObj.employees[i] = this.DenormalizePerson(person.employees[i], dtoObjects);
            }

            for (var i = 0; i< person?.project_Person_Roles?.length; i++)
            {
                retObj.project_Person_Roles[i] = this.DenormalizeProject_Person_Role(person.project_Person_Roles[i], dtoObjects);
            }

            // Normalizer - Denormalize - Ref fields.cs

            {
                var xDepartment: DepartmentDto = null;
                for (var iiDepartment = 0; iiDepartment < this.dtoObjects.length; iiDepartment++) {
                    if (this.dtoObjects[iiDepartment].key == "Department_" + person.departmentId) {
                        xDepartment = this.dtoObjects[iiDepartment].object;
                    }
                }

                retObj.department = this.DenormalizeDepartment(xDepartment, dtoObjects);
            }

            {
                var xGender: GenderDto = null;
                for (var iiGender = 0; iiGender < this.dtoObjects.length; iiGender++) {
                    if (this.dtoObjects[iiGender].key == "Gender_" + person.genderId) {
                        xGender = this.dtoObjects[iiGender].object;
                    }
                }

                retObj.gender = this.DenormalizeGender(xGender, dtoObjects);
            }

            {
                var xManager: PersonDto = null;
                for (var iiManager = 0; iiManager < this.dtoObjects.length; iiManager++) {
                    if (this.dtoObjects[iiManager].key == "Person_" + person.managerId) {
                        xManager = this.dtoObjects[iiManager].object;
                    }
                }

                retObj.manager = this.DenormalizePerson(xManager, dtoObjects);
            }

            return retObj;
        }

        JsonAux_Deserialize_ProjectDto(json: string) : ProjectDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadProject(project: ProjectDto) : ProjectDto 
        {
            // Normalizer - Load - Header.cs
            if (project == null)
                return null;
            project.myKey = "Project_" + project.projectId;
            var retObj = new ProjectDto();
            retObj.myKey = "Project_" + project.projectId;

            var obj = this.dtoObjects.find(p => p.key == project.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as ProjectDto;
            }
            else {
                var nk = new NormKey();
                nk.key = project.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            retObj.project_Clients = new Array<Project_ClientDto>();
            for (var i = 0; i < project?.project_Clients?.length ; i++)
            {
                var xProject_ClientsItem = project.project_Clients[i];
                retObj.project_Clients.push(this.LoadProject_Client(xProject_ClientsItem));
            }

            retObj.project_Person_Roles = new Array<Project_Person_RoleDto>();
            for (var i = 0; i < project?.project_Person_Roles?.length ; i++)
            {
                var xProject_Person_RolesItem = project.project_Person_Roles[i];
                retObj.project_Person_Roles.push(this.LoadProject_Person_Role(xProject_Person_RolesItem));
            }

            // Normalizer - Load - Id field.cs

            retObj.projectId = project.projectId;

            // Normalizer - Load - Ref fields.cs

            retObj.projectTypeId = project.projectTypeId;
            retObj.projectType = this.LoadProjectType(project.projectType);

            retObj.viewProjectAug = this.LoadViewProjectAug(project.viewProjectAug);

            // Normalizer - Load - Data fields.cs

            retObj.projectName = project.projectName;

            retObj.isProBono = project.isProBono;

            retObj.deadline = project.deadline;

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeProject(project: ProjectDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (project == null)
                return;
            project.myKey = "Project_" + project.projectId;

            var obj = normalizer.dtoObjects.find(p => p.key == project.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = project.myKey;
                nk.object = project;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            for (var i = 0; i < project?.project_Clients?.length ; i++)
            {
                var xProject_ClientsItem = project.project_Clients[i];
                this.NormalizeProject_Client(xProject_ClientsItem, this);
            }

            for (var i = 0; i < project?.project_Person_Roles?.length ; i++)
            {
                var xProject_Person_RolesItem = project.project_Person_Roles[i];
                this.NormalizeProject_Person_Role(xProject_Person_RolesItem, this);
            }

            // Normalizer - Normalize - Ref fields.ts

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (project.projectType) {
                project.projectTypeId = project.projectType.projectTypeId;
            }

            var project_projectType = project.projectType;
            project.projectType = null;
            this.NormalizeProjectType(project_projectType, this);

        }

        // Normalizer - Denormalize.cs
        DenormalizeProject(project: ProjectDto, dtoObjects: Array<NormKey>) : ProjectDto
        {
            // Normalizer - Denormalize - Header.cs
            if (project == null)
                return null;
            project.myKey = "Project_" + project.projectId;

            var retObj: ProjectDto = null;

            var obj = this.dtoObjects.find(p => p.key == project.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as ProjectDto;
                retObj.myKey = "Project_" + project.projectId;
            retObj.deadline = GetLocalFromUtc(retObj.deadline); // Assume server sends UTC.

            }



            // Normalizer - Denormalize - Child tables.cs

            for (var i = 0; i< project?.project_Clients?.length; i++)
            {
                retObj.project_Clients[i] = this.DenormalizeProject_Client(project.project_Clients[i], dtoObjects);
            }

            for (var i = 0; i< project?.project_Person_Roles?.length; i++)
            {
                retObj.project_Person_Roles[i] = this.DenormalizeProject_Person_Role(project.project_Person_Roles[i], dtoObjects);
            }

            // Normalizer - Denormalize - Ref fields.cs

            {
                var xProjectType: ProjectTypeDto = null;
                for (var iiProjectType = 0; iiProjectType < this.dtoObjects.length; iiProjectType++) {
                    if (this.dtoObjects[iiProjectType].key == "ProjectType_" + project.projectTypeId) {
                        xProjectType = this.dtoObjects[iiProjectType].object;
                    }
                }

                retObj.projectType = this.DenormalizeProjectType(xProjectType, dtoObjects);
            }

            return retObj;
        }

        JsonAux_Deserialize_ProjectTypeDto(json: string) : ProjectTypeDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadProjectType(projectType: ProjectTypeDto) : ProjectTypeDto 
        {
            // Normalizer - Load - Header.cs
            if (projectType == null)
                return null;
            projectType.myKey = "ProjectType_" + projectType.projectTypeId;
            var retObj = new ProjectTypeDto();
            retObj.myKey = "ProjectType_" + projectType.projectTypeId;

            var obj = this.dtoObjects.find(p => p.key == projectType.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as ProjectTypeDto;
            }
            else {
                var nk = new NormKey();
                nk.key = projectType.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            retObj.projects = new Array<ProjectDto>();
            for (var i = 0; i < projectType?.projects?.length ; i++)
            {
                var xProjectsItem = projectType.projects[i];
                retObj.projects.push(this.LoadProject(xProjectsItem));
            }

            // Normalizer - Load - Id field.cs

            retObj.projectTypeId = projectType.projectTypeId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.projectTypeName = projectType.projectTypeName;

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeProjectType(projectType: ProjectTypeDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (projectType == null)
                return;
            projectType.myKey = "ProjectType_" + projectType.projectTypeId;

            var obj = normalizer.dtoObjects.find(p => p.key == projectType.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = projectType.myKey;
                nk.object = projectType;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            for (var i = 0; i < projectType?.projects?.length ; i++)
            {
                var xProjectsItem = projectType.projects[i];
                this.NormalizeProject(xProjectsItem, this);
            }

            // Normalizer - Normalize - Ref fields.ts

        }

        // Normalizer - Denormalize.cs
        DenormalizeProjectType(projectType: ProjectTypeDto, dtoObjects: Array<NormKey>) : ProjectTypeDto
        {
            // Normalizer - Denormalize - Header.cs
            if (projectType == null)
                return null;
            projectType.myKey = "ProjectType_" + projectType.projectTypeId;

            var retObj: ProjectTypeDto = null;

            var obj = this.dtoObjects.find(p => p.key == projectType.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as ProjectTypeDto;
                retObj.myKey = "ProjectType_" + projectType.projectTypeId;

            }



            // Normalizer - Denormalize - Child tables.cs

            for (var i = 0; i< projectType?.projects?.length; i++)
            {
                retObj.projects[i] = this.DenormalizeProject(projectType.projects[i], dtoObjects);
            }

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }

        JsonAux_Deserialize_Project_ClientDto(json: string) : Project_ClientDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadProject_Client(project_Client: Project_ClientDto) : Project_ClientDto 
        {
            // Normalizer - Load - Header.cs
            if (project_Client == null)
                return null;
            project_Client.myKey = "Project_Client_" + project_Client.project_ClientId;
            var retObj = new Project_ClientDto();
            retObj.myKey = "Project_Client_" + project_Client.project_ClientId;

            var obj = this.dtoObjects.find(p => p.key == project_Client.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as Project_ClientDto;
            }
            else {
                var nk = new NormKey();
                nk.key = project_Client.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            // Normalizer - Load - Id field.cs

            retObj.project_ClientId = project_Client.project_ClientId;

            // Normalizer - Load - Ref fields.cs

            retObj.projectId = project_Client.projectId;
            retObj.project = this.LoadProject(project_Client.project);

            retObj.clientId = project_Client.clientId;
            retObj.client = this.LoadClient(project_Client.client);

            // Normalizer - Load - Data fields.cs

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeProject_Client(project_Client: Project_ClientDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (project_Client == null)
                return;
            project_Client.myKey = "Project_Client_" + project_Client.project_ClientId;

            var obj = normalizer.dtoObjects.find(p => p.key == project_Client.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = project_Client.myKey;
                nk.object = project_Client;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            // Normalizer - Normalize - Ref fields.ts

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (project_Client.project) {
                project_Client.projectId = project_Client.project.projectId;
            }

            var project_Client_project = project_Client.project;
            project_Client.project = null;
            this.NormalizeProject(project_Client_project, this);

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (project_Client.client) {
                project_Client.clientId = project_Client.client.clientId;
            }

            var project_Client_client = project_Client.client;
            project_Client.client = null;
            this.NormalizeClient(project_Client_client, this);

        }

        // Normalizer - Denormalize.cs
        DenormalizeProject_Client(project_Client: Project_ClientDto, dtoObjects: Array<NormKey>) : Project_ClientDto
        {
            // Normalizer - Denormalize - Header.cs
            if (project_Client == null)
                return null;
            project_Client.myKey = "Project_Client_" + project_Client.project_ClientId;

            var retObj: Project_ClientDto = null;

            var obj = this.dtoObjects.find(p => p.key == project_Client.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as Project_ClientDto;
                retObj.myKey = "Project_Client_" + project_Client.project_ClientId;

            }



            // Normalizer - Denormalize - Child tables.cs

            // Normalizer - Denormalize - Ref fields.cs

            {
                var xProject: ProjectDto = null;
                for (var iiProject = 0; iiProject < this.dtoObjects.length; iiProject++) {
                    if (this.dtoObjects[iiProject].key == "Project_" + project_Client.projectId) {
                        xProject = this.dtoObjects[iiProject].object;
                    }
                }

                retObj.project = this.DenormalizeProject(xProject, dtoObjects);
            }

            {
                var xClient: ClientDto = null;
                for (var iiClient = 0; iiClient < this.dtoObjects.length; iiClient++) {
                    if (this.dtoObjects[iiClient].key == "Client_" + project_Client.clientId) {
                        xClient = this.dtoObjects[iiClient].object;
                    }
                }

                retObj.client = this.DenormalizeClient(xClient, dtoObjects);
            }

            return retObj;
        }

        JsonAux_Deserialize_Project_Person_RoleDto(json: string) : Project_Person_RoleDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadProject_Person_Role(project_Person_Role: Project_Person_RoleDto) : Project_Person_RoleDto 
        {
            // Normalizer - Load - Header.cs
            if (project_Person_Role == null)
                return null;
            project_Person_Role.myKey = "Project_Person_Role_" + project_Person_Role.project_Person_RoleId;
            var retObj = new Project_Person_RoleDto();
            retObj.myKey = "Project_Person_Role_" + project_Person_Role.project_Person_RoleId;

            var obj = this.dtoObjects.find(p => p.key == project_Person_Role.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as Project_Person_RoleDto;
            }
            else {
                var nk = new NormKey();
                nk.key = project_Person_Role.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            // Normalizer - Load - Id field.cs

            retObj.project_Person_RoleId = project_Person_Role.project_Person_RoleId;

            // Normalizer - Load - Ref fields.cs

            retObj.personId = project_Person_Role.personId;
            retObj.person = this.LoadPerson(project_Person_Role.person);

            retObj.projectId = project_Person_Role.projectId;
            retObj.project = this.LoadProject(project_Person_Role.project);

            retObj.roleId = project_Person_Role.roleId;
            retObj.role = this.LoadRole(project_Person_Role.role);

            // Normalizer - Load - Data fields.cs

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeProject_Person_Role(project_Person_Role: Project_Person_RoleDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (project_Person_Role == null)
                return;
            project_Person_Role.myKey = "Project_Person_Role_" + project_Person_Role.project_Person_RoleId;

            var obj = normalizer.dtoObjects.find(p => p.key == project_Person_Role.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = project_Person_Role.myKey;
                nk.object = project_Person_Role;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            // Normalizer - Normalize - Ref fields.ts

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (project_Person_Role.person) {
                project_Person_Role.personId = project_Person_Role.person.personId;
            }

            var project_Person_Role_person = project_Person_Role.person;
            project_Person_Role.person = null;
            this.NormalizePerson(project_Person_Role_person, this);

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (project_Person_Role.project) {
                project_Person_Role.projectId = project_Person_Role.project.projectId;
            }

            var project_Person_Role_project = project_Person_Role.project;
            project_Person_Role.project = null;
            this.NormalizeProject(project_Person_Role_project, this);

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (project_Person_Role.role) {
                project_Person_Role.roleId = project_Person_Role.role.roleId;
            }

            var project_Person_Role_role = project_Person_Role.role;
            project_Person_Role.role = null;
            this.NormalizeRole(project_Person_Role_role, this);

        }

        // Normalizer - Denormalize.cs
        DenormalizeProject_Person_Role(project_Person_Role: Project_Person_RoleDto, dtoObjects: Array<NormKey>) : Project_Person_RoleDto
        {
            // Normalizer - Denormalize - Header.cs
            if (project_Person_Role == null)
                return null;
            project_Person_Role.myKey = "Project_Person_Role_" + project_Person_Role.project_Person_RoleId;

            var retObj: Project_Person_RoleDto = null;

            var obj = this.dtoObjects.find(p => p.key == project_Person_Role.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as Project_Person_RoleDto;
                retObj.myKey = "Project_Person_Role_" + project_Person_Role.project_Person_RoleId;

            }



            // Normalizer - Denormalize - Child tables.cs

            // Normalizer - Denormalize - Ref fields.cs

            {
                var xPerson: PersonDto = null;
                for (var iiPerson = 0; iiPerson < this.dtoObjects.length; iiPerson++) {
                    if (this.dtoObjects[iiPerson].key == "Person_" + project_Person_Role.personId) {
                        xPerson = this.dtoObjects[iiPerson].object;
                    }
                }

                retObj.person = this.DenormalizePerson(xPerson, dtoObjects);
            }

            {
                var xProject: ProjectDto = null;
                for (var iiProject = 0; iiProject < this.dtoObjects.length; iiProject++) {
                    if (this.dtoObjects[iiProject].key == "Project_" + project_Person_Role.projectId) {
                        xProject = this.dtoObjects[iiProject].object;
                    }
                }

                retObj.project = this.DenormalizeProject(xProject, dtoObjects);
            }

            {
                var xRole: RoleDto = null;
                for (var iiRole = 0; iiRole < this.dtoObjects.length; iiRole++) {
                    if (this.dtoObjects[iiRole].key == "Role_" + project_Person_Role.roleId) {
                        xRole = this.dtoObjects[iiRole].object;
                    }
                }

                retObj.role = this.DenormalizeRole(xRole, dtoObjects);
            }

            return retObj;
        }

        JsonAux_Deserialize_RoleDto(json: string) : RoleDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadRole(role: RoleDto) : RoleDto 
        {
            // Normalizer - Load - Header.cs
            if (role == null)
                return null;
            role.myKey = "Role_" + role.roleId;
            var retObj = new RoleDto();
            retObj.myKey = "Role_" + role.roleId;

            var obj = this.dtoObjects.find(p => p.key == role.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as RoleDto;
            }
            else {
                var nk = new NormKey();
                nk.key = role.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            retObj.project_Person_Roles = new Array<Project_Person_RoleDto>();
            for (var i = 0; i < role?.project_Person_Roles?.length ; i++)
            {
                var xProject_Person_RolesItem = role.project_Person_Roles[i];
                retObj.project_Person_Roles.push(this.LoadProject_Person_Role(xProject_Person_RolesItem));
            }

            // Normalizer - Load - Id field.cs

            retObj.roleId = role.roleId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.roleName = role.roleName;

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeRole(role: RoleDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (role == null)
                return;
            role.myKey = "Role_" + role.roleId;

            var obj = normalizer.dtoObjects.find(p => p.key == role.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = role.myKey;
                nk.object = role;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            for (var i = 0; i < role?.project_Person_Roles?.length ; i++)
            {
                var xProject_Person_RolesItem = role.project_Person_Roles[i];
                this.NormalizeProject_Person_Role(xProject_Person_RolesItem, this);
            }

            // Normalizer - Normalize - Ref fields.ts

        }

        // Normalizer - Denormalize.cs
        DenormalizeRole(role: RoleDto, dtoObjects: Array<NormKey>) : RoleDto
        {
            // Normalizer - Denormalize - Header.cs
            if (role == null)
                return null;
            role.myKey = "Role_" + role.roleId;

            var retObj: RoleDto = null;

            var obj = this.dtoObjects.find(p => p.key == role.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as RoleDto;
                retObj.myKey = "Role_" + role.roleId;

            }



            // Normalizer - Denormalize - Child tables.cs

            for (var i = 0; i< role?.project_Person_Roles?.length; i++)
            {
                retObj.project_Person_Roles[i] = this.DenormalizeProject_Person_Role(role.project_Person_Roles[i], dtoObjects);
            }

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }

        JsonAux_Deserialize_ViewProjectAugDto(json: string) : ViewProjectAugDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadViewProjectAug(viewProjectAug: ViewProjectAugDto) : ViewProjectAugDto 
        {
            // Normalizer - Load - Header.cs
            if (viewProjectAug == null)
                return null;
            viewProjectAug.myKey = "ViewProjectAug_" + viewProjectAug.projectId;
            var retObj = new ViewProjectAugDto();
            retObj.myKey = "ViewProjectAug_" + viewProjectAug.projectId;

            var obj = this.dtoObjects.find(p => p.key == viewProjectAug.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as ViewProjectAugDto;
            }
            else {
                var nk = new NormKey();
                nk.key = viewProjectAug.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            // Normalizer - Load - Id field.cs

            retObj.projectId = viewProjectAug.projectId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.tempNum = viewProjectAug.tempNum;

            retObj.quadruple = viewProjectAug.quadruple;

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeViewProjectAug(viewProjectAug: ViewProjectAugDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (viewProjectAug == null)
                return;
            viewProjectAug.myKey = "ViewProjectAug_" + viewProjectAug.projectId;

            var obj = normalizer.dtoObjects.find(p => p.key == viewProjectAug.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = viewProjectAug.myKey;
                nk.object = viewProjectAug;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            // Normalizer - Normalize - Ref fields.ts

        }

        // Normalizer - Denormalize.cs
        DenormalizeViewProjectAug(viewProjectAug: ViewProjectAugDto, dtoObjects: Array<NormKey>) : ViewProjectAugDto
        {
            // Normalizer - Denormalize - Header.cs
            if (viewProjectAug == null)
                return null;
            viewProjectAug.myKey = "ViewProjectAug_" + viewProjectAug.projectId;

            var retObj: ViewProjectAugDto = null;

            var obj = this.dtoObjects.find(p => p.key == viewProjectAug.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as ViewProjectAugDto;
                retObj.myKey = "ViewProjectAug_" + viewProjectAug.projectId;

            }



            // Normalizer - Denormalize - Child tables.cs

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }

        JsonAux_Deserialize_AuthorDto(json: string) : AuthorDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadAuthor(author: AuthorDto) : AuthorDto 
        {
            // Normalizer - Load - Header.cs
            if (author == null)
                return null;
            author.myKey = "Author_" + author.authorId;
            var retObj = new AuthorDto();
            retObj.myKey = "Author_" + author.authorId;

            var obj = this.dtoObjects.find(p => p.key == author.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as AuthorDto;
            }
            else {
                var nk = new NormKey();
                nk.key = author.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            retObj.books = new Array<BookDto>();
            for (var i = 0; i < author?.books?.length ; i++)
            {
                var xBooksItem = author.books[i];
                retObj.books.push(this.LoadBook(xBooksItem));
            }

            // Normalizer - Load - Id field.cs

            retObj.authorId = author.authorId;

            // Normalizer - Load - Ref fields.cs

            retObj.countryID = author.countryID;
            retObj.country = this.LoadCountry(author.country);

            // Normalizer - Load - Data fields.cs

            retObj.firstName = author.firstName;

            retObj.lastName = author.lastName;

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeAuthor(author: AuthorDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (author == null)
                return;
            author.myKey = "Author_" + author.authorId;

            var obj = normalizer.dtoObjects.find(p => p.key == author.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = author.myKey;
                nk.object = author;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            for (var i = 0; i < author?.books?.length ; i++)
            {
                var xBooksItem = author.books[i];
                this.NormalizeBook(xBooksItem, this);
            }

            // Normalizer - Normalize - Ref fields.ts

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (author.country) {
                author.countryID = author.country.countryId;
            }

            var author_country = author.country;
            author.country = null;
            this.NormalizeCountry(author_country, this);

        }

        // Normalizer - Denormalize.cs
        DenormalizeAuthor(author: AuthorDto, dtoObjects: Array<NormKey>) : AuthorDto
        {
            // Normalizer - Denormalize - Header.cs
            if (author == null)
                return null;
            author.myKey = "Author_" + author.authorId;

            var retObj: AuthorDto = null;

            var obj = this.dtoObjects.find(p => p.key == author.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as AuthorDto;
                retObj.myKey = "Author_" + author.authorId;

            }



            // Normalizer - Denormalize - Child tables.cs

            for (var i = 0; i< author?.books?.length; i++)
            {
                retObj.books[i] = this.DenormalizeBook(author.books[i], dtoObjects);
            }

            // Normalizer - Denormalize - Ref fields.cs

            {
                var xCountry: CountryDto = null;
                for (var iiCountry = 0; iiCountry < this.dtoObjects.length; iiCountry++) {
                    if (this.dtoObjects[iiCountry].key == "Country_" + author.countryID) {
                        xCountry = this.dtoObjects[iiCountry].object;
                    }
                }

                retObj.country = this.DenormalizeCountry(xCountry, dtoObjects);
            }

            return retObj;
        }

        JsonAux_Deserialize_BookDto(json: string) : BookDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadBook(book: BookDto) : BookDto 
        {
            // Normalizer - Load - Header.cs
            if (book == null)
                return null;
            book.myKey = "Book_" + book.bookId;
            var retObj = new BookDto();
            retObj.myKey = "Book_" + book.bookId;

            var obj = this.dtoObjects.find(p => p.key == book.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as BookDto;
            }
            else {
                var nk = new NormKey();
                nk.key = book.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            // Normalizer - Load - Id field.cs

            retObj.bookId = book.bookId;

            // Normalizer - Load - Ref fields.cs

            retObj.genreID = book.genreID;
            retObj.genre = this.LoadGenre(book.genre);

            retObj.authorID = book.authorID;
            retObj.author = this.LoadAuthor(book.author);

            retObj.ratingId = book.ratingId;
            retObj.rating = this.LoadRating(book.rating);

            // Normalizer - Load - Data fields.cs

            retObj.title = book.title;

            retObj.yearOfPublish = book.yearOfPublish;

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeBook(book: BookDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (book == null)
                return;
            book.myKey = "Book_" + book.bookId;

            var obj = normalizer.dtoObjects.find(p => p.key == book.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = book.myKey;
                nk.object = book;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            // Normalizer - Normalize - Ref fields.ts

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (book.genre) {
                book.genreID = book.genre.genreId;
            }

            var book_genre = book.genre;
            book.genre = null;
            this.NormalizeGenre(book_genre, this);

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (book.author) {
                book.authorID = book.author.authorId;
            }

            var book_author = book.author;
            book.author = null;
            this.NormalizeAuthor(book_author, this);

            // Check if we've got an instance of the object, if so, revert the local id value.
            if (book.rating) {
                book.ratingId = book.rating.ratingId;
            }

            var book_rating = book.rating;
            book.rating = null;
            this.NormalizeRating(book_rating, this);

        }

        // Normalizer - Denormalize.cs
        DenormalizeBook(book: BookDto, dtoObjects: Array<NormKey>) : BookDto
        {
            // Normalizer - Denormalize - Header.cs
            if (book == null)
                return null;
            book.myKey = "Book_" + book.bookId;

            var retObj: BookDto = null;

            var obj = this.dtoObjects.find(p => p.key == book.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as BookDto;
                retObj.myKey = "Book_" + book.bookId;

            }



            // Normalizer - Denormalize - Child tables.cs

            // Normalizer - Denormalize - Ref fields.cs

            {
                var xGenre: GenreDto = null;
                for (var iiGenre = 0; iiGenre < this.dtoObjects.length; iiGenre++) {
                    if (this.dtoObjects[iiGenre].key == "Genre_" + book.genreID) {
                        xGenre = this.dtoObjects[iiGenre].object;
                    }
                }

                retObj.genre = this.DenormalizeGenre(xGenre, dtoObjects);
            }

            {
                var xAuthor: AuthorDto = null;
                for (var iiAuthor = 0; iiAuthor < this.dtoObjects.length; iiAuthor++) {
                    if (this.dtoObjects[iiAuthor].key == "Author_" + book.authorID) {
                        xAuthor = this.dtoObjects[iiAuthor].object;
                    }
                }

                retObj.author = this.DenormalizeAuthor(xAuthor, dtoObjects);
            }

            {
                var xRating: RatingDto = null;
                for (var iiRating = 0; iiRating < this.dtoObjects.length; iiRating++) {
                    if (this.dtoObjects[iiRating].key == "Rating_" + book.ratingId) {
                        xRating = this.dtoObjects[iiRating].object;
                    }
                }

                retObj.rating = this.DenormalizeRating(xRating, dtoObjects);
            }

            return retObj;
        }

        JsonAux_Deserialize_CountryDto(json: string) : CountryDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadCountry(country: CountryDto) : CountryDto 
        {
            // Normalizer - Load - Header.cs
            if (country == null)
                return null;
            country.myKey = "Country_" + country.countryId;
            var retObj = new CountryDto();
            retObj.myKey = "Country_" + country.countryId;

            var obj = this.dtoObjects.find(p => p.key == country.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as CountryDto;
            }
            else {
                var nk = new NormKey();
                nk.key = country.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            retObj.authors = new Array<AuthorDto>();
            for (var i = 0; i < country?.authors?.length ; i++)
            {
                var xAuthorsItem = country.authors[i];
                retObj.authors.push(this.LoadAuthor(xAuthorsItem));
            }

            // Normalizer - Load - Id field.cs

            retObj.countryId = country.countryId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.name = country.name;

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeCountry(country: CountryDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (country == null)
                return;
            country.myKey = "Country_" + country.countryId;

            var obj = normalizer.dtoObjects.find(p => p.key == country.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = country.myKey;
                nk.object = country;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            for (var i = 0; i < country?.authors?.length ; i++)
            {
                var xAuthorsItem = country.authors[i];
                this.NormalizeAuthor(xAuthorsItem, this);
            }

            // Normalizer - Normalize - Ref fields.ts

        }

        // Normalizer - Denormalize.cs
        DenormalizeCountry(country: CountryDto, dtoObjects: Array<NormKey>) : CountryDto
        {
            // Normalizer - Denormalize - Header.cs
            if (country == null)
                return null;
            country.myKey = "Country_" + country.countryId;

            var retObj: CountryDto = null;

            var obj = this.dtoObjects.find(p => p.key == country.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as CountryDto;
                retObj.myKey = "Country_" + country.countryId;

            }



            // Normalizer - Denormalize - Child tables.cs

            for (var i = 0; i< country?.authors?.length; i++)
            {
                retObj.authors[i] = this.DenormalizeAuthor(country.authors[i], dtoObjects);
            }

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }

        JsonAux_Deserialize_GenreDto(json: string) : GenreDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadGenre(genre: GenreDto) : GenreDto 
        {
            // Normalizer - Load - Header.cs
            if (genre == null)
                return null;
            genre.myKey = "Genre_" + genre.genreId;
            var retObj = new GenreDto();
            retObj.myKey = "Genre_" + genre.genreId;

            var obj = this.dtoObjects.find(p => p.key == genre.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as GenreDto;
            }
            else {
                var nk = new NormKey();
                nk.key = genre.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            retObj.books = new Array<BookDto>();
            for (var i = 0; i < genre?.books?.length ; i++)
            {
                var xBooksItem = genre.books[i];
                retObj.books.push(this.LoadBook(xBooksItem));
            }

            // Normalizer - Load - Id field.cs

            retObj.genreId = genre.genreId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.name = genre.name;

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeGenre(genre: GenreDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (genre == null)
                return;
            genre.myKey = "Genre_" + genre.genreId;

            var obj = normalizer.dtoObjects.find(p => p.key == genre.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = genre.myKey;
                nk.object = genre;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            for (var i = 0; i < genre?.books?.length ; i++)
            {
                var xBooksItem = genre.books[i];
                this.NormalizeBook(xBooksItem, this);
            }

            // Normalizer - Normalize - Ref fields.ts

        }

        // Normalizer - Denormalize.cs
        DenormalizeGenre(genre: GenreDto, dtoObjects: Array<NormKey>) : GenreDto
        {
            // Normalizer - Denormalize - Header.cs
            if (genre == null)
                return null;
            genre.myKey = "Genre_" + genre.genreId;

            var retObj: GenreDto = null;

            var obj = this.dtoObjects.find(p => p.key == genre.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as GenreDto;
                retObj.myKey = "Genre_" + genre.genreId;

            }



            // Normalizer - Denormalize - Child tables.cs

            for (var i = 0; i< genre?.books?.length; i++)
            {
                retObj.books[i] = this.DenormalizeBook(genre.books[i], dtoObjects);
            }

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }

        JsonAux_Deserialize_RatingDto(json: string) : RatingDto {
            return null;
        }


        // Normalizer - Load.cs
        LoadRating(rating: RatingDto) : RatingDto 
        {
            // Normalizer - Load - Header.cs
            if (rating == null)
                return null;
            rating.myKey = "Rating_" + rating.ratingId;
            var retObj = new RatingDto();
            retObj.myKey = "Rating_" + rating.ratingId;

            var obj = this.dtoObjects.find(p => p.key == rating.myKey);
            if (obj != null && obj.object != null) {
                return obj.object as RatingDto;
            }
            else {
                var nk = new NormKey();
                nk.key = rating.myKey;
                nk.object = retObj;
                this.dtoObjects.push(nk);
            }



            // Normalizer - Load - Child tables.cs

            retObj.books = new Array<BookDto>();
            for (var i = 0; i < rating?.books?.length ; i++)
            {
                var xBooksItem = rating.books[i];
                retObj.books.push(this.LoadBook(xBooksItem));
            }

            // Normalizer - Load - Id field.cs

            retObj.ratingId = rating.ratingId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.name = rating.name;

            return retObj;
        }

        // Normalizer - Normalize.cs
        NormalizeRating(rating: RatingDto, normalizer: Normalizer)
        {
            // Normalizer - Normalize - Header.cs
            if (rating == null)
                return;
            rating.myKey = "Rating_" + rating.ratingId;

            var obj = normalizer.dtoObjects.find(p => p.key == rating.myKey);
            if (obj != null && obj.object != null) {
                // If we've got an object, it has already been handled, null out 
                return;
            }
            else {
                var nk = new NormKey();
                nk.key = rating.myKey;
                nk.object = rating;
                normalizer.dtoObjects.push(nk);
            }





            // Normalizer - Normalize - Child tables.ts

            for (var i = 0; i < rating?.books?.length ; i++)
            {
                var xBooksItem = rating.books[i];
                this.NormalizeBook(xBooksItem, this);
            }

            // Normalizer - Normalize - Ref fields.ts

        }

        // Normalizer - Denormalize.cs
        DenormalizeRating(rating: RatingDto, dtoObjects: Array<NormKey>) : RatingDto
        {
            // Normalizer - Denormalize - Header.cs
            if (rating == null)
                return null;
            rating.myKey = "Rating_" + rating.ratingId;

            var retObj: RatingDto = null;

            var obj = this.dtoObjects.find(p => p.key == rating.myKey);
            if (obj != null && obj.object != null && obj.isDenormalized) {
                // This has been denormalized already - simply return it.
                return obj.object;
            }
            else {
                if (obj == null) {
                    return null; // Wasn't loaded before normalization
                }
                obj.isDenormalized = true;
                retObj = obj.object as RatingDto;
                retObj.myKey = "Rating_" + rating.ratingId;

            }



            // Normalizer - Denormalize - Child tables.cs

            for (var i = 0; i< rating?.books?.length; i++)
            {
                retObj.books[i] = this.DenormalizeBook(rating.books[i], dtoObjects);
            }

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }


    } // End normalizers

        // DtoClasses.cs

    // VM - class.cs
    export class ClientDto extends DtoBase
    {
        // VM - class - id.cs

        clientId: number;

        // VM - class - Child tables.cs

        project_Clients: Array<Project_ClientDto>;

        // VM - class - Ref.cs

        personId: number;

        keyAccountManager: PersonDto;

        // VM - class - Data.cs

        clientName: string;

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class DepartmentDto extends DtoBase
    {
        // VM - class - id.cs

        departmentId: number;

        // VM - class - Child tables.cs

        persons: Array<PersonDto>;

        // VM - class - Ref.cs

        // VM - class - Data.cs

        departmentName: string;

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class GenderDto extends DtoBase
    {
        // VM - class - id.cs

        genderId: number;

        // VM - class - Child tables.cs

        persons: Array<PersonDto>;

        // VM - class - Ref.cs

        // VM - class - Data.cs

        genderDescription: string;

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class PersonDto extends DtoBase
    {
        // VM - class - id.cs

        personId: number;

        // VM - class - Child tables.cs

        clients: Array<ClientDto>;

        employees: Array<PersonDto>;

        project_Person_Roles: Array<Project_Person_RoleDto>;

        // VM - class - Ref.cs

        departmentId: number;

        department: DepartmentDto;

        genderId: number;

        gender: GenderDto;

        managerId: number;

        manager: PersonDto;

        // VM - class - Data.cs

        userName: string;

        salary: number;

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class ProjectDto extends DtoBase
    {
        // VM - class - id.cs

        projectId: number;

        // VM - class - Child tables.cs

        project_Clients: Array<Project_ClientDto>;

        project_Person_Roles: Array<Project_Person_RoleDto>;

        // VM - class - Ref.cs

        projectTypeId: number;

        projectType: ProjectTypeDto;

        viewProjectAug: ViewProjectAugDto; // Refer to Augmented View.

        // VM - class - Data.cs

        projectName: string;

        isProBono: boolean;

        deadline: Date;

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class ProjectTypeDto extends DtoBase
    {
        // VM - class - id.cs

        projectTypeId: number;

        // VM - class - Child tables.cs

        projects: Array<ProjectDto>;

        // VM - class - Ref.cs

        // VM - class - Data.cs

        projectTypeName: string;

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class Project_ClientDto extends DtoBase
    {
        // VM - class - id.cs

        project_ClientId: number;

        // VM - class - Child tables.cs

        // VM - class - Ref.cs

        projectId: number;

        project: ProjectDto;

        clientId: number;

        client: ClientDto;

        // VM - class - Data.cs

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class Project_Person_RoleDto extends DtoBase
    {
        // VM - class - id.cs

        project_Person_RoleId: number;

        // VM - class - Child tables.cs

        // VM - class - Ref.cs

        personId: number;

        person: PersonDto;

        projectId: number;

        project: ProjectDto;

        roleId: number;

        role: RoleDto;

        // VM - class - Data.cs

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class RoleDto extends DtoBase
    {
        // VM - class - id.cs

        roleId: number;

        // VM - class - Child tables.cs

        project_Person_Roles: Array<Project_Person_RoleDto>;

        // VM - class - Ref.cs

        // VM - class - Data.cs

        roleName: string;

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class ViewProjectAugDto extends DtoBase
    {
        // VM - class - id.cs

        projectId: number;

        // VM - class - Child tables.cs

        // VM - class - Ref.cs

        // VM - class - Data.cs

        tempNum: number;

        quadruple: number;

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class AuthorDto extends DtoBase
    {
        // VM - class - id.cs

        authorId: number;

        // VM - class - Child tables.cs

        books: Array<BookDto>;

        // VM - class - Ref.cs

        countryID: number;

        country: CountryDto;

        // VM - class - Data.cs

        firstName: string;

        lastName: string;

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class BookDto extends DtoBase
    {
        // VM - class - id.cs

        bookId: number;

        // VM - class - Child tables.cs

        // VM - class - Ref.cs

        genreID: number;

        genre: GenreDto;

        authorID: number;

        author: AuthorDto;

        ratingId: number;

        rating: RatingDto;

        // VM - class - Data.cs

        title: string;

        yearOfPublish: number;

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class CountryDto extends DtoBase
    {
        // VM - class - id.cs

        countryId: number;

        // VM - class - Child tables.cs

        authors: Array<AuthorDto>;

        // VM - class - Ref.cs

        // VM - class - Data.cs

        name: string;

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class GenreDto extends DtoBase
    {
        // VM - class - id.cs

        genreId: number;

        // VM - class - Child tables.cs

        books: Array<BookDto>;

        // VM - class - Ref.cs

        // VM - class - Data.cs

        name: string;

        // Custom object
        extraObject: any;
    }

    // VM - class.cs
    export class RatingDto extends DtoBase
    {
        // VM - class - id.cs

        ratingId: number;

        // VM - class - Child tables.cs

        books: Array<BookDto>;

        // VM - class - Ref.cs

        // VM - class - Data.cs

        name: string;

        // Custom object
        extraObject: any;
    }


    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    export class ProjectFilterRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectFilterRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: ProjectFilterRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    export class ProjectFilterResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        projectTypes: Array<ProjectTypeDto>;

        request: ProjectFilterRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectFilterResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.projectTypes?.length; i++)
            //{
            //    normalizer.NormalizeProjectType(me.projectTypes[i], normalizer);
            //}
            me.projectTypes = new Array<ProjectTypeDto>();

            ProjectFilterRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ProjectFilterResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.projectTypes?.length; i++)
            {
                me.projectTypes[i] = normalizer.DenormalizeProjectType(me.projectTypes[i], normalizer.dtoObjects);
            }

            ProjectFilterRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    export class ProjectSearchRequest extends TransferBase {
        constructor() {
            super();

        this.quickSearch = "";

        this.projectId = new IntClause();

        this.projectName = new StringClause();

        this.isProBono = new BoolClause();

        this.deadline = new DateTimeClause();

        this.projectType_projectTypeId = new IntClause();

        this.projectType_projectTypeName = new StringClause();

        this.viewProjectAug_projectId = new IntClause();

        this.viewProjectAug_tempNum = new IntClause();

        this.viewProjectAug_quadruple = new IntClause();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        quickSearch: string;

        projectId: IntClause;

        projectName: StringClause;

        isProBono: BoolClause;

        deadline: DateTimeClause;

        projectType_projectTypeId: IntClause;

        projectType_projectTypeName: StringClause;

        viewProjectAug_projectId: IntClause;

        viewProjectAug_tempNum: IntClause;

        viewProjectAug_quadruple: IntClause;

        
        static Normalize(normalizer: Normalizer, me: ProjectSearchRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: ProjectSearchRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    export class ProjectSearchResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        projects: Array<ProjectDto>;

        request: ProjectSearchRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectSearchResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.projects?.length; i++)
            //{
            //    normalizer.NormalizeProject(me.projects[i], normalizer);
            //}
            me.projects = new Array<ProjectDto>();

            ProjectSearchRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ProjectSearchResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.projects?.length; i++)
            {
                me.projects[i] = normalizer.DenormalizeProject(me.projects[i], normalizer.dtoObjects);
            }

            ProjectSearchRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Detail request, basically one item from the AugView Project, that user clicked after search was performed.
    /// </summary>
    export class ProjectDetailsRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        project: ProjectDto


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectDetailsRequest)
        {
            // Data objects

            normalizer.NormalizeProject(me.project, normalizer);

        }

        static Denormalize(normalizer: Normalizer, me: ProjectDetailsRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.project = normalizer.DenormalizeProject(me.project, normalizer.dtoObjects);

        }

    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    export class ProjectDetailsResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        project: ProjectDto

        genders: Array<GenderDto>;

        projectTypes: Array<ProjectTypeDto>;

        departments: Array<DepartmentDto>;

        roles: Array<RoleDto>;

        request: ProjectDetailsRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectDetailsResponse)
        {
            // Data objects

            normalizer.NormalizeProject(me.project, normalizer);

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.genders?.length; i++)
            //{
            //    normalizer.NormalizeGender(me.genders[i], normalizer);
            //}
            me.genders = new Array<GenderDto>();

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.projectTypes?.length; i++)
            //{
            //    normalizer.NormalizeProjectType(me.projectTypes[i], normalizer);
            //}
            me.projectTypes = new Array<ProjectTypeDto>();

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.departments?.length; i++)
            //{
            //    normalizer.NormalizeDepartment(me.departments[i], normalizer);
            //}
            me.departments = new Array<DepartmentDto>();

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.roles?.length; i++)
            //{
            //    normalizer.NormalizeRole(me.roles[i], normalizer);
            //}
            me.roles = new Array<RoleDto>();

            ProjectDetailsRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ProjectDetailsResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.project = normalizer.DenormalizeProject(me.project, normalizer.dtoObjects);

            for (var i = 0; i < me.genders?.length; i++)
            {
                me.genders[i] = normalizer.DenormalizeGender(me.genders[i], normalizer.dtoObjects);
            }

            for (var i = 0; i < me.projectTypes?.length; i++)
            {
                me.projectTypes[i] = normalizer.DenormalizeProjectType(me.projectTypes[i], normalizer.dtoObjects);
            }

            for (var i = 0; i < me.departments?.length; i++)
            {
                me.departments[i] = normalizer.DenormalizeDepartment(me.departments[i], normalizer.dtoObjects);
            }

            for (var i = 0; i < me.roles?.length; i++)
            {
                me.roles[i] = normalizer.DenormalizeRole(me.roles[i], normalizer.dtoObjects);
            }

            ProjectDetailsRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    export class PersonMiniFilterRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonMiniFilterRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: PersonMiniFilterRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    export class PersonMiniFilterResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        departments: Array<DepartmentDto>;

        genders: Array<GenderDto>;

        request: PersonMiniFilterRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonMiniFilterResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.departments?.length; i++)
            //{
            //    normalizer.NormalizeDepartment(me.departments[i], normalizer);
            //}
            me.departments = new Array<DepartmentDto>();

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.genders?.length; i++)
            //{
            //    normalizer.NormalizeGender(me.genders[i], normalizer);
            //}
            me.genders = new Array<GenderDto>();

            PersonMiniFilterRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: PersonMiniFilterResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.departments?.length; i++)
            {
                me.departments[i] = normalizer.DenormalizeDepartment(me.departments[i], normalizer.dtoObjects);
            }

            for (var i = 0; i < me.genders?.length; i++)
            {
                me.genders[i] = normalizer.DenormalizeGender(me.genders[i], normalizer.dtoObjects);
            }

            PersonMiniFilterRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    export class PersonMiniSearchRequest extends TransferBase {
        constructor() {
            super();

        this.quickSearch = "";

        this.personId = new IntClause();

        this.userName = new StringClause();

        this.salary = new IntClause();

        this.gender_genderId = new IntClause();

        this.gender_genderDescription = new StringClause();

        this.department_departmentId = new IntClause();

        this.department_departmentName = new StringClause();

        this.manager_personId = new IntClause();

        this.manager_userName = new StringClause();

        this.manager_salary = new IntClause();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        quickSearch: string;

        personId: IntClause;

        userName: StringClause;

        salary: IntClause;

        gender_genderId: IntClause;

        gender_genderDescription: StringClause;

        department_departmentId: IntClause;

        department_departmentName: StringClause;

        manager_personId: IntClause;

        manager_userName: StringClause;

        manager_salary: IntClause;

        
        static Normalize(normalizer: Normalizer, me: PersonMiniSearchRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: PersonMiniSearchRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    export class PersonMiniSearchResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        persons: Array<PersonDto>;

        request: PersonMiniSearchRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonMiniSearchResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.persons?.length; i++)
            //{
            //    normalizer.NormalizePerson(me.persons[i], normalizer);
            //}
            me.persons = new Array<PersonDto>();

            PersonMiniSearchRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: PersonMiniSearchResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.persons?.length; i++)
            {
                me.persons[i] = normalizer.DenormalizePerson(me.persons[i], normalizer.dtoObjects);
            }

            PersonMiniSearchRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Detail request, basically one item from the AugView Person, that user clicked after search was performed.
    /// </summary>
    export class PersonMiniDetailsRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        person: PersonDto


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonMiniDetailsRequest)
        {
            // Data objects

            normalizer.NormalizePerson(me.person, normalizer);

        }

        static Denormalize(normalizer: Normalizer, me: PersonMiniDetailsRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.person = normalizer.DenormalizePerson(me.person, normalizer.dtoObjects);

        }

    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    export class PersonMiniDetailsResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        person: PersonDto

        genders: Array<GenderDto>;

        departments: Array<DepartmentDto>;

        request: PersonMiniDetailsRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonMiniDetailsResponse)
        {
            // Data objects

            normalizer.NormalizePerson(me.person, normalizer);

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.genders?.length; i++)
            //{
            //    normalizer.NormalizeGender(me.genders[i], normalizer);
            //}
            me.genders = new Array<GenderDto>();

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.departments?.length; i++)
            //{
            //    normalizer.NormalizeDepartment(me.departments[i], normalizer);
            //}
            me.departments = new Array<DepartmentDto>();

            PersonMiniDetailsRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: PersonMiniDetailsResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.person = normalizer.DenormalizePerson(me.person, normalizer.dtoObjects);

            for (var i = 0; i < me.genders?.length; i++)
            {
                me.genders[i] = normalizer.DenormalizeGender(me.genders[i], normalizer.dtoObjects);
            }

            for (var i = 0; i < me.departments?.length; i++)
            {
                me.departments[i] = normalizer.DenormalizeDepartment(me.departments[i], normalizer.dtoObjects);
            }

            PersonMiniDetailsRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    export class PersonFilterRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonFilterRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: PersonFilterRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    export class PersonFilterResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        genders: Array<GenderDto>;

        departments: Array<DepartmentDto>;

        request: PersonFilterRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonFilterResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.genders?.length; i++)
            //{
            //    normalizer.NormalizeGender(me.genders[i], normalizer);
            //}
            me.genders = new Array<GenderDto>();

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.departments?.length; i++)
            //{
            //    normalizer.NormalizeDepartment(me.departments[i], normalizer);
            //}
            me.departments = new Array<DepartmentDto>();

            PersonFilterRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: PersonFilterResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.genders?.length; i++)
            {
                me.genders[i] = normalizer.DenormalizeGender(me.genders[i], normalizer.dtoObjects);
            }

            for (var i = 0; i < me.departments?.length; i++)
            {
                me.departments[i] = normalizer.DenormalizeDepartment(me.departments[i], normalizer.dtoObjects);
            }

            PersonFilterRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    export class PersonSearchRequest extends TransferBase {
        constructor() {
            super();

        this.quickSearch = "";

        this.personId = new IntClause();

        this.userName = new StringClause();

        this.salary = new IntClause();

        this.department_departmentId = new IntClause();

        this.department_departmentName = new StringClause();

        this.gender_genderId = new IntClause();

        this.gender_genderDescription = new StringClause();

        this.manager_personId = new IntClause();

        this.manager_userName = new StringClause();

        this.manager_salary = new IntClause();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        quickSearch: string;

        personId: IntClause;

        userName: StringClause;

        salary: IntClause;

        department_departmentId: IntClause;

        department_departmentName: StringClause;

        gender_genderId: IntClause;

        gender_genderDescription: StringClause;

        manager_personId: IntClause;

        manager_userName: StringClause;

        manager_salary: IntClause;

        
        static Normalize(normalizer: Normalizer, me: PersonSearchRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: PersonSearchRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    export class PersonSearchResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        persons: Array<PersonDto>;

        request: PersonSearchRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonSearchResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.persons?.length; i++)
            //{
            //    normalizer.NormalizePerson(me.persons[i], normalizer);
            //}
            me.persons = new Array<PersonDto>();

            PersonSearchRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: PersonSearchResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.persons?.length; i++)
            {
                me.persons[i] = normalizer.DenormalizePerson(me.persons[i], normalizer.dtoObjects);
            }

            PersonSearchRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Detail request, basically one item from the AugView Person, that user clicked after search was performed.
    /// </summary>
    export class PersonDetailsRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        person: PersonDto


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonDetailsRequest)
        {
            // Data objects

            normalizer.NormalizePerson(me.person, normalizer);

        }

        static Denormalize(normalizer: Normalizer, me: PersonDetailsRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.person = normalizer.DenormalizePerson(me.person, normalizer.dtoObjects);

        }

    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    export class PersonDetailsResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        person: PersonDto

        genders: Array<GenderDto>;

        departments: Array<DepartmentDto>;

        request: PersonDetailsRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonDetailsResponse)
        {
            // Data objects

            normalizer.NormalizePerson(me.person, normalizer);

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.genders?.length; i++)
            //{
            //    normalizer.NormalizeGender(me.genders[i], normalizer);
            //}
            me.genders = new Array<GenderDto>();

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.departments?.length; i++)
            //{
            //    normalizer.NormalizeDepartment(me.departments[i], normalizer);
            //}
            me.departments = new Array<DepartmentDto>();

            PersonDetailsRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: PersonDetailsResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.person = normalizer.DenormalizePerson(me.person, normalizer.dtoObjects);

            for (var i = 0; i < me.genders?.length; i++)
            {
                me.genders[i] = normalizer.DenormalizeGender(me.genders[i], normalizer.dtoObjects);
            }

            for (var i = 0; i < me.departments?.length; i++)
            {
                me.departments[i] = normalizer.DenormalizeDepartment(me.departments[i], normalizer.dtoObjects);
            }

            PersonDetailsRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    export class ClientFilterRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ClientFilterRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: ClientFilterRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    export class ClientFilterResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        request: ClientFilterRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ClientFilterResponse)
        {
            // Data objects

            ClientFilterRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ClientFilterResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            ClientFilterRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    export class ClientSearchRequest extends TransferBase {
        constructor() {
            super();

        this.quickSearch = "";

        this.clientId = new IntClause();

        this.clientName = new StringClause();

        this.keyAccountManager_personId = new IntClause();

        this.keyAccountManager_userName = new StringClause();

        this.keyAccountManager_salary = new IntClause();

        this.keyAccountManager_gender_genderId = new IntClause();

        this.keyAccountManager_gender_genderDescription = new StringClause();

        this.keyAccountManager_department_departmentId = new IntClause();

        this.keyAccountManager_department_departmentName = new StringClause();

        this.keyAccountManager_manager_personId = new IntClause();

        this.keyAccountManager_manager_userName = new StringClause();

        this.keyAccountManager_manager_salary = new IntClause();

        this.keyAccountManager_manager_gender_genderId = new IntClause();

        this.keyAccountManager_manager_gender_genderDescription = new StringClause();

        this.keyAccountManager_manager_department_departmentId = new IntClause();

        this.keyAccountManager_manager_department_departmentName = new StringClause();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        quickSearch: string;

        clientId: IntClause;

        clientName: StringClause;

        keyAccountManager_personId: IntClause;

        keyAccountManager_userName: StringClause;

        keyAccountManager_salary: IntClause;

        keyAccountManager_gender_genderId: IntClause;

        keyAccountManager_gender_genderDescription: StringClause;

        keyAccountManager_department_departmentId: IntClause;

        keyAccountManager_department_departmentName: StringClause;

        keyAccountManager_manager_personId: IntClause;

        keyAccountManager_manager_userName: StringClause;

        keyAccountManager_manager_salary: IntClause;

        keyAccountManager_manager_gender_genderId: IntClause;

        keyAccountManager_manager_gender_genderDescription: StringClause;

        keyAccountManager_manager_department_departmentId: IntClause;

        keyAccountManager_manager_department_departmentName: StringClause;

        
        static Normalize(normalizer: Normalizer, me: ClientSearchRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: ClientSearchRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    export class ClientSearchResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        clients: Array<ClientDto>;

        request: ClientSearchRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ClientSearchResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.clients?.length; i++)
            //{
            //    normalizer.NormalizeClient(me.clients[i], normalizer);
            //}
            me.clients = new Array<ClientDto>();

            ClientSearchRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ClientSearchResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.clients?.length; i++)
            {
                me.clients[i] = normalizer.DenormalizeClient(me.clients[i], normalizer.dtoObjects);
            }

            ClientSearchRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Detail request, basically one item from the AugView Client, that user clicked after search was performed.
    /// </summary>
    export class ClientDetailsRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        client: ClientDto


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ClientDetailsRequest)
        {
            // Data objects

            normalizer.NormalizeClient(me.client, normalizer);

        }

        static Denormalize(normalizer: Normalizer, me: ClientDetailsRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.client = normalizer.DenormalizeClient(me.client, normalizer.dtoObjects);

        }

    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    export class ClientDetailsResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        client: ClientDto

        request: ClientDetailsRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ClientDetailsResponse)
        {
            // Data objects

            normalizer.NormalizeClient(me.client, normalizer);

            ClientDetailsRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ClientDetailsResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.client = normalizer.DenormalizeClient(me.client, normalizer.dtoObjects);

            ClientDetailsRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    export class ClientLookupFilterRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ClientLookupFilterRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: ClientLookupFilterRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    export class ClientLookupFilterResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        request: ClientLookupFilterRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ClientLookupFilterResponse)
        {
            // Data objects

            ClientLookupFilterRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ClientLookupFilterResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            ClientLookupFilterRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    export class ClientLookupSearchRequest extends TransferBase {
        constructor() {
            super();

        this.quickSearch = "";

        this.clientId = new IntClause();

        this.clientName = new StringClause();

        this.keyAccountManager_personId = new IntClause();

        this.keyAccountManager_userName = new StringClause();

        this.keyAccountManager_salary = new IntClause();

        this.keyAccountManager_gender_genderId = new IntClause();

        this.keyAccountManager_gender_genderDescription = new StringClause();

        this.keyAccountManager_department_departmentId = new IntClause();

        this.keyAccountManager_department_departmentName = new StringClause();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        quickSearch: string;

        clientId: IntClause;

        clientName: StringClause;

        keyAccountManager_personId: IntClause;

        keyAccountManager_userName: StringClause;

        keyAccountManager_salary: IntClause;

        keyAccountManager_gender_genderId: IntClause;

        keyAccountManager_gender_genderDescription: StringClause;

        keyAccountManager_department_departmentId: IntClause;

        keyAccountManager_department_departmentName: StringClause;

        
        static Normalize(normalizer: Normalizer, me: ClientLookupSearchRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: ClientLookupSearchRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    export class ClientLookupSearchResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        clients: Array<ClientDto>;

        request: ClientLookupSearchRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ClientLookupSearchResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.clients?.length; i++)
            //{
            //    normalizer.NormalizeClient(me.clients[i], normalizer);
            //}
            me.clients = new Array<ClientDto>();

            ClientLookupSearchRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ClientLookupSearchResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.clients?.length; i++)
            {
                me.clients[i] = normalizer.DenormalizeClient(me.clients[i], normalizer.dtoObjects);
            }

            ClientLookupSearchRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Detail request, basically one item from the AugView Client, that user clicked after search was performed.
    /// </summary>
    export class ClientLookupDetailsRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        client: ClientDto


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ClientLookupDetailsRequest)
        {
            // Data objects

            normalizer.NormalizeClient(me.client, normalizer);

        }

        static Denormalize(normalizer: Normalizer, me: ClientLookupDetailsRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.client = normalizer.DenormalizeClient(me.client, normalizer.dtoObjects);

        }

    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    export class ClientLookupDetailsResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        client: ClientDto

        request: ClientLookupDetailsRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ClientLookupDetailsResponse)
        {
            // Data objects

            normalizer.NormalizeClient(me.client, normalizer);

            ClientLookupDetailsRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ClientLookupDetailsResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.client = normalizer.DenormalizeClient(me.client, normalizer.dtoObjects);

            ClientLookupDetailsRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    export class GenderLookupFilterRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: GenderLookupFilterRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: GenderLookupFilterRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    export class GenderLookupFilterResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        request: GenderLookupFilterRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: GenderLookupFilterResponse)
        {
            // Data objects

            GenderLookupFilterRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: GenderLookupFilterResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            GenderLookupFilterRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    export class GenderLookupSearchRequest extends TransferBase {
        constructor() {
            super();

        this.quickSearch = "";

        this.genderId = new IntClause();

        this.genderDescription = new StringClause();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        quickSearch: string;

        genderId: IntClause;

        genderDescription: StringClause;

        
        static Normalize(normalizer: Normalizer, me: GenderLookupSearchRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: GenderLookupSearchRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    export class GenderLookupSearchResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        genders: Array<GenderDto>;

        request: GenderLookupSearchRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: GenderLookupSearchResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.genders?.length; i++)
            //{
            //    normalizer.NormalizeGender(me.genders[i], normalizer);
            //}
            me.genders = new Array<GenderDto>();

            GenderLookupSearchRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: GenderLookupSearchResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.genders?.length; i++)
            {
                me.genders[i] = normalizer.DenormalizeGender(me.genders[i], normalizer.dtoObjects);
            }

            GenderLookupSearchRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Detail request, basically one item from the AugView Gender, that user clicked after search was performed.
    /// </summary>
    export class GenderLookupDetailsRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        gender: GenderDto


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: GenderLookupDetailsRequest)
        {
            // Data objects

            normalizer.NormalizeGender(me.gender, normalizer);

        }

        static Denormalize(normalizer: Normalizer, me: GenderLookupDetailsRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.gender = normalizer.DenormalizeGender(me.gender, normalizer.dtoObjects);

        }

    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    export class GenderLookupDetailsResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        gender: GenderDto

        request: GenderLookupDetailsRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: GenderLookupDetailsResponse)
        {
            // Data objects

            normalizer.NormalizeGender(me.gender, normalizer);

            GenderLookupDetailsRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: GenderLookupDetailsResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.gender = normalizer.DenormalizeGender(me.gender, normalizer.dtoObjects);

            GenderLookupDetailsRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    export class ProjectTypeLookupFilterRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectTypeLookupFilterRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: ProjectTypeLookupFilterRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    export class ProjectTypeLookupFilterResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        request: ProjectTypeLookupFilterRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectTypeLookupFilterResponse)
        {
            // Data objects

            ProjectTypeLookupFilterRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ProjectTypeLookupFilterResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            ProjectTypeLookupFilterRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    export class ProjectTypeLookupSearchRequest extends TransferBase {
        constructor() {
            super();

        this.quickSearch = "";

        this.projectTypeId = new IntClause();

        this.projectTypeName = new StringClause();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        quickSearch: string;

        projectTypeId: IntClause;

        projectTypeName: StringClause;

        
        static Normalize(normalizer: Normalizer, me: ProjectTypeLookupSearchRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: ProjectTypeLookupSearchRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    export class ProjectTypeLookupSearchResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        projectTypes: Array<ProjectTypeDto>;

        request: ProjectTypeLookupSearchRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectTypeLookupSearchResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.projectTypes?.length; i++)
            //{
            //    normalizer.NormalizeProjectType(me.projectTypes[i], normalizer);
            //}
            me.projectTypes = new Array<ProjectTypeDto>();

            ProjectTypeLookupSearchRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ProjectTypeLookupSearchResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.projectTypes?.length; i++)
            {
                me.projectTypes[i] = normalizer.DenormalizeProjectType(me.projectTypes[i], normalizer.dtoObjects);
            }

            ProjectTypeLookupSearchRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Detail request, basically one item from the AugView ProjectType, that user clicked after search was performed.
    /// </summary>
    export class ProjectTypeLookupDetailsRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        projectType: ProjectTypeDto


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectTypeLookupDetailsRequest)
        {
            // Data objects

            normalizer.NormalizeProjectType(me.projectType, normalizer);

        }

        static Denormalize(normalizer: Normalizer, me: ProjectTypeLookupDetailsRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.projectType = normalizer.DenormalizeProjectType(me.projectType, normalizer.dtoObjects);

        }

    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    export class ProjectTypeLookupDetailsResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        projectType: ProjectTypeDto

        request: ProjectTypeLookupDetailsRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectTypeLookupDetailsResponse)
        {
            // Data objects

            normalizer.NormalizeProjectType(me.projectType, normalizer);

            ProjectTypeLookupDetailsRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ProjectTypeLookupDetailsResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.projectType = normalizer.DenormalizeProjectType(me.projectType, normalizer.dtoObjects);

            ProjectTypeLookupDetailsRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    export class DepartmentLookupFilterRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: DepartmentLookupFilterRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: DepartmentLookupFilterRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    export class DepartmentLookupFilterResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        request: DepartmentLookupFilterRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: DepartmentLookupFilterResponse)
        {
            // Data objects

            DepartmentLookupFilterRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: DepartmentLookupFilterResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            DepartmentLookupFilterRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    export class DepartmentLookupSearchRequest extends TransferBase {
        constructor() {
            super();

        this.quickSearch = "";

        this.departmentId = new IntClause();

        this.departmentName = new StringClause();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        quickSearch: string;

        departmentId: IntClause;

        departmentName: StringClause;

        
        static Normalize(normalizer: Normalizer, me: DepartmentLookupSearchRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: DepartmentLookupSearchRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    export class DepartmentLookupSearchResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        departments: Array<DepartmentDto>;

        request: DepartmentLookupSearchRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: DepartmentLookupSearchResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.departments?.length; i++)
            //{
            //    normalizer.NormalizeDepartment(me.departments[i], normalizer);
            //}
            me.departments = new Array<DepartmentDto>();

            DepartmentLookupSearchRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: DepartmentLookupSearchResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.departments?.length; i++)
            {
                me.departments[i] = normalizer.DenormalizeDepartment(me.departments[i], normalizer.dtoObjects);
            }

            DepartmentLookupSearchRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Detail request, basically one item from the AugView Department, that user clicked after search was performed.
    /// </summary>
    export class DepartmentLookupDetailsRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        department: DepartmentDto


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: DepartmentLookupDetailsRequest)
        {
            // Data objects

            normalizer.NormalizeDepartment(me.department, normalizer);

        }

        static Denormalize(normalizer: Normalizer, me: DepartmentLookupDetailsRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.department = normalizer.DenormalizeDepartment(me.department, normalizer.dtoObjects);

        }

    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    export class DepartmentLookupDetailsResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        department: DepartmentDto

        request: DepartmentLookupDetailsRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: DepartmentLookupDetailsResponse)
        {
            // Data objects

            normalizer.NormalizeDepartment(me.department, normalizer);

            DepartmentLookupDetailsRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: DepartmentLookupDetailsResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.department = normalizer.DenormalizeDepartment(me.department, normalizer.dtoObjects);

            DepartmentLookupDetailsRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    export class RoleLookupFilterRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: RoleLookupFilterRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: RoleLookupFilterRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    export class RoleLookupFilterResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        request: RoleLookupFilterRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: RoleLookupFilterResponse)
        {
            // Data objects

            RoleLookupFilterRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: RoleLookupFilterResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            RoleLookupFilterRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    export class RoleLookupSearchRequest extends TransferBase {
        constructor() {
            super();

        this.quickSearch = "";

        this.roleId = new IntClause();

        this.roleName = new StringClause();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        quickSearch: string;

        roleId: IntClause;

        roleName: StringClause;

        
        static Normalize(normalizer: Normalizer, me: RoleLookupSearchRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: RoleLookupSearchRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    export class RoleLookupSearchResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        roles: Array<RoleDto>;

        request: RoleLookupSearchRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: RoleLookupSearchResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.roles?.length; i++)
            //{
            //    normalizer.NormalizeRole(me.roles[i], normalizer);
            //}
            me.roles = new Array<RoleDto>();

            RoleLookupSearchRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: RoleLookupSearchResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.roles?.length; i++)
            {
                me.roles[i] = normalizer.DenormalizeRole(me.roles[i], normalizer.dtoObjects);
            }

            RoleLookupSearchRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Detail request, basically one item from the AugView Role, that user clicked after search was performed.
    /// </summary>
    export class RoleLookupDetailsRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        role: RoleDto


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: RoleLookupDetailsRequest)
        {
            // Data objects

            normalizer.NormalizeRole(me.role, normalizer);

        }

        static Denormalize(normalizer: Normalizer, me: RoleLookupDetailsRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.role = normalizer.DenormalizeRole(me.role, normalizer.dtoObjects);

        }

    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    export class RoleLookupDetailsResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        role: RoleDto

        request: RoleLookupDetailsRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: RoleLookupDetailsResponse)
        {
            // Data objects

            normalizer.NormalizeRole(me.role, normalizer);

            RoleLookupDetailsRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: RoleLookupDetailsResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.role = normalizer.DenormalizeRole(me.role, normalizer.dtoObjects);

            RoleLookupDetailsRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    export class ProjectLookupFilterRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectLookupFilterRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: ProjectLookupFilterRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    export class ProjectLookupFilterResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        projectTypes: Array<ProjectTypeDto>;

        request: ProjectLookupFilterRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectLookupFilterResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.projectTypes?.length; i++)
            //{
            //    normalizer.NormalizeProjectType(me.projectTypes[i], normalizer);
            //}
            me.projectTypes = new Array<ProjectTypeDto>();

            ProjectLookupFilterRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ProjectLookupFilterResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.projectTypes?.length; i++)
            {
                me.projectTypes[i] = normalizer.DenormalizeProjectType(me.projectTypes[i], normalizer.dtoObjects);
            }

            ProjectLookupFilterRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    export class ProjectLookupSearchRequest extends TransferBase {
        constructor() {
            super();

        this.quickSearch = "";

        this.projectId = new IntClause();

        this.projectName = new StringClause();

        this.isProBono = new BoolClause();

        this.deadline = new DateTimeClause();

        this.projectType_projectTypeId = new IntClause();

        this.projectType_projectTypeName = new StringClause();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        quickSearch: string;

        projectId: IntClause;

        projectName: StringClause;

        isProBono: BoolClause;

        deadline: DateTimeClause;

        projectType_projectTypeId: IntClause;

        projectType_projectTypeName: StringClause;

        
        static Normalize(normalizer: Normalizer, me: ProjectLookupSearchRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: ProjectLookupSearchRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    export class ProjectLookupSearchResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        projects: Array<ProjectDto>;

        request: ProjectLookupSearchRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectLookupSearchResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.projects?.length; i++)
            //{
            //    normalizer.NormalizeProject(me.projects[i], normalizer);
            //}
            me.projects = new Array<ProjectDto>();

            ProjectLookupSearchRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ProjectLookupSearchResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.projects?.length; i++)
            {
                me.projects[i] = normalizer.DenormalizeProject(me.projects[i], normalizer.dtoObjects);
            }

            ProjectLookupSearchRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Detail request, basically one item from the AugView Project, that user clicked after search was performed.
    /// </summary>
    export class ProjectLookupDetailsRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        project: ProjectDto


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectLookupDetailsRequest)
        {
            // Data objects

            normalizer.NormalizeProject(me.project, normalizer);

        }

        static Denormalize(normalizer: Normalizer, me: ProjectLookupDetailsRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.project = normalizer.DenormalizeProject(me.project, normalizer.dtoObjects);

        }

    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    export class ProjectLookupDetailsResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        project: ProjectDto

        projectTypes: Array<ProjectTypeDto>;

        request: ProjectLookupDetailsRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: ProjectLookupDetailsResponse)
        {
            // Data objects

            normalizer.NormalizeProject(me.project, normalizer);

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.projectTypes?.length; i++)
            //{
            //    normalizer.NormalizeProjectType(me.projectTypes[i], normalizer);
            //}
            me.projectTypes = new Array<ProjectTypeDto>();

            ProjectLookupDetailsRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: ProjectLookupDetailsResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.project = normalizer.DenormalizeProject(me.project, normalizer.dtoObjects);

            for (var i = 0; i < me.projectTypes?.length; i++)
            {
                me.projectTypes[i] = normalizer.DenormalizeProjectType(me.projectTypes[i], normalizer.dtoObjects);
            }

            ProjectLookupDetailsRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    export class PersonLookupFilterRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonLookupFilterRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: PersonLookupFilterRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    export class PersonLookupFilterResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        departments: Array<DepartmentDto>;

        genders: Array<GenderDto>;

        request: PersonLookupFilterRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonLookupFilterResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.departments?.length; i++)
            //{
            //    normalizer.NormalizeDepartment(me.departments[i], normalizer);
            //}
            me.departments = new Array<DepartmentDto>();

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.genders?.length; i++)
            //{
            //    normalizer.NormalizeGender(me.genders[i], normalizer);
            //}
            me.genders = new Array<GenderDto>();

            PersonLookupFilterRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: PersonLookupFilterResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.departments?.length; i++)
            {
                me.departments[i] = normalizer.DenormalizeDepartment(me.departments[i], normalizer.dtoObjects);
            }

            for (var i = 0; i < me.genders?.length; i++)
            {
                me.genders[i] = normalizer.DenormalizeGender(me.genders[i], normalizer.dtoObjects);
            }

            PersonLookupFilterRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    export class PersonLookupSearchRequest extends TransferBase {
        constructor() {
            super();

        this.quickSearch = "";

        this.personId = new IntClause();

        this.userName = new StringClause();

        this.salary = new IntClause();

        this.department_departmentId = new IntClause();

        this.department_departmentName = new StringClause();

        this.gender_genderId = new IntClause();

        this.gender_genderDescription = new StringClause();

        this.manager_personId = new IntClause();

        this.manager_userName = new StringClause();

        this.manager_salary = new IntClause();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        quickSearch: string;

        personId: IntClause;

        userName: StringClause;

        salary: IntClause;

        department_departmentId: IntClause;

        department_departmentName: StringClause;

        gender_genderId: IntClause;

        gender_genderDescription: StringClause;

        manager_personId: IntClause;

        manager_userName: StringClause;

        manager_salary: IntClause;

        
        static Normalize(normalizer: Normalizer, me: PersonLookupSearchRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: PersonLookupSearchRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    export class PersonLookupSearchResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        persons: Array<PersonDto>;

        request: PersonLookupSearchRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonLookupSearchResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.persons?.length; i++)
            //{
            //    normalizer.NormalizePerson(me.persons[i], normalizer);
            //}
            me.persons = new Array<PersonDto>();

            PersonLookupSearchRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: PersonLookupSearchResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.persons?.length; i++)
            {
                me.persons[i] = normalizer.DenormalizePerson(me.persons[i], normalizer.dtoObjects);
            }

            PersonLookupSearchRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Detail request, basically one item from the AugView Person, that user clicked after search was performed.
    /// </summary>
    export class PersonLookupDetailsRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        person: PersonDto


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonLookupDetailsRequest)
        {
            // Data objects

            normalizer.NormalizePerson(me.person, normalizer);

        }

        static Denormalize(normalizer: Normalizer, me: PersonLookupDetailsRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.person = normalizer.DenormalizePerson(me.person, normalizer.dtoObjects);

        }

    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    export class PersonLookupDetailsResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        person: PersonDto

        departments: Array<DepartmentDto>;

        genders: Array<GenderDto>;

        request: PersonLookupDetailsRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: PersonLookupDetailsResponse)
        {
            // Data objects

            normalizer.NormalizePerson(me.person, normalizer);

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.departments?.length; i++)
            //{
            //    normalizer.NormalizeDepartment(me.departments[i], normalizer);
            //}
            me.departments = new Array<DepartmentDto>();

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.genders?.length; i++)
            //{
            //    normalizer.NormalizeGender(me.genders[i], normalizer);
            //}
            me.genders = new Array<GenderDto>();

            PersonLookupDetailsRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: PersonLookupDetailsResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.person = normalizer.DenormalizePerson(me.person, normalizer.dtoObjects);

            for (var i = 0; i < me.departments?.length; i++)
            {
                me.departments[i] = normalizer.DenormalizeDepartment(me.departments[i], normalizer.dtoObjects);
            }

            for (var i = 0; i < me.genders?.length; i++)
            {
                me.genders[i] = normalizer.DenormalizeGender(me.genders[i], normalizer.dtoObjects);
            }

            PersonLookupDetailsRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    export class Project_ClientExtendedFilterRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: Project_ClientExtendedFilterRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: Project_ClientExtendedFilterRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    export class Project_ClientExtendedFilterResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        request: Project_ClientExtendedFilterRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: Project_ClientExtendedFilterResponse)
        {
            // Data objects

            Project_ClientExtendedFilterRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: Project_ClientExtendedFilterResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            Project_ClientExtendedFilterRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    export class Project_ClientExtendedSearchRequest extends TransferBase {
        constructor() {
            super();

        this.quickSearch = "";

        this.project_ClientId = new IntClause();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        quickSearch: string;

        project_ClientId: IntClause;

        
        static Normalize(normalizer: Normalizer, me: Project_ClientExtendedSearchRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: Project_ClientExtendedSearchRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    export class Project_ClientExtendedSearchResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        project_Clients: Array<Project_ClientDto>;

        request: Project_ClientExtendedSearchRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: Project_ClientExtendedSearchResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.project_Clients?.length; i++)
            //{
            //    normalizer.NormalizeProject_Client(me.project_Clients[i], normalizer);
            //}
            me.project_Clients = new Array<Project_ClientDto>();

            Project_ClientExtendedSearchRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: Project_ClientExtendedSearchResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.project_Clients?.length; i++)
            {
                me.project_Clients[i] = normalizer.DenormalizeProject_Client(me.project_Clients[i], normalizer.dtoObjects);
            }

            Project_ClientExtendedSearchRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Detail request, basically one item from the AugView Project_Client, that user clicked after search was performed.
    /// </summary>
    export class Project_ClientExtendedDetailsRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        project_Client: Project_ClientDto


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: Project_ClientExtendedDetailsRequest)
        {
            // Data objects

            normalizer.NormalizeProject_Client(me.project_Client, normalizer);

        }

        static Denormalize(normalizer: Normalizer, me: Project_ClientExtendedDetailsRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.project_Client = normalizer.DenormalizeProject_Client(me.project_Client, normalizer.dtoObjects);

        }

    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    export class Project_ClientExtendedDetailsResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        project_Client: Project_ClientDto

        request: Project_ClientExtendedDetailsRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: Project_ClientExtendedDetailsResponse)
        {
            // Data objects

            normalizer.NormalizeProject_Client(me.project_Client, normalizer);

            Project_ClientExtendedDetailsRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: Project_ClientExtendedDetailsResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.project_Client = normalizer.DenormalizeProject_Client(me.project_Client, normalizer.dtoObjects);

            Project_ClientExtendedDetailsRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    export class Project_Person_RoleExtendedFilterRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: Project_Person_RoleExtendedFilterRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: Project_Person_RoleExtendedFilterRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    export class Project_Person_RoleExtendedFilterResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        request: Project_Person_RoleExtendedFilterRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: Project_Person_RoleExtendedFilterResponse)
        {
            // Data objects

            Project_Person_RoleExtendedFilterRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: Project_Person_RoleExtendedFilterResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            Project_Person_RoleExtendedFilterRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    export class Project_Person_RoleExtendedSearchRequest extends TransferBase {
        constructor() {
            super();

        this.quickSearch = "";

        this.project_Person_RoleId = new IntClause();

        }


        // Properties to be transfered
        extraObject: any;


        // Custom properties, not to be transfered

        quickSearch: string;

        project_Person_RoleId: IntClause;

        
        static Normalize(normalizer: Normalizer, me: Project_Person_RoleExtendedSearchRequest)
        {
            // Data objects

        }

        static Denormalize(normalizer: Normalizer, me: Project_Person_RoleExtendedSearchRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

        }

    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    export class Project_Person_RoleExtendedSearchResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        project_Person_Roles: Array<Project_Person_RoleDto>;

        request: Project_Person_RoleExtendedSearchRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: Project_Person_RoleExtendedSearchResponse)
        {
            // Data objects

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.project_Person_Roles?.length; i++)
            //{
            //    normalizer.NormalizeProject_Person_Role(me.project_Person_Roles[i], normalizer);
            //}
            me.project_Person_Roles = new Array<Project_Person_RoleDto>();

            Project_Person_RoleExtendedSearchRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: Project_Person_RoleExtendedSearchResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            for (var i = 0; i < me.project_Person_Roles?.length; i++)
            {
                me.project_Person_Roles[i] = normalizer.DenormalizeProject_Person_Role(me.project_Person_Roles[i], normalizer.dtoObjects);
            }

            Project_Person_RoleExtendedSearchRequest.Denormalize(normalizer, me.request);

        }

    }

    /// <summary>
    /// Detail request, basically one item from the AugView Project_Person_Role, that user clicked after search was performed.
    /// </summary>
    export class Project_Person_RoleExtendedDetailsRequest extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        project_Person_Role: Project_Person_RoleDto


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: Project_Person_RoleExtendedDetailsRequest)
        {
            // Data objects

            normalizer.NormalizeProject_Person_Role(me.project_Person_Role, normalizer);

        }

        static Denormalize(normalizer: Normalizer, me: Project_Person_RoleExtendedDetailsRequest)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.project_Person_Role = normalizer.DenormalizeProject_Person_Role(me.project_Person_Role, normalizer.dtoObjects);

        }

    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    export class Project_Person_RoleExtendedDetailsResponse extends TransferBase {
        constructor() {
            super();

        }


        // Properties to be transfered
        extraObject: any;

        project_Person_Role: Project_Person_RoleDto

        departments: Array<DepartmentDto>;

        genders: Array<GenderDto>;

        roles: Array<RoleDto>;

        request: Project_Person_RoleExtendedDetailsRequest


        // Custom properties, not to be transfered

        
        static Normalize(normalizer: Normalizer, me: Project_Person_RoleExtendedDetailsResponse)
        {
            // Data objects

            normalizer.NormalizeProject_Person_Role(me.project_Person_Role, normalizer);

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.departments?.length; i++)
            //{
            //    normalizer.NormalizeDepartment(me.departments[i], normalizer);
            //}
            me.departments = new Array<DepartmentDto>();

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.genders?.length; i++)
            //{
            //    normalizer.NormalizeGender(me.genders[i], normalizer);
            //}
            me.genders = new Array<GenderDto>();

            // These are just going back to server.. null them out.
            //for (var i = 0; i < me.roles?.length; i++)
            //{
            //    normalizer.NormalizeRole(me.roles[i], normalizer);
            //}
            me.roles = new Array<RoleDto>();

            Project_Person_RoleExtendedDetailsRequest.Normalize(normalizer, me.request);

        }

        static Denormalize(normalizer: Normalizer, me: Project_Person_RoleExtendedDetailsResponse)
        {
            normalizer.CastDtoObjects(normalizer.dtoObjects);
            
            // Data objects

            me.project_Person_Role = normalizer.DenormalizeProject_Person_Role(me.project_Person_Role, normalizer.dtoObjects);

            for (var i = 0; i < me.departments?.length; i++)
            {
                me.departments[i] = normalizer.DenormalizeDepartment(me.departments[i], normalizer.dtoObjects);
            }

            for (var i = 0; i < me.genders?.length; i++)
            {
                me.genders[i] = normalizer.DenormalizeGender(me.genders[i], normalizer.dtoObjects);
            }

            for (var i = 0; i < me.roles?.length; i++)
            {
                me.roles[i] = normalizer.DenormalizeRole(me.roles[i], normalizer.dtoObjects);
            }

            Project_Person_RoleExtendedDetailsRequest.Denormalize(normalizer, me.request);

        }

    }


export class Fetchers {
    ApiBaseUrl: string = "https://localhost:44326/";

    IsControlDown: boolean = false;
    DebugMessages: Array<string>;

    Debug(name: string) {
        if (!this.IsControlDown) return;
        console.log("DEBUG: " + name);
        if (!this.DebugMessages) this.DebugMessages = new Array<string>();
        this.DebugMessages.push(name);
        //setTimeout("this.DebugDone", 100);
        var that = this;
        setTimeout(function () {
            that.DebugDone();
        }, 20);
    }

    DebugDone() {
        if (!this.DebugMessages) return;
        var s: string = "";
        for (var i = 0; i < this.DebugMessages.length; i++) {
            s += this.DebugMessages[i] + " - ";
        }
        this.DebugMessages = null;
        console.log("Tutti: " + s);
        navigator.clipboard.writeText(s);
    }

    async CallRestPost(method: any, obj: any) {
        var url = this.ApiBaseUrl + method;

        const f = await fetch(url, {
            method: 'POST',
            body: JSON.stringify(obj),
            headers: {
                'Content-Type': 'application/json; charset=utf-8'
            }
        });

        let r = await f.json();
        return r;
    }



     // ************** Project ******************
 
    async GetProjectFilter(projectFilterRequest: ProjectFilterRequest): Promise<ProjectFilterResponse> {
        projectFilterRequest.userAuthentication = userAuthentication;
        projectFilterRequest.normalizer = new Normalizer();
        ProjectFilterRequest.Normalize(projectFilterRequest.normalizer, projectFilterRequest);



        for (var i = 0; i < projectFilterRequest.normalizer.dtoObjects.length; i++) {
            projectFilterRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(projectFilterRequest.normalizer.dtoObjects[i].object);
            projectFilterRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getprojectfilter", projectFilterRequest);
        var resp = new ProjectFilterResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ProjectFilterResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetProjectSearch(projectSearchRequest: ProjectSearchRequest): Promise<ProjectSearchResponse> {
        projectSearchRequest.userAuthentication = userAuthentication;
        projectSearchRequest.normalizer = new Normalizer();
        ProjectSearchRequest.Normalize(projectSearchRequest.normalizer, projectSearchRequest);



        for (var i = 0; i < projectSearchRequest.normalizer.dtoObjects.length; i++) {
            projectSearchRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(projectSearchRequest.normalizer.dtoObjects[i].object);
            projectSearchRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getprojectsearch", projectSearchRequest);
        var resp = new ProjectSearchResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ProjectSearchResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetProjectDetails(projectDetailsRequest: ProjectDetailsRequest): Promise<ProjectDetailsResponse> {
        projectDetailsRequest.userAuthentication = userAuthentication;
        projectDetailsRequest.normalizer = new Normalizer();
        ProjectDetailsRequest.Normalize(projectDetailsRequest.normalizer, projectDetailsRequest);



        for (var i = 0; i < projectDetailsRequest.normalizer.dtoObjects.length; i++) {
            projectDetailsRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(projectDetailsRequest.normalizer.dtoObjects[i].object);
            projectDetailsRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getprojectdetails", projectDetailsRequest);
        var resp = new ProjectDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ProjectDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async SaveProjectDetails(projectDetailsResponse: ProjectDetailsResponse): Promise<ProjectDetailsResponse> {
        projectDetailsResponse.userAuthentication = userAuthentication;
        projectDetailsResponse.normalizer = new Normalizer();
        ProjectDetailsResponse.Normalize(projectDetailsResponse.normalizer, projectDetailsResponse);


        for (var i = 0; i < projectDetailsResponse.normalizer.dtoObjects.length; i++) {
            var obj = projectDetailsResponse.normalizer.dtoObjects[i];
            var key = obj.key;
            // TODO: Kolla ifall vi verkligen ändrats...
            //var objOrig = originalNormalizer.dtoObjects.find(p => p.key === key);
            obj.object.isTainted = true;
        }


        for (var i = 0; i < projectDetailsResponse.normalizer.dtoObjects.length; i++) {
            projectDetailsResponse.normalizer.dtoObjects[i].jansson = JSON.stringify(projectDetailsResponse.normalizer.dtoObjects[i].object);
            projectDetailsResponse.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/saveprojectdetails", projectDetailsResponse);
        var resp = new ProjectDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ProjectDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }

     // ************** PersonMini ******************
 
    async GetPersonMiniFilter(personMiniFilterRequest: PersonMiniFilterRequest): Promise<PersonMiniFilterResponse> {
        personMiniFilterRequest.userAuthentication = userAuthentication;
        personMiniFilterRequest.normalizer = new Normalizer();
        PersonMiniFilterRequest.Normalize(personMiniFilterRequest.normalizer, personMiniFilterRequest);



        for (var i = 0; i < personMiniFilterRequest.normalizer.dtoObjects.length; i++) {
            personMiniFilterRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(personMiniFilterRequest.normalizer.dtoObjects[i].object);
            personMiniFilterRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getpersonminifilter", personMiniFilterRequest);
        var resp = new PersonMiniFilterResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        PersonMiniFilterResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetPersonMiniSearch(personMiniSearchRequest: PersonMiniSearchRequest): Promise<PersonMiniSearchResponse> {
        personMiniSearchRequest.userAuthentication = userAuthentication;
        personMiniSearchRequest.normalizer = new Normalizer();
        PersonMiniSearchRequest.Normalize(personMiniSearchRequest.normalizer, personMiniSearchRequest);



        for (var i = 0; i < personMiniSearchRequest.normalizer.dtoObjects.length; i++) {
            personMiniSearchRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(personMiniSearchRequest.normalizer.dtoObjects[i].object);
            personMiniSearchRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getpersonminisearch", personMiniSearchRequest);
        var resp = new PersonMiniSearchResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        PersonMiniSearchResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetPersonMiniDetails(personMiniDetailsRequest: PersonMiniDetailsRequest): Promise<PersonMiniDetailsResponse> {
        personMiniDetailsRequest.userAuthentication = userAuthentication;
        personMiniDetailsRequest.normalizer = new Normalizer();
        PersonMiniDetailsRequest.Normalize(personMiniDetailsRequest.normalizer, personMiniDetailsRequest);



        for (var i = 0; i < personMiniDetailsRequest.normalizer.dtoObjects.length; i++) {
            personMiniDetailsRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(personMiniDetailsRequest.normalizer.dtoObjects[i].object);
            personMiniDetailsRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getpersonminidetails", personMiniDetailsRequest);
        var resp = new PersonMiniDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        PersonMiniDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async SavePersonMiniDetails(personMiniDetailsResponse: PersonMiniDetailsResponse): Promise<PersonMiniDetailsResponse> {
        personMiniDetailsResponse.userAuthentication = userAuthentication;
        personMiniDetailsResponse.normalizer = new Normalizer();
        PersonMiniDetailsResponse.Normalize(personMiniDetailsResponse.normalizer, personMiniDetailsResponse);


        for (var i = 0; i < personMiniDetailsResponse.normalizer.dtoObjects.length; i++) {
            var obj = personMiniDetailsResponse.normalizer.dtoObjects[i];
            var key = obj.key;
            // TODO: Kolla ifall vi verkligen ändrats...
            //var objOrig = originalNormalizer.dtoObjects.find(p => p.key === key);
            obj.object.isTainted = true;
        }


        for (var i = 0; i < personMiniDetailsResponse.normalizer.dtoObjects.length; i++) {
            personMiniDetailsResponse.normalizer.dtoObjects[i].jansson = JSON.stringify(personMiniDetailsResponse.normalizer.dtoObjects[i].object);
            personMiniDetailsResponse.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/savepersonminidetails", personMiniDetailsResponse);
        var resp = new PersonMiniDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        PersonMiniDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }

     // ************** Person ******************
 
    async GetPersonFilter(personFilterRequest: PersonFilterRequest): Promise<PersonFilterResponse> {
        personFilterRequest.userAuthentication = userAuthentication;
        personFilterRequest.normalizer = new Normalizer();
        PersonFilterRequest.Normalize(personFilterRequest.normalizer, personFilterRequest);



        for (var i = 0; i < personFilterRequest.normalizer.dtoObjects.length; i++) {
            personFilterRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(personFilterRequest.normalizer.dtoObjects[i].object);
            personFilterRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getpersonfilter", personFilterRequest);
        var resp = new PersonFilterResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        PersonFilterResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetPersonSearch(personSearchRequest: PersonSearchRequest): Promise<PersonSearchResponse> {
        personSearchRequest.userAuthentication = userAuthentication;
        personSearchRequest.normalizer = new Normalizer();
        PersonSearchRequest.Normalize(personSearchRequest.normalizer, personSearchRequest);



        for (var i = 0; i < personSearchRequest.normalizer.dtoObjects.length; i++) {
            personSearchRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(personSearchRequest.normalizer.dtoObjects[i].object);
            personSearchRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getpersonsearch", personSearchRequest);
        var resp = new PersonSearchResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        PersonSearchResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetPersonDetails(personDetailsRequest: PersonDetailsRequest): Promise<PersonDetailsResponse> {
        personDetailsRequest.userAuthentication = userAuthentication;
        personDetailsRequest.normalizer = new Normalizer();
        PersonDetailsRequest.Normalize(personDetailsRequest.normalizer, personDetailsRequest);



        for (var i = 0; i < personDetailsRequest.normalizer.dtoObjects.length; i++) {
            personDetailsRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(personDetailsRequest.normalizer.dtoObjects[i].object);
            personDetailsRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getpersondetails", personDetailsRequest);
        var resp = new PersonDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        PersonDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async SavePersonDetails(personDetailsResponse: PersonDetailsResponse): Promise<PersonDetailsResponse> {
        personDetailsResponse.userAuthentication = userAuthentication;
        personDetailsResponse.normalizer = new Normalizer();
        PersonDetailsResponse.Normalize(personDetailsResponse.normalizer, personDetailsResponse);


        for (var i = 0; i < personDetailsResponse.normalizer.dtoObjects.length; i++) {
            var obj = personDetailsResponse.normalizer.dtoObjects[i];
            var key = obj.key;
            // TODO: Kolla ifall vi verkligen ändrats...
            //var objOrig = originalNormalizer.dtoObjects.find(p => p.key === key);
            obj.object.isTainted = true;
        }


        for (var i = 0; i < personDetailsResponse.normalizer.dtoObjects.length; i++) {
            personDetailsResponse.normalizer.dtoObjects[i].jansson = JSON.stringify(personDetailsResponse.normalizer.dtoObjects[i].object);
            personDetailsResponse.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/savepersondetails", personDetailsResponse);
        var resp = new PersonDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        PersonDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }

     // ************** Client ******************
         // No fetcher... Client / Get / Filter
    async GetClientSearch(clientSearchRequest: ClientSearchRequest): Promise<ClientSearchResponse> {
        clientSearchRequest.userAuthentication = userAuthentication;
        clientSearchRequest.normalizer = new Normalizer();
        ClientSearchRequest.Normalize(clientSearchRequest.normalizer, clientSearchRequest);



        for (var i = 0; i < clientSearchRequest.normalizer.dtoObjects.length; i++) {
            clientSearchRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(clientSearchRequest.normalizer.dtoObjects[i].object);
            clientSearchRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getclientsearch", clientSearchRequest);
        var resp = new ClientSearchResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ClientSearchResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetClientDetails(clientDetailsRequest: ClientDetailsRequest): Promise<ClientDetailsResponse> {
        clientDetailsRequest.userAuthentication = userAuthentication;
        clientDetailsRequest.normalizer = new Normalizer();
        ClientDetailsRequest.Normalize(clientDetailsRequest.normalizer, clientDetailsRequest);



        for (var i = 0; i < clientDetailsRequest.normalizer.dtoObjects.length; i++) {
            clientDetailsRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(clientDetailsRequest.normalizer.dtoObjects[i].object);
            clientDetailsRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getclientdetails", clientDetailsRequest);
        var resp = new ClientDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ClientDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async SaveClientDetails(clientDetailsResponse: ClientDetailsResponse): Promise<ClientDetailsResponse> {
        clientDetailsResponse.userAuthentication = userAuthentication;
        clientDetailsResponse.normalizer = new Normalizer();
        ClientDetailsResponse.Normalize(clientDetailsResponse.normalizer, clientDetailsResponse);


        for (var i = 0; i < clientDetailsResponse.normalizer.dtoObjects.length; i++) {
            var obj = clientDetailsResponse.normalizer.dtoObjects[i];
            var key = obj.key;
            // TODO: Kolla ifall vi verkligen ändrats...
            //var objOrig = originalNormalizer.dtoObjects.find(p => p.key === key);
            obj.object.isTainted = true;
        }


        for (var i = 0; i < clientDetailsResponse.normalizer.dtoObjects.length; i++) {
            clientDetailsResponse.normalizer.dtoObjects[i].jansson = JSON.stringify(clientDetailsResponse.normalizer.dtoObjects[i].object);
            clientDetailsResponse.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/saveclientdetails", clientDetailsResponse);
        var resp = new ClientDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ClientDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }

     // ************** ClientLookup ******************
         // No fetcher... ClientLookup / Get / Filter
    async GetClientLookupSearch(clientLookupSearchRequest: ClientLookupSearchRequest): Promise<ClientLookupSearchResponse> {
        clientLookupSearchRequest.userAuthentication = userAuthentication;
        clientLookupSearchRequest.normalizer = new Normalizer();
        ClientLookupSearchRequest.Normalize(clientLookupSearchRequest.normalizer, clientLookupSearchRequest);



        for (var i = 0; i < clientLookupSearchRequest.normalizer.dtoObjects.length; i++) {
            clientLookupSearchRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(clientLookupSearchRequest.normalizer.dtoObjects[i].object);
            clientLookupSearchRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getclientlookupsearch", clientLookupSearchRequest);
        var resp = new ClientLookupSearchResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ClientLookupSearchResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetClientLookupDetails(clientLookupDetailsRequest: ClientLookupDetailsRequest): Promise<ClientLookupDetailsResponse> {
        clientLookupDetailsRequest.userAuthentication = userAuthentication;
        clientLookupDetailsRequest.normalizer = new Normalizer();
        ClientLookupDetailsRequest.Normalize(clientLookupDetailsRequest.normalizer, clientLookupDetailsRequest);



        for (var i = 0; i < clientLookupDetailsRequest.normalizer.dtoObjects.length; i++) {
            clientLookupDetailsRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(clientLookupDetailsRequest.normalizer.dtoObjects[i].object);
            clientLookupDetailsRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getclientlookupdetails", clientLookupDetailsRequest);
        var resp = new ClientLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ClientLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async SaveClientLookupDetails(clientLookupDetailsResponse: ClientLookupDetailsResponse): Promise<ClientLookupDetailsResponse> {
        clientLookupDetailsResponse.userAuthentication = userAuthentication;
        clientLookupDetailsResponse.normalizer = new Normalizer();
        ClientLookupDetailsResponse.Normalize(clientLookupDetailsResponse.normalizer, clientLookupDetailsResponse);


        for (var i = 0; i < clientLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            var obj = clientLookupDetailsResponse.normalizer.dtoObjects[i];
            var key = obj.key;
            // TODO: Kolla ifall vi verkligen ändrats...
            //var objOrig = originalNormalizer.dtoObjects.find(p => p.key === key);
            obj.object.isTainted = true;
        }


        for (var i = 0; i < clientLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            clientLookupDetailsResponse.normalizer.dtoObjects[i].jansson = JSON.stringify(clientLookupDetailsResponse.normalizer.dtoObjects[i].object);
            clientLookupDetailsResponse.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/saveclientlookupdetails", clientLookupDetailsResponse);
        var resp = new ClientLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ClientLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }

     // ************** GenderLookup ******************
         // No fetcher... GenderLookup / Get / Filter
    async GetGenderLookupSearch(genderLookupSearchRequest: GenderLookupSearchRequest): Promise<GenderLookupSearchResponse> {
        genderLookupSearchRequest.userAuthentication = userAuthentication;
        genderLookupSearchRequest.normalizer = new Normalizer();
        GenderLookupSearchRequest.Normalize(genderLookupSearchRequest.normalizer, genderLookupSearchRequest);



        for (var i = 0; i < genderLookupSearchRequest.normalizer.dtoObjects.length; i++) {
            genderLookupSearchRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(genderLookupSearchRequest.normalizer.dtoObjects[i].object);
            genderLookupSearchRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getgenderlookupsearch", genderLookupSearchRequest);
        var resp = new GenderLookupSearchResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        GenderLookupSearchResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetGenderLookupDetails(genderLookupDetailsRequest: GenderLookupDetailsRequest): Promise<GenderLookupDetailsResponse> {
        genderLookupDetailsRequest.userAuthentication = userAuthentication;
        genderLookupDetailsRequest.normalizer = new Normalizer();
        GenderLookupDetailsRequest.Normalize(genderLookupDetailsRequest.normalizer, genderLookupDetailsRequest);



        for (var i = 0; i < genderLookupDetailsRequest.normalizer.dtoObjects.length; i++) {
            genderLookupDetailsRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(genderLookupDetailsRequest.normalizer.dtoObjects[i].object);
            genderLookupDetailsRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getgenderlookupdetails", genderLookupDetailsRequest);
        var resp = new GenderLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        GenderLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async SaveGenderLookupDetails(genderLookupDetailsResponse: GenderLookupDetailsResponse): Promise<GenderLookupDetailsResponse> {
        genderLookupDetailsResponse.userAuthentication = userAuthentication;
        genderLookupDetailsResponse.normalizer = new Normalizer();
        GenderLookupDetailsResponse.Normalize(genderLookupDetailsResponse.normalizer, genderLookupDetailsResponse);


        for (var i = 0; i < genderLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            var obj = genderLookupDetailsResponse.normalizer.dtoObjects[i];
            var key = obj.key;
            // TODO: Kolla ifall vi verkligen ändrats...
            //var objOrig = originalNormalizer.dtoObjects.find(p => p.key === key);
            obj.object.isTainted = true;
        }


        for (var i = 0; i < genderLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            genderLookupDetailsResponse.normalizer.dtoObjects[i].jansson = JSON.stringify(genderLookupDetailsResponse.normalizer.dtoObjects[i].object);
            genderLookupDetailsResponse.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/savegenderlookupdetails", genderLookupDetailsResponse);
        var resp = new GenderLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        GenderLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }

     // ************** ProjectTypeLookup ******************
         // No fetcher... ProjectTypeLookup / Get / Filter
    async GetProjectTypeLookupSearch(projectTypeLookupSearchRequest: ProjectTypeLookupSearchRequest): Promise<ProjectTypeLookupSearchResponse> {
        projectTypeLookupSearchRequest.userAuthentication = userAuthentication;
        projectTypeLookupSearchRequest.normalizer = new Normalizer();
        ProjectTypeLookupSearchRequest.Normalize(projectTypeLookupSearchRequest.normalizer, projectTypeLookupSearchRequest);



        for (var i = 0; i < projectTypeLookupSearchRequest.normalizer.dtoObjects.length; i++) {
            projectTypeLookupSearchRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(projectTypeLookupSearchRequest.normalizer.dtoObjects[i].object);
            projectTypeLookupSearchRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getprojecttypelookupsearch", projectTypeLookupSearchRequest);
        var resp = new ProjectTypeLookupSearchResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ProjectTypeLookupSearchResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetProjectTypeLookupDetails(projectTypeLookupDetailsRequest: ProjectTypeLookupDetailsRequest): Promise<ProjectTypeLookupDetailsResponse> {
        projectTypeLookupDetailsRequest.userAuthentication = userAuthentication;
        projectTypeLookupDetailsRequest.normalizer = new Normalizer();
        ProjectTypeLookupDetailsRequest.Normalize(projectTypeLookupDetailsRequest.normalizer, projectTypeLookupDetailsRequest);



        for (var i = 0; i < projectTypeLookupDetailsRequest.normalizer.dtoObjects.length; i++) {
            projectTypeLookupDetailsRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(projectTypeLookupDetailsRequest.normalizer.dtoObjects[i].object);
            projectTypeLookupDetailsRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getprojecttypelookupdetails", projectTypeLookupDetailsRequest);
        var resp = new ProjectTypeLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ProjectTypeLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async SaveProjectTypeLookupDetails(projectTypeLookupDetailsResponse: ProjectTypeLookupDetailsResponse): Promise<ProjectTypeLookupDetailsResponse> {
        projectTypeLookupDetailsResponse.userAuthentication = userAuthentication;
        projectTypeLookupDetailsResponse.normalizer = new Normalizer();
        ProjectTypeLookupDetailsResponse.Normalize(projectTypeLookupDetailsResponse.normalizer, projectTypeLookupDetailsResponse);


        for (var i = 0; i < projectTypeLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            var obj = projectTypeLookupDetailsResponse.normalizer.dtoObjects[i];
            var key = obj.key;
            // TODO: Kolla ifall vi verkligen ändrats...
            //var objOrig = originalNormalizer.dtoObjects.find(p => p.key === key);
            obj.object.isTainted = true;
        }


        for (var i = 0; i < projectTypeLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            projectTypeLookupDetailsResponse.normalizer.dtoObjects[i].jansson = JSON.stringify(projectTypeLookupDetailsResponse.normalizer.dtoObjects[i].object);
            projectTypeLookupDetailsResponse.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/saveprojecttypelookupdetails", projectTypeLookupDetailsResponse);
        var resp = new ProjectTypeLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ProjectTypeLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }

     // ************** DepartmentLookup ******************
         // No fetcher... DepartmentLookup / Get / Filter
    async GetDepartmentLookupSearch(departmentLookupSearchRequest: DepartmentLookupSearchRequest): Promise<DepartmentLookupSearchResponse> {
        departmentLookupSearchRequest.userAuthentication = userAuthentication;
        departmentLookupSearchRequest.normalizer = new Normalizer();
        DepartmentLookupSearchRequest.Normalize(departmentLookupSearchRequest.normalizer, departmentLookupSearchRequest);



        for (var i = 0; i < departmentLookupSearchRequest.normalizer.dtoObjects.length; i++) {
            departmentLookupSearchRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(departmentLookupSearchRequest.normalizer.dtoObjects[i].object);
            departmentLookupSearchRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getdepartmentlookupsearch", departmentLookupSearchRequest);
        var resp = new DepartmentLookupSearchResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        DepartmentLookupSearchResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetDepartmentLookupDetails(departmentLookupDetailsRequest: DepartmentLookupDetailsRequest): Promise<DepartmentLookupDetailsResponse> {
        departmentLookupDetailsRequest.userAuthentication = userAuthentication;
        departmentLookupDetailsRequest.normalizer = new Normalizer();
        DepartmentLookupDetailsRequest.Normalize(departmentLookupDetailsRequest.normalizer, departmentLookupDetailsRequest);



        for (var i = 0; i < departmentLookupDetailsRequest.normalizer.dtoObjects.length; i++) {
            departmentLookupDetailsRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(departmentLookupDetailsRequest.normalizer.dtoObjects[i].object);
            departmentLookupDetailsRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getdepartmentlookupdetails", departmentLookupDetailsRequest);
        var resp = new DepartmentLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        DepartmentLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async SaveDepartmentLookupDetails(departmentLookupDetailsResponse: DepartmentLookupDetailsResponse): Promise<DepartmentLookupDetailsResponse> {
        departmentLookupDetailsResponse.userAuthentication = userAuthentication;
        departmentLookupDetailsResponse.normalizer = new Normalizer();
        DepartmentLookupDetailsResponse.Normalize(departmentLookupDetailsResponse.normalizer, departmentLookupDetailsResponse);


        for (var i = 0; i < departmentLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            var obj = departmentLookupDetailsResponse.normalizer.dtoObjects[i];
            var key = obj.key;
            // TODO: Kolla ifall vi verkligen ändrats...
            //var objOrig = originalNormalizer.dtoObjects.find(p => p.key === key);
            obj.object.isTainted = true;
        }


        for (var i = 0; i < departmentLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            departmentLookupDetailsResponse.normalizer.dtoObjects[i].jansson = JSON.stringify(departmentLookupDetailsResponse.normalizer.dtoObjects[i].object);
            departmentLookupDetailsResponse.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/savedepartmentlookupdetails", departmentLookupDetailsResponse);
        var resp = new DepartmentLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        DepartmentLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }

     // ************** RoleLookup ******************
         // No fetcher... RoleLookup / Get / Filter
    async GetRoleLookupSearch(roleLookupSearchRequest: RoleLookupSearchRequest): Promise<RoleLookupSearchResponse> {
        roleLookupSearchRequest.userAuthentication = userAuthentication;
        roleLookupSearchRequest.normalizer = new Normalizer();
        RoleLookupSearchRequest.Normalize(roleLookupSearchRequest.normalizer, roleLookupSearchRequest);



        for (var i = 0; i < roleLookupSearchRequest.normalizer.dtoObjects.length; i++) {
            roleLookupSearchRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(roleLookupSearchRequest.normalizer.dtoObjects[i].object);
            roleLookupSearchRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getrolelookupsearch", roleLookupSearchRequest);
        var resp = new RoleLookupSearchResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        RoleLookupSearchResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetRoleLookupDetails(roleLookupDetailsRequest: RoleLookupDetailsRequest): Promise<RoleLookupDetailsResponse> {
        roleLookupDetailsRequest.userAuthentication = userAuthentication;
        roleLookupDetailsRequest.normalizer = new Normalizer();
        RoleLookupDetailsRequest.Normalize(roleLookupDetailsRequest.normalizer, roleLookupDetailsRequest);



        for (var i = 0; i < roleLookupDetailsRequest.normalizer.dtoObjects.length; i++) {
            roleLookupDetailsRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(roleLookupDetailsRequest.normalizer.dtoObjects[i].object);
            roleLookupDetailsRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getrolelookupdetails", roleLookupDetailsRequest);
        var resp = new RoleLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        RoleLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async SaveRoleLookupDetails(roleLookupDetailsResponse: RoleLookupDetailsResponse): Promise<RoleLookupDetailsResponse> {
        roleLookupDetailsResponse.userAuthentication = userAuthentication;
        roleLookupDetailsResponse.normalizer = new Normalizer();
        RoleLookupDetailsResponse.Normalize(roleLookupDetailsResponse.normalizer, roleLookupDetailsResponse);


        for (var i = 0; i < roleLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            var obj = roleLookupDetailsResponse.normalizer.dtoObjects[i];
            var key = obj.key;
            // TODO: Kolla ifall vi verkligen ändrats...
            //var objOrig = originalNormalizer.dtoObjects.find(p => p.key === key);
            obj.object.isTainted = true;
        }


        for (var i = 0; i < roleLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            roleLookupDetailsResponse.normalizer.dtoObjects[i].jansson = JSON.stringify(roleLookupDetailsResponse.normalizer.dtoObjects[i].object);
            roleLookupDetailsResponse.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/saverolelookupdetails", roleLookupDetailsResponse);
        var resp = new RoleLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        RoleLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }

     // ************** ProjectLookup ******************
 
    async GetProjectLookupFilter(projectLookupFilterRequest: ProjectLookupFilterRequest): Promise<ProjectLookupFilterResponse> {
        projectLookupFilterRequest.userAuthentication = userAuthentication;
        projectLookupFilterRequest.normalizer = new Normalizer();
        ProjectLookupFilterRequest.Normalize(projectLookupFilterRequest.normalizer, projectLookupFilterRequest);



        for (var i = 0; i < projectLookupFilterRequest.normalizer.dtoObjects.length; i++) {
            projectLookupFilterRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(projectLookupFilterRequest.normalizer.dtoObjects[i].object);
            projectLookupFilterRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getprojectlookupfilter", projectLookupFilterRequest);
        var resp = new ProjectLookupFilterResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ProjectLookupFilterResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetProjectLookupSearch(projectLookupSearchRequest: ProjectLookupSearchRequest): Promise<ProjectLookupSearchResponse> {
        projectLookupSearchRequest.userAuthentication = userAuthentication;
        projectLookupSearchRequest.normalizer = new Normalizer();
        ProjectLookupSearchRequest.Normalize(projectLookupSearchRequest.normalizer, projectLookupSearchRequest);



        for (var i = 0; i < projectLookupSearchRequest.normalizer.dtoObjects.length; i++) {
            projectLookupSearchRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(projectLookupSearchRequest.normalizer.dtoObjects[i].object);
            projectLookupSearchRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getprojectlookupsearch", projectLookupSearchRequest);
        var resp = new ProjectLookupSearchResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ProjectLookupSearchResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetProjectLookupDetails(projectLookupDetailsRequest: ProjectLookupDetailsRequest): Promise<ProjectLookupDetailsResponse> {
        projectLookupDetailsRequest.userAuthentication = userAuthentication;
        projectLookupDetailsRequest.normalizer = new Normalizer();
        ProjectLookupDetailsRequest.Normalize(projectLookupDetailsRequest.normalizer, projectLookupDetailsRequest);



        for (var i = 0; i < projectLookupDetailsRequest.normalizer.dtoObjects.length; i++) {
            projectLookupDetailsRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(projectLookupDetailsRequest.normalizer.dtoObjects[i].object);
            projectLookupDetailsRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getprojectlookupdetails", projectLookupDetailsRequest);
        var resp = new ProjectLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ProjectLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async SaveProjectLookupDetails(projectLookupDetailsResponse: ProjectLookupDetailsResponse): Promise<ProjectLookupDetailsResponse> {
        projectLookupDetailsResponse.userAuthentication = userAuthentication;
        projectLookupDetailsResponse.normalizer = new Normalizer();
        ProjectLookupDetailsResponse.Normalize(projectLookupDetailsResponse.normalizer, projectLookupDetailsResponse);


        for (var i = 0; i < projectLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            var obj = projectLookupDetailsResponse.normalizer.dtoObjects[i];
            var key = obj.key;
            // TODO: Kolla ifall vi verkligen ändrats...
            //var objOrig = originalNormalizer.dtoObjects.find(p => p.key === key);
            obj.object.isTainted = true;
        }


        for (var i = 0; i < projectLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            projectLookupDetailsResponse.normalizer.dtoObjects[i].jansson = JSON.stringify(projectLookupDetailsResponse.normalizer.dtoObjects[i].object);
            projectLookupDetailsResponse.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/saveprojectlookupdetails", projectLookupDetailsResponse);
        var resp = new ProjectLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        ProjectLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }

     // ************** PersonLookup ******************
 
    async GetPersonLookupFilter(personLookupFilterRequest: PersonLookupFilterRequest): Promise<PersonLookupFilterResponse> {
        personLookupFilterRequest.userAuthentication = userAuthentication;
        personLookupFilterRequest.normalizer = new Normalizer();
        PersonLookupFilterRequest.Normalize(personLookupFilterRequest.normalizer, personLookupFilterRequest);



        for (var i = 0; i < personLookupFilterRequest.normalizer.dtoObjects.length; i++) {
            personLookupFilterRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(personLookupFilterRequest.normalizer.dtoObjects[i].object);
            personLookupFilterRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getpersonlookupfilter", personLookupFilterRequest);
        var resp = new PersonLookupFilterResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        PersonLookupFilterResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetPersonLookupSearch(personLookupSearchRequest: PersonLookupSearchRequest): Promise<PersonLookupSearchResponse> {
        personLookupSearchRequest.userAuthentication = userAuthentication;
        personLookupSearchRequest.normalizer = new Normalizer();
        PersonLookupSearchRequest.Normalize(personLookupSearchRequest.normalizer, personLookupSearchRequest);



        for (var i = 0; i < personLookupSearchRequest.normalizer.dtoObjects.length; i++) {
            personLookupSearchRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(personLookupSearchRequest.normalizer.dtoObjects[i].object);
            personLookupSearchRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getpersonlookupsearch", personLookupSearchRequest);
        var resp = new PersonLookupSearchResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        PersonLookupSearchResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetPersonLookupDetails(personLookupDetailsRequest: PersonLookupDetailsRequest): Promise<PersonLookupDetailsResponse> {
        personLookupDetailsRequest.userAuthentication = userAuthentication;
        personLookupDetailsRequest.normalizer = new Normalizer();
        PersonLookupDetailsRequest.Normalize(personLookupDetailsRequest.normalizer, personLookupDetailsRequest);



        for (var i = 0; i < personLookupDetailsRequest.normalizer.dtoObjects.length; i++) {
            personLookupDetailsRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(personLookupDetailsRequest.normalizer.dtoObjects[i].object);
            personLookupDetailsRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getpersonlookupdetails", personLookupDetailsRequest);
        var resp = new PersonLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        PersonLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async SavePersonLookupDetails(personLookupDetailsResponse: PersonLookupDetailsResponse): Promise<PersonLookupDetailsResponse> {
        personLookupDetailsResponse.userAuthentication = userAuthentication;
        personLookupDetailsResponse.normalizer = new Normalizer();
        PersonLookupDetailsResponse.Normalize(personLookupDetailsResponse.normalizer, personLookupDetailsResponse);


        for (var i = 0; i < personLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            var obj = personLookupDetailsResponse.normalizer.dtoObjects[i];
            var key = obj.key;
            // TODO: Kolla ifall vi verkligen ändrats...
            //var objOrig = originalNormalizer.dtoObjects.find(p => p.key === key);
            obj.object.isTainted = true;
        }


        for (var i = 0; i < personLookupDetailsResponse.normalizer.dtoObjects.length; i++) {
            personLookupDetailsResponse.normalizer.dtoObjects[i].jansson = JSON.stringify(personLookupDetailsResponse.normalizer.dtoObjects[i].object);
            personLookupDetailsResponse.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/savepersonlookupdetails", personLookupDetailsResponse);
        var resp = new PersonLookupDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        PersonLookupDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }

     // ************** Project_ClientExtended ******************
         // No fetcher... Project_ClientExtended / Get / Filter
    async GetProject_ClientExtendedSearch(project_ClientExtendedSearchRequest: Project_ClientExtendedSearchRequest): Promise<Project_ClientExtendedSearchResponse> {
        project_ClientExtendedSearchRequest.userAuthentication = userAuthentication;
        project_ClientExtendedSearchRequest.normalizer = new Normalizer();
        Project_ClientExtendedSearchRequest.Normalize(project_ClientExtendedSearchRequest.normalizer, project_ClientExtendedSearchRequest);



        for (var i = 0; i < project_ClientExtendedSearchRequest.normalizer.dtoObjects.length; i++) {
            project_ClientExtendedSearchRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(project_ClientExtendedSearchRequest.normalizer.dtoObjects[i].object);
            project_ClientExtendedSearchRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getproject_clientextendedsearch", project_ClientExtendedSearchRequest);
        var resp = new Project_ClientExtendedSearchResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        Project_ClientExtendedSearchResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetProject_ClientExtendedDetails(project_ClientExtendedDetailsRequest: Project_ClientExtendedDetailsRequest): Promise<Project_ClientExtendedDetailsResponse> {
        project_ClientExtendedDetailsRequest.userAuthentication = userAuthentication;
        project_ClientExtendedDetailsRequest.normalizer = new Normalizer();
        Project_ClientExtendedDetailsRequest.Normalize(project_ClientExtendedDetailsRequest.normalizer, project_ClientExtendedDetailsRequest);



        for (var i = 0; i < project_ClientExtendedDetailsRequest.normalizer.dtoObjects.length; i++) {
            project_ClientExtendedDetailsRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(project_ClientExtendedDetailsRequest.normalizer.dtoObjects[i].object);
            project_ClientExtendedDetailsRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getproject_clientextendeddetails", project_ClientExtendedDetailsRequest);
        var resp = new Project_ClientExtendedDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        Project_ClientExtendedDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async SaveProject_ClientExtendedDetails(project_ClientExtendedDetailsResponse: Project_ClientExtendedDetailsResponse): Promise<Project_ClientExtendedDetailsResponse> {
        project_ClientExtendedDetailsResponse.userAuthentication = userAuthentication;
        project_ClientExtendedDetailsResponse.normalizer = new Normalizer();
        Project_ClientExtendedDetailsResponse.Normalize(project_ClientExtendedDetailsResponse.normalizer, project_ClientExtendedDetailsResponse);


        for (var i = 0; i < project_ClientExtendedDetailsResponse.normalizer.dtoObjects.length; i++) {
            var obj = project_ClientExtendedDetailsResponse.normalizer.dtoObjects[i];
            var key = obj.key;
            // TODO: Kolla ifall vi verkligen ändrats...
            //var objOrig = originalNormalizer.dtoObjects.find(p => p.key === key);
            obj.object.isTainted = true;
        }


        for (var i = 0; i < project_ClientExtendedDetailsResponse.normalizer.dtoObjects.length; i++) {
            project_ClientExtendedDetailsResponse.normalizer.dtoObjects[i].jansson = JSON.stringify(project_ClientExtendedDetailsResponse.normalizer.dtoObjects[i].object);
            project_ClientExtendedDetailsResponse.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/saveproject_clientextendeddetails", project_ClientExtendedDetailsResponse);
        var resp = new Project_ClientExtendedDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        Project_ClientExtendedDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }

     // ************** Project_Person_RoleExtended ******************
         // No fetcher... Project_Person_RoleExtended / Get / Filter
    async GetProject_Person_RoleExtendedSearch(project_Person_RoleExtendedSearchRequest: Project_Person_RoleExtendedSearchRequest): Promise<Project_Person_RoleExtendedSearchResponse> {
        project_Person_RoleExtendedSearchRequest.userAuthentication = userAuthentication;
        project_Person_RoleExtendedSearchRequest.normalizer = new Normalizer();
        Project_Person_RoleExtendedSearchRequest.Normalize(project_Person_RoleExtendedSearchRequest.normalizer, project_Person_RoleExtendedSearchRequest);



        for (var i = 0; i < project_Person_RoleExtendedSearchRequest.normalizer.dtoObjects.length; i++) {
            project_Person_RoleExtendedSearchRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(project_Person_RoleExtendedSearchRequest.normalizer.dtoObjects[i].object);
            project_Person_RoleExtendedSearchRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getproject_person_roleextendedsearch", project_Person_RoleExtendedSearchRequest);
        var resp = new Project_Person_RoleExtendedSearchResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        Project_Person_RoleExtendedSearchResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async GetProject_Person_RoleExtendedDetails(project_Person_RoleExtendedDetailsRequest: Project_Person_RoleExtendedDetailsRequest): Promise<Project_Person_RoleExtendedDetailsResponse> {
        project_Person_RoleExtendedDetailsRequest.userAuthentication = userAuthentication;
        project_Person_RoleExtendedDetailsRequest.normalizer = new Normalizer();
        Project_Person_RoleExtendedDetailsRequest.Normalize(project_Person_RoleExtendedDetailsRequest.normalizer, project_Person_RoleExtendedDetailsRequest);



        for (var i = 0; i < project_Person_RoleExtendedDetailsRequest.normalizer.dtoObjects.length; i++) {
            project_Person_RoleExtendedDetailsRequest.normalizer.dtoObjects[i].jansson = JSON.stringify(project_Person_RoleExtendedDetailsRequest.normalizer.dtoObjects[i].object);
            project_Person_RoleExtendedDetailsRequest.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/getproject_person_roleextendeddetails", project_Person_RoleExtendedDetailsRequest);
        var resp = new Project_Person_RoleExtendedDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        Project_Person_RoleExtendedDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }
    async SaveProject_Person_RoleExtendedDetails(project_Person_RoleExtendedDetailsResponse: Project_Person_RoleExtendedDetailsResponse): Promise<Project_Person_RoleExtendedDetailsResponse> {
        project_Person_RoleExtendedDetailsResponse.userAuthentication = userAuthentication;
        project_Person_RoleExtendedDetailsResponse.normalizer = new Normalizer();
        Project_Person_RoleExtendedDetailsResponse.Normalize(project_Person_RoleExtendedDetailsResponse.normalizer, project_Person_RoleExtendedDetailsResponse);


        for (var i = 0; i < project_Person_RoleExtendedDetailsResponse.normalizer.dtoObjects.length; i++) {
            var obj = project_Person_RoleExtendedDetailsResponse.normalizer.dtoObjects[i];
            var key = obj.key;
            // TODO: Kolla ifall vi verkligen ändrats...
            //var objOrig = originalNormalizer.dtoObjects.find(p => p.key === key);
            obj.object.isTainted = true;
        }


        for (var i = 0; i < project_Person_RoleExtendedDetailsResponse.normalizer.dtoObjects.length; i++) {
            project_Person_RoleExtendedDetailsResponse.normalizer.dtoObjects[i].jansson = JSON.stringify(project_Person_RoleExtendedDetailsResponse.normalizer.dtoObjects[i].object);
            project_Person_RoleExtendedDetailsResponse.normalizer.dtoObjects[i].object = null;
        }

        var tempResponse = await this.CallRestPost("api/empty/saveproject_person_roleextendeddetails", project_Person_RoleExtendedDetailsResponse);
        var resp = new Project_Person_RoleExtendedDetailsResponse();

        // Standard:
        resp = { ...tempResponse };
        resp.isSuccess = tempResponse.isSuccess;
        resp.errorMessage = tempResponse.errorMessage;
        resp.stackTrace = tempResponse.stackTrace;
        resp.request = tempResponse.request;
        resp.request = tempResponse.request;
        resp.normalizer = new Normalizer();

        for (var ii = 0; ii < tempResponse.normalizer.dtoObjects.length; ii++) {
            var nk = new NormKey();
            nk.key = tempResponse.normalizer.dtoObjects[ii].key;
            nk.jansson = tempResponse.normalizer.dtoObjects[ii].jansson;
            resp.normalizer.dtoObjects.push(nk);
        }
        

        // Specific:
        //assignments

        Project_Person_RoleExtendedDetailsResponse.Denormalize(resp.normalizer, resp);

        return resp;
    }

} // end fetchers class

export const fetchers = new Fetchers();
export const userAuthentication = new UserAuthentication();
