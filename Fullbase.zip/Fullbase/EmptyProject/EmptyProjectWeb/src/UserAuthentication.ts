import { UserAuthenticationAuto } from "./UserAuthenticationAuto";

export class UserAuthentication extends UserAuthenticationAuto {
    userId: number;
    firstName: string;
    lastName: string;
    token: string;
}