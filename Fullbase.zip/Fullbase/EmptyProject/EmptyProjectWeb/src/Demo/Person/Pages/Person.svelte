
<script lang="ts">
    import { createEventDispatcher } from "svelte";
    import { filterResponse, searchResponse, detailsResponse } from "../PersonStores";
    import PersonFilter from "../Panels/PersonFilter.svelte";
    import PersonSearch from "../Panels/PersonSearch.svelte";
    import PersonQuickSearch from "../Panels/PersonQuickSearch.svelte";
    import PersonDetails from "../Panels/PersonDetails.svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;

    // Relay back to caller...
    function onOk(c) {
        dispatch("ok", c.detail);
    }

    // Reset stores when surfing to page.
    $filterResponse = null;
    $searchResponse = null;
    $detailsResponse = null;
</script>

<PersonFilter />
<hr />
<PersonSearch {isModal} on:ok={onOk}/>
<hr />
<PersonDetails />
