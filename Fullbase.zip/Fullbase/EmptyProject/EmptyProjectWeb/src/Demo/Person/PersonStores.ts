
import { writable } from "svelte/store";
import type {
    PersonDto,
    PersonFilterResponse,
    PersonSearchRequest,
    PersonSearchResponse,
    PersonDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<PersonFilterResponse>(null);
export let searchResponse = writable<PersonSearchResponse>(null);
export let detailsResponse = writable<PersonDetailsResponse>(null);
export let searchRequest = writable<PersonSearchRequest>(null);
export let selectedRow = writable<PersonDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
