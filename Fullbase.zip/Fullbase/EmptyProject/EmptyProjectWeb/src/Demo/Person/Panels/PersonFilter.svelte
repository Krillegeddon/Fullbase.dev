
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        Normalizer,
        NormKey,
PersonDto,DepartmentDto,GenderDto,Project_Person_RoleDto,ProjectDto,ProjectTypeDto,RoleDto,ClientDto,PersonFilterRequest,PersonFilterResponse,PersonSearchRequest,PersonSearchResponse
    } from "../../../WebApi";
    import {createEventDispatcher} from "svelte";
    import { filterResponse,searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingSearch } from "../PersonStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import { Icon } from "sveltestrap";
    const dispatch = createEventDispatcher();

    //export let isModal: boolean;
    let addCounter = -1;

import PersonLookup from "./../../PersonLookup/Pages/PersonLookup.svelte";
import PersonLookupQuickSearch from "./../../PersonLookup/Panels/PersonLookupQuickSearch.svelte";



    const addProject_Person_Roles_to_Person = (parentObject: PersonDto) => {
        var o = new Project_Person_RoleDto();
        o.project_Person_RoleId = addCounter;
        addCounter--;
        o.personId = parentObject.personId;
        o.person = parentObject;
        if (parentObject.project_Person_Roles == null) {
            parentObject.project_Person_Roles = new Array<Project_Person_RoleDto>();
        }
        parentObject.project_Person_Roles = [... parentObject.project_Person_Roles, o ];
        $detailsResponse = $detailsResponse; // Workaround to get stuff reloaded!
    };


    const addClients_to_Person = (parentObject: PersonDto) => {
        var o = new ClientDto();
        o.clientId = addCounter;
        addCounter--;
        o.personId = parentObject.personId;
        o.keyAccountManager = parentObject;
        if (parentObject.clients == null) {
            parentObject.clients = new Array<ClientDto>();
        }
        parentObject.clients = [... parentObject.clients, o ];
        $detailsResponse = $detailsResponse; // Workaround to get stuff reloaded!
    };



    onMount(async () => {
        var req = new PersonFilterRequest(); // Default Filter Request
        $filterResponse = await fetchers.GetPersonFilter(req);
        $searchRequest = new PersonSearchRequest();
        $searchRequest.personId = new IntClause();
        $searchRequest.userName = new StringClause();
        $searchRequest.salary = new IntClause();
        $searchRequest.department_departmentId = new IntClause();
        $searchRequest.department_departmentName = new StringClause();
        $searchRequest.gender_genderId = new IntClause();
        $searchRequest.gender_genderDescription = new StringClause();
        $searchRequest.manager_personId = new IntClause();
        $searchRequest.manager_userName = new StringClause();
        $searchRequest.manager_salary = new IntClause();

    });



    const onSearch = async () => {
        $isLoadingSearch = true;
        $searchResponse = null;
        $selectedRow = null;
        $detailsResponse = null;
        $searchResponse = await fetchers.GetPersonSearch($searchRequest);
        $isLoadingSearch = false;
    };




    /******* MODAL FOR SEARCHING manager_personId for PersonSearchRequest - START ************/
    let modalControllerFindPersonSearchRequest__manager_personId_IsOpen: boolean;

    let modalPersonSearchRequest__manager_personId: PersonSearchRequest;
    const openFindPersonSearchRequest__manager_personId = (x: PersonSearchRequest) => {
        modalPersonSearchRequest__manager_personId = x;
        modalControllerFindPersonSearchRequest__manager_personId_IsOpen = true;
    };

    let manager_personId: PersonDto = null;
    function onPersonSearchRequest__manager_personIdFound(c) {
        manager_personId = c.detail;
        modalControllerFindPersonSearchRequest__manager_personId_IsOpen = false;
        modalPersonSearchRequest__manager_personId.manager_personId.exactMatch = manager_personId.personId;
        $searchRequest = $searchRequest;
    }
    /******* MODAL FOR SEARCHING manager_personId for PersonSearchRequest - DONE ************/


</script>



    <Container>
{#if $filterResponse}
        <form on:submit|preventDefault={onSearch}>
            <Row>

<div class="col-10">
    <FormGroup>
        <Label>Person.QuickSearch</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.quickSearch} />
    </FormGroup>
</div>

            </Row>
            <Row>

<div class="col-5">
    <FormGroup>
        <Label>Person.PersonId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.personId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.DepartmentId</Label>
        
        <select class="form-control" bind:value={$searchRequest.department_departmentId.exactMatch}>
            <option value={null}>- all -</option>
            {#each $filterResponse.departments as department}
                <option value={department.departmentId}>{department.departmentName}</option>
            {/each}
        </select>

    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.GenderId</Label>
        
        <select class="form-control" bind:value={$searchRequest.gender_genderId.exactMatch}>
            <option value={null}>- all -</option>
            {#each $filterResponse.genders as gender}
                <option value={gender.genderId}>{gender.genderDescription}</option>
            {/each}
        </select>

    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.ManagerId <span style="cursor:pointer;" on:click={() => openFindPersonSearchRequest__manager_personId($searchRequest)}
                    ><Icon name="search" /></span></Label>
        <PersonLookupQuickSearch selectedObject={manager_personId} bind:selectedId={$searchRequest.manager_personId.exactMatch} isReadOnly={false} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>User Name</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.userName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Salary</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.salary.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.department_departmentId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.department_departmentName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.gender_genderId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.gender_genderDescription.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.PersonId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.manager_personId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.UserName</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.manager_userName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.Salary</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.manager_salary.exactMatch} />
    </FormGroup>
</div>

            </Row>

<Row>
    <div class="col-2">
        <Button color="primary"><Icon name="search"/> Search</Button>
    </div>
</Row>

        </form>
{:else}
    <Spinner color="primary" />
{/if}
    </Container>

<Modal isOpen={modalControllerFindPersonSearchRequest__manager_personId_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find manager_personId</ModalHeader>
    <ModalBody>
        <PersonLookup on:ok={onPersonSearchRequest__manager_personIdFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindPersonSearchRequest__manager_personId_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>

<style>
</style>
