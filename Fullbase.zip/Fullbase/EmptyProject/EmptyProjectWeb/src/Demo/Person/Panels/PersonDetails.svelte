
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        Normalizer,
        NormKey,
        userAuthentication,
PersonDto,DepartmentDto,GenderDto,Project_Person_RoleDto,ProjectDto,ProjectTypeDto,RoleDto,ClientDto,PersonFilterRequest,PersonFilterResponse,PersonSearchRequest,PersonSearchResponse,PersonDetailsRequest,PersonDetailsResponse
    } from "../../../WebApi";
    import FBSelect from "../../../Components/FBSelect.svelte";
    import FBControl from "../../../Components/FBControl.svelte";
    import FBCard from "../../../Components/FBCard.svelte";
    import FBRootCard from "../../../Components/FBRootCard.svelte";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails } from "../PersonStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Card, CardHeader, CardTitle, CardBody, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean = false;
    let addCounter = -5;

import PersonLookup from "./../../PersonLookup/Pages/PersonLookup.svelte";
import PersonLookupQuickSearch from "./../../PersonLookup/Panels/PersonLookupQuickSearch.svelte";


import ProjectLookup from "./../../ProjectLookup/Pages/ProjectLookup.svelte";
import ProjectLookupQuickSearch from "./../../ProjectLookup/Panels/ProjectLookupQuickSearch.svelte";


import RoleLookup from "./../../RoleLookup/Pages/RoleLookup.svelte";
import RoleLookupQuickSearch from "./../../RoleLookup/Panels/RoleLookupQuickSearch.svelte";


import ProjectTypeLookup from "./../../ProjectTypeLookup/Pages/ProjectTypeLookup.svelte";
import ProjectTypeLookupQuickSearch from "./../../ProjectTypeLookup/Panels/ProjectTypeLookupQuickSearch.svelte";



    const addProject_Person_Roles_to_Person = (parentObject: PersonDto) => {
        var o = new Project_Person_RoleDto();
        o.project_Person_RoleId = addCounter;
        addCounter--;
        o.personId = parentObject.personId;
        o.person = parentObject;
        if (parentObject.project_Person_Roles == null) {
            parentObject.project_Person_Roles = new Array<Project_Person_RoleDto>();
        }
        parentObject.project_Person_Roles = [... parentObject.project_Person_Roles, o ];
        $detailsResponse = $detailsResponse; // Workaround to get stuff reloaded!
    };


    const addClients_to_Person = (parentObject: PersonDto) => {
        var o = new ClientDto();
        o.clientId = addCounter;
        addCounter--;
        o.personId = parentObject.personId;
        o.keyAccountManager = parentObject;
        if (parentObject.clients == null) {
            parentObject.clients = new Array<ClientDto>();
        }
        parentObject.clients = [... parentObject.clients, o ];
        $detailsResponse = $detailsResponse; // Workaround to get stuff reloaded!
    };



    let isSaving: boolean = false;
    const onSave = async () => {
        isSaving = true;
        var copy = { ...$detailsResponse };

        //$detailsResponse = null;
        $detailsResponse = await fetchers.SavePersonDetails(copy);
        isSaving = false;
    };




    /******* MODAL FOR FINDING manager for Person - START ************/
    let modalControllerFindPerson__manager_IsOpen: boolean;

    let modalPerson__manager: PersonDto;
    const openFindPerson__manager = (x: PersonDto) => {
        modalPerson__manager = x;
        modalControllerFindPerson__manager_IsOpen = true;
    };

    function onPerson__managerFound(c) {
        var person: PersonDto = c.detail;
        modalControllerFindPerson__manager_IsOpen = false;
        modalPerson__manager.manager = person;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING manager for Person - DONE ************/


    /******* MODAL FOR FINDING project for Project_Person_Role - START ************/
    let modalControllerFindProject_Person_Role__project_IsOpen: boolean;

    let modalProject_Person_Role__project: Project_Person_RoleDto;
    const openFindProject_Person_Role__project = (x: Project_Person_RoleDto) => {
        modalProject_Person_Role__project = x;
        modalControllerFindProject_Person_Role__project_IsOpen = true;
    };

    function onProject_Person_Role__projectFound(c) {
        var project: ProjectDto = c.detail;
        modalControllerFindProject_Person_Role__project_IsOpen = false;
        modalProject_Person_Role__project.project = project;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING project for Project_Person_Role - DONE ************/


    /******* MODAL FOR FINDING role for Project_Person_Role - START ************/
    let modalControllerFindProject_Person_Role__role_IsOpen: boolean;

    let modalProject_Person_Role__role: Project_Person_RoleDto;
    const openFindProject_Person_Role__role = (x: Project_Person_RoleDto) => {
        modalProject_Person_Role__role = x;
        modalControllerFindProject_Person_Role__role_IsOpen = true;
    };

    function onProject_Person_Role__roleFound(c) {
        var role: RoleDto = c.detail;
        modalControllerFindProject_Person_Role__role_IsOpen = false;
        modalProject_Person_Role__role.role = role;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING role for Project_Person_Role - DONE ************/


    /******* MODAL FOR FINDING projectType for Project - START ************/
    let modalControllerFindProject__projectType_IsOpen: boolean;

    let modalProject__projectType: ProjectDto;
    const openFindProject__projectType = (x: ProjectDto) => {
        modalProject__projectType = x;
        modalControllerFindProject__projectType_IsOpen = true;
    };

    function onProject__projectTypeFound(c) {
        var projectType: ProjectTypeDto = c.detail;
        modalControllerFindProject__projectType_IsOpen = false;
        modalProject__projectType.projectType = projectType;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING projectType for Project - DONE ************/


</script>



<Container>
    {#if userAuthentication.isDefault || userAuthentication.isAdmin}
        {#if $detailsResponse}
            <FBRootCard>
                <svelte:fragment slot="title">
                    Person
                </svelte:fragment>
                <svelte:fragment slot="savebutton">
                    {#if userAuthentication.isAdmin}
                        {#if !isModal}
                            <button class="btn btn-primary" on:click={onSave}><Icon name="save" /> Save</button>
                        {/if}
                        {#if isSaving}
                            <Spinner color="primary" />
                        {/if}
                    {/if}
                </svelte:fragment>
                <svelte:fragment slot="body">
        
<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.PersonId</Label>
        {#if $detailsResponse?.person}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.personId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>User Name</Label>
        {#if $detailsResponse?.person}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.userName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>User Name</Label>
        {#if $detailsResponse?.person}
            <span class="form-control">{$detailsResponse.person.userName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isAdmin}
    
<div class="col-5">
    <FormGroup>
        <Label>Salary</Label>
        {#if $detailsResponse?.person}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.salary} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin}
    
<div class="col-5">
    <FormGroup>
        <Label>Salary</Label>
        {#if $detailsResponse?.person}
            <span class="form-control">{$detailsResponse.person.salary}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.DepartmentId</Label>
        {#if $detailsResponse?.person}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.department}
        objects={$detailsResponse.departments}
        let:object
        isReadOnly={false}
    >
        <option>{object.departmentName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.DepartmentId</Label>
        {#if $detailsResponse?.person}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.department}
        objects={$detailsResponse.departments}
        let:object
        isReadOnly={true}
    >
        <option>{object.departmentName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.GenderId</Label>
        {#if $detailsResponse?.person}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.gender}
        objects={$detailsResponse.genders}
        let:object
        isReadOnly={false}
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.GenderId</Label>
        {#if $detailsResponse?.person}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.gender}
        objects={$detailsResponse.genders}
        let:object
        isReadOnly={true}
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.ManagerId <span style="cursor:pointer;" on:click={() => openFindPerson__manager($detailsResponse.person)}
                    ><Icon name="search" /></span></Label>
        {#if $detailsResponse?.person}
            <PersonLookupQuickSearch bind:selectedObject={$detailsResponse.person.manager} selectedId={0} isReadOnly={false}/>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.ManagerId</Label>
        {#if $detailsResponse?.person}
            <PersonLookupQuickSearch bind:selectedObject={$detailsResponse.person.manager} selectedId={0} isReadOnly={true}/>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">Department</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentId</Label>
        {#if $detailsResponse?.person?.department}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.department.departmentId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        {#if $detailsResponse?.person?.department}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.department.departmentName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        {#if $detailsResponse?.person?.department}
            <span class="form-control">{$detailsResponse.person.department.departmentName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Gender</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        {#if $detailsResponse?.person?.gender}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.gender.genderId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        {#if $detailsResponse?.person?.gender}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.gender.genderDescription} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        {#if $detailsResponse?.person?.gender}
            <span class="form-control">{$detailsResponse.person.gender.genderDescription}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Manager</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.PersonId</Label>
        {#if $detailsResponse?.person?.manager}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.manager.personId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.UserName</Label>
        {#if $detailsResponse?.person?.manager}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.manager.userName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.UserName</Label>
        {#if $detailsResponse?.person?.manager}
            <span class="form-control">{$detailsResponse.person.manager.userName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.Salary</Label>
        {#if $detailsResponse?.person?.manager}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.manager.salary} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.Salary</Label>
        {#if $detailsResponse?.person?.manager}
            <span class="form-control">{$detailsResponse.person.manager.salary}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.DepartmentId</Label>
        {#if $detailsResponse?.person?.manager}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.manager.department}
        objects={$detailsResponse.departments}
        let:object
        isReadOnly={false}
    >
        <option>{object.departmentName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.DepartmentId</Label>
        {#if $detailsResponse?.person?.manager}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.manager.department}
        objects={$detailsResponse.departments}
        let:object
        isReadOnly={true}
    >
        <option>{object.departmentName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.GenderId</Label>
        {#if $detailsResponse?.person?.manager}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.manager.gender}
        objects={$detailsResponse.genders}
        let:object
        isReadOnly={false}
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.GenderId</Label>
        {#if $detailsResponse?.person?.manager}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.manager.gender}
        objects={$detailsResponse.genders}
        let:object
        isReadOnly={true}
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">Department</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentId</Label>
        {#if $detailsResponse?.person?.manager?.department}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.manager.department.departmentId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        {#if $detailsResponse?.person?.manager?.department}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.manager.department.departmentName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        {#if $detailsResponse?.person?.manager?.department}
            <span class="form-control">{$detailsResponse.person.manager.department.departmentName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Gender</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        {#if $detailsResponse?.person?.manager?.gender}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.manager.gender.genderId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        {#if $detailsResponse?.person?.manager?.gender}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.manager.gender.genderDescription} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        {#if $detailsResponse?.person?.manager?.gender}
            <span class="form-control">{$detailsResponse.person.manager.gender.genderDescription}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">
        List of Project_Person_Roles <button class="btn btn-outline-primary btn-sm mb-2" on:click={ () => addProject_Person_Roles_to_Person($detailsResponse.person) }><Icon name="plus-square"/> Add Project_Person_Role</button>
    </svelte:fragment>
    <svelte:fragment slot="body">
        {#if $detailsResponse?.person && $detailsResponse?.person?.project_Person_Roles}
            {#each $detailsResponse.person.project_Person_Roles as project_Person_Role (project_Person_Role.project_Person_RoleId)}
        <FBCard>
            <svelte:fragment slot="title">
                Project_Person_Role <button class="btn btn-outline-danger btn-sm"><Icon name="file-excel"/> Delete Project_Person_Role</button>
            </svelte:fragment>
            <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Person_Roles.Project_Person_RoleId</Label>
        {#if project_Person_Role}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={project_Person_Role.project_Person_RoleId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Project_Person_Roles.ProjectId <span style="cursor:pointer;" on:click={() => openFindProject_Person_Role__project(project_Person_Role)}
                    ><Icon name="search" /></span></Label>
        {#if project_Person_Role}
            <ProjectLookupQuickSearch bind:selectedObject={project_Person_Role.project} selectedId={0} isReadOnly={false}/>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Project_Person_Roles.ProjectId</Label>
        {#if project_Person_Role}
            <ProjectLookupQuickSearch bind:selectedObject={project_Person_Role.project} selectedId={0} isReadOnly={true}/>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Person_Roles.RoleId <span style="cursor:pointer;" on:click={() => openFindProject_Person_Role__role(project_Person_Role)}
                    ><Icon name="search" /></span></Label>
        {#if project_Person_Role}
            <RoleLookupQuickSearch bind:selectedObject={project_Person_Role.role} selectedId={0} isReadOnly={false}/>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Person_Roles.RoleId</Label>
        {#if project_Person_Role}
            <RoleLookupQuickSearch bind:selectedObject={project_Person_Role.role} selectedId={0} isReadOnly={true}/>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">Project</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>ProjectId</Label>
        {#if project_Person_Role?.project}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={project_Person_Role.project.projectId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project Name</Label>
        {#if project_Person_Role?.project}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={project_Person_Role.project.projectName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project Name</Label>
        {#if project_Person_Role?.project}
            <span class="form-control">{project_Person_Role.project.projectName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Is Pro-Bono</Label>
        {#if project_Person_Role?.project}
            <div class="form-control">
    <input autocomplete="new-password" class="form-check-input" type="checkbox" bind:checked={project_Person_Role.project.isProBono} />
</div>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Is Pro-Bono</Label>
        {#if project_Person_Role?.project}
            <span class="form-control">{project_Person_Role.project.isProBono}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Deadline</Label>
        {#if project_Person_Role?.project}
            <DateTimeInput css="form-control" bind:value={project_Person_Role.project.deadline} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Deadline</Label>
        {#if project_Person_Role?.project}
            <span class="form-control">{project_Person_Role.project.deadline}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project Type <span style="cursor:pointer;" on:click={() => openFindProject__projectType(project_Person_Role.project)}
                    ><Icon name="search" /></span></Label>
        {#if project_Person_Role?.project}
            <ProjectTypeLookupQuickSearch bind:selectedObject={project_Person_Role.project.projectType} selectedId={0} isReadOnly={false}/>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project Type</Label>
        {#if project_Person_Role?.project}
            <ProjectTypeLookupQuickSearch bind:selectedObject={project_Person_Role.project.projectType} selectedId={0} isReadOnly={true}/>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">ProjectType</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectType.ProjectTypeId</Label>
        {#if project_Person_Role?.project?.projectType}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={project_Person_Role.project.projectType.projectTypeId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectType.ProjectTypeName</Label>
        {#if project_Person_Role?.project?.projectType}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={project_Person_Role.project.projectType.projectTypeName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectType.ProjectTypeName</Label>
        {#if project_Person_Role?.project?.projectType}
            <span class="form-control">{project_Person_Role.project.projectType.projectTypeName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Role</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Person_Roles.Role.RoleId</Label>
        {#if project_Person_Role?.role}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={project_Person_Role.role.roleId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Role</Label>
        {#if project_Person_Role?.role}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={project_Person_Role.role.roleName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Role</Label>
        {#if project_Person_Role?.role}
            <span class="form-control">{project_Person_Role.role.roleName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

            </svelte:fragment>
        </FBCard>
            {/each}
        {/if}
    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">
        List of Clients <button class="btn btn-outline-primary btn-sm mb-2" on:click={ () => addClients_to_Person($detailsResponse.person) }><Icon name="plus-square"/> Add Client</button>
    </svelte:fragment>
    <svelte:fragment slot="body">
        {#if $detailsResponse?.person && $detailsResponse?.person?.clients}
            {#each $detailsResponse.person.clients as client (client.clientId)}
        <FBCard>
            <svelte:fragment slot="title">
                Client <button class="btn btn-outline-danger btn-sm"><Icon name="file-excel"/> Delete Client</button>
            </svelte:fragment>
            <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Clients.ClientId</Label>
        {#if client}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={client.clientId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Clients.ClientName</Label>
        {#if client}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={client.clientName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Clients.ClientName</Label>
        {#if client}
            <span class="form-control">{client.clientName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

            </svelte:fragment>
        </FBCard>
            {/each}
        {/if}
    </svelte:fragment>
</FBCard>

                </svelte:fragment>
                </FBRootCard>
        {:else if $isLoadingDetails}
            <Spinner color="primary" />
        {/if}
    {:else}
        **hidden**
    {/if}
</Container>

<Modal isOpen={modalControllerFindPerson__manager_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Person</ModalHeader>
    <ModalBody>
        <PersonLookup on:ok={onPerson__managerFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindPerson__manager_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindProject_Person_Role__project_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Project</ModalHeader>
    <ModalBody>
        <ProjectLookup on:ok={onProject_Person_Role__projectFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindProject_Person_Role__project_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindProject_Person_Role__role_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Role</ModalHeader>
    <ModalBody>
        <RoleLookup on:ok={onProject_Person_Role__roleFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindProject_Person_Role__role_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindProject__projectType_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find ProjectType</ModalHeader>
    <ModalBody>
        <ProjectTypeLookup on:ok={onProject__projectTypeFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindProject__projectType_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>

<style>
</style>
