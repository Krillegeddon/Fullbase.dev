
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        Normalizer,
        NormKey,
        userAuthentication,
PersonDto,DepartmentDto,GenderDto,Project_Person_RoleDto,ProjectDto,ProjectTypeDto,RoleDto,ClientDto,PersonFilterRequest,PersonFilterResponse,PersonSearchRequest,PersonSearchResponse,PersonDetailsRequest,PersonDetailsResponse
    } from "../../../WebApi";
    import FBSelect from "../../../Components/FBSelect.svelte";
    import FBControl from "../../../Components/FBControl.svelte";
    import FBCard from "../../../Components/FBCard.svelte";
    import FBRootCard from "../../../Components/FBRootCard.svelte";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails } from "../PersonStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Card, CardHeader, CardTitle, CardBody, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean = false;
    let addCounter = -5;

import PersonLookup from "./../../PersonLookup/Pages/PersonLookup.svelte";
import PersonLookupQuickSearch from "./../../PersonLookup/Panels/PersonLookupQuickSearch.svelte";


import ProjectLookup from "./../../ProjectLookup/Pages/ProjectLookup.svelte";
import ProjectLookupQuickSearch from "./../../ProjectLookup/Panels/ProjectLookupQuickSearch.svelte";


import RoleLookup from "./../../RoleLookup/Pages/RoleLookup.svelte";
import RoleLookupQuickSearch from "./../../RoleLookup/Panels/RoleLookupQuickSearch.svelte";


import ProjectTypeLookup from "./../../ProjectTypeLookup/Pages/ProjectTypeLookup.svelte";
import ProjectTypeLookupQuickSearch from "./../../ProjectTypeLookup/Panels/ProjectTypeLookupQuickSearch.svelte";



    const addProject_Person_Roles_to_Person = (parentObject: PersonDto) => {
        var o = new Project_Person_RoleDto();
        o.project_Person_RoleId = addCounter;
        addCounter--;
        o.personId = parentObject.personId;
        o.person = parentObject;
        if (parentObject.project_Person_Roles == null) {
            parentObject.project_Person_Roles = new Array<Project_Person_RoleDto>();
        }
        parentObject.project_Person_Roles = [... parentObject.project_Person_Roles, o ];
        $detailsResponse = $detailsResponse; // Workaround to get stuff reloaded!
    };


    const addClients_to_Person = (parentObject: PersonDto) => {
        var o = new ClientDto();
        o.clientId = addCounter;
        addCounter--;
        o.personId = parentObject.personId;
        o.keyAccountManager = parentObject;
        if (parentObject.clients == null) {
            parentObject.clients = new Array<ClientDto>();
        }
        parentObject.clients = [... parentObject.clients, o ];
        $detailsResponse = $detailsResponse; // Workaround to get stuff reloaded!
    };



    let isSaving: boolean = false;
    const onSave = async () => {
        isSaving = true;
        var copy = { ...$detailsResponse };

        //$detailsResponse = null;
        $detailsResponse = await fetchers.SavePersonDetails(copy);
        isSaving = false;
    };




    /******* MODAL FOR FINDING manager for Person - START ************/
    let modalControllerFindPerson__manager_IsOpen: boolean;

    let modalPerson__manager: PersonDto;
    const openFindPerson__manager = (x: PersonDto) => {
        modalPerson__manager = x;
        modalControllerFindPerson__manager_IsOpen = true;
    };

    function onPerson__managerFound(c) {
        var person: PersonDto = c.detail;
        modalControllerFindPerson__manager_IsOpen = false;
        modalPerson__manager.manager = person;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING manager for Person - DONE ************/


    /******* MODAL FOR FINDING project for Project_Person_Role - START ************/
    let modalControllerFindProject_Person_Role__project_IsOpen: boolean;

    let modalProject_Person_Role__project: Project_Person_RoleDto;
    const openFindProject_Person_Role__project = (x: Project_Person_RoleDto) => {
        modalProject_Person_Role__project = x;
        modalControllerFindProject_Person_Role__project_IsOpen = true;
    };

    function onProject_Person_Role__projectFound(c) {
        var project: ProjectDto = c.detail;
        modalControllerFindProject_Person_Role__project_IsOpen = false;
        modalProject_Person_Role__project.project = project;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING project for Project_Person_Role - DONE ************/


    /******* MODAL FOR FINDING person for Project_Person_Role - START ************/
    let modalControllerFindProject_Person_Role__person_IsOpen: boolean;

    let modalProject_Person_Role__person: Project_Person_RoleDto;
    const openFindProject_Person_Role__person = (x: Project_Person_RoleDto) => {
        modalProject_Person_Role__person = x;
        modalControllerFindProject_Person_Role__person_IsOpen = true;
    };

    function onProject_Person_Role__personFound(c) {
        var person: PersonDto = c.detail;
        modalControllerFindProject_Person_Role__person_IsOpen = false;
        modalProject_Person_Role__person.person = person;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING person for Project_Person_Role - DONE ************/


    /******* MODAL FOR FINDING role for Project_Person_Role - START ************/
    let modalControllerFindProject_Person_Role__role_IsOpen: boolean;

    let modalProject_Person_Role__role: Project_Person_RoleDto;
    const openFindProject_Person_Role__role = (x: Project_Person_RoleDto) => {
        modalProject_Person_Role__role = x;
        modalControllerFindProject_Person_Role__role_IsOpen = true;
    };

    function onProject_Person_Role__roleFound(c) {
        var role: RoleDto = c.detail;
        modalControllerFindProject_Person_Role__role_IsOpen = false;
        modalProject_Person_Role__role.role = role;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING role for Project_Person_Role - DONE ************/


    /******* MODAL FOR FINDING projectType for Project - START ************/
    let modalControllerFindProject__projectType_IsOpen: boolean;

    let modalProject__projectType: ProjectDto;
    const openFindProject__projectType = (x: ProjectDto) => {
        modalProject__projectType = x;
        modalControllerFindProject__projectType_IsOpen = true;
    };

    function onProject__projectTypeFound(c) {
        var projectType: ProjectTypeDto = c.detail;
        modalControllerFindProject__projectType_IsOpen = false;
        modalProject__projectType.projectType = projectType;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING projectType for Project - DONE ************/


</script>



<Container>
    {#if userAuthentication.isDefault || userAuthentication.isAdmin}
        {#if $detailsResponse}
            <FBRootCard>
                <svelte:fragment slot="title">
                    Person
                </svelte:fragment>
                <svelte:fragment slot="savebutton">
                    {#if userAuthentication.isAdmin}
                        {#if !isModal}
                            <button class="btn btn-primary" on:click={onSave}><Icon name="save" /> Save</button>
                        {/if}
                        {#if isSaving}
                            <Spinner color="primary" />
                        {/if}
                    {/if}
                </svelte:fragment>
                <svelte:fragment slot="body">
        
<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.PersonId</Label>
        {#if $detailsResponse?.person}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.personId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>User Name</Label>
        {#if $detailsResponse?.person}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.userName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.person.userName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Salary</Label>
        {#if $detailsResponse?.person}
            
{#if userAuthentication.isAdmin}
    <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.salary} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin}
    <span class="form-control">{$detailsResponse.person.salary}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.DepartmentId</Label>
        {#if $detailsResponse?.person}
            
{#if true}
    
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.department}
        objects={$detailsResponse.departments}
        let:object
    >
        <option>{object.departmentName}</option>
    </FBSelect>

{:else if true}
    <span class="form-control">{$detailsResponse.person.department}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.GenderId</Label>
        {#if $detailsResponse?.person}
            
{#if true}
    
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.gender}
        objects={$detailsResponse.genders}
        let:object
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

{:else if true}
    <span class="form-control">{$detailsResponse.person.gender}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.ManagerId <span style="cursor:pointer;" on:click={() => openFindPerson__manager($detailsResponse.person)}
                    ><Icon name="search" /></span></Label>
        {#if $detailsResponse?.person}
            
{#if true}
    <PersonLookupQuickSearch bind:selectedObject={$detailsResponse.person.manager} selectedId={0} isReadOnly={false}/>
{:else if true}
    <PersonLookupQuickSearch bind:selectedObject={$detailsResponse.person.manager} selectedId={0} isReadOnly={true}/>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">Department</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentId</Label>
        {#if $detailsResponse?.person?.department}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.department.departmentId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        {#if $detailsResponse?.person?.department}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.department.departmentName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.person.department.departmentName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Gender</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        {#if $detailsResponse?.person?.gender}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.gender.genderId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        {#if $detailsResponse?.person?.gender}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.gender.genderDescription} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.person.gender.genderDescription}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Manager</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.PersonId</Label>
        {#if $detailsResponse?.person?.manager}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.manager.personId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.UserName</Label>
        {#if $detailsResponse?.person?.manager}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.manager.userName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.person.manager.userName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.Salary</Label>
        {#if $detailsResponse?.person?.manager}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.manager.salary} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.person.manager.salary}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.DepartmentId</Label>
        {#if $detailsResponse?.person?.manager}
            
{#if true}
    
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.manager.department}
        objects={$detailsResponse.departments}
        let:object
    >
        <option>{object.departmentName}</option>
    </FBSelect>

{:else if true}
    <span class="form-control">{$detailsResponse.person.manager.department}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.GenderId</Label>
        {#if $detailsResponse?.person?.manager}
            
{#if true}
    
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.manager.gender}
        objects={$detailsResponse.genders}
        let:object
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

{:else if true}
    <span class="form-control">{$detailsResponse.person.manager.gender}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">Department</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentId</Label>
        {#if $detailsResponse?.person?.manager?.department}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.manager.department.departmentId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        {#if $detailsResponse?.person?.manager?.department}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.manager.department.departmentName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.person.manager.department.departmentName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Gender</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        {#if $detailsResponse?.person?.manager?.gender}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.manager.gender.genderId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        {#if $detailsResponse?.person?.manager?.gender}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.manager.gender.genderDescription} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.person.manager.gender.genderDescription}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">
        List of Project_Person_Roles <button class="btn btn-outline-primary btn-sm mb-2" on:click={ () => addProject_Person_Roles_to_Person($detailsResponse.person) }><Icon name="plus-square"/> Add Project_Person_Role</button>
    </svelte:fragment>
    <svelte:fragment slot="body">
        {#if $detailsResponse?.person && $detailsResponse?.person?.project_Person_Roles}
            {#each $detailsResponse.person.project_Person_Roles as project_Person_Role (project_Person_Role.project_Person_RoleId)}
        <FBCard>
            <svelte:fragment slot="title">
                Project_Person_Role <button class="btn btn-outline-danger btn-sm"><Icon name="file-excel"/> Delete Project_Person_Role</button>
            </svelte:fragment>
            <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Person_Roles.Project_Person_RoleId</Label>
        {#if project_Person_Role}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={project_Person_Role.project_Person_RoleId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Project_Person_Roles.ProjectId <span style="cursor:pointer;" on:click={() => openFindProject_Person_Role__project(project_Person_Role)}
                    ><Icon name="search" /></span></Label>
        {#if project_Person_Role}
            
{#if true}
    <ProjectLookupQuickSearch bind:selectedObject={project_Person_Role.project} selectedId={0} isReadOnly={false}/>
{:else if true}
    <ProjectLookupQuickSearch bind:selectedObject={project_Person_Role.project} selectedId={0} isReadOnly={true}/>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Person_Roles.PersonId <span style="cursor:pointer;" on:click={() => openFindProject_Person_Role__person(project_Person_Role)}
                    ><Icon name="search" /></span></Label>
        {#if project_Person_Role}
            
{#if true}
    <PersonLookupQuickSearch bind:selectedObject={project_Person_Role.person} selectedId={0} isReadOnly={false}/>
{:else if true}
    <PersonLookupQuickSearch bind:selectedObject={project_Person_Role.person} selectedId={0} isReadOnly={true}/>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Person_Roles.RoleId <span style="cursor:pointer;" on:click={() => openFindProject_Person_Role__role(project_Person_Role)}
                    ><Icon name="search" /></span></Label>
        {#if project_Person_Role}
            
{#if true}
    <RoleLookupQuickSearch bind:selectedObject={project_Person_Role.role} selectedId={0} isReadOnly={false}/>
{:else if true}
    <RoleLookupQuickSearch bind:selectedObject={project_Person_Role.role} selectedId={0} isReadOnly={true}/>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">Project</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>ProjectId</Label>
        {#if project_Person_Role?.project}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={project_Person_Role.project.projectId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project Name</Label>
        {#if project_Person_Role?.project}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={project_Person_Role.project.projectName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{project_Person_Role.project.projectName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Is Pro-Bono</Label>
        {#if project_Person_Role?.project}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="checkbox" bind:checked={project_Person_Role.project.isProBono} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{project_Person_Role.project.isProBono}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Deadline</Label>
        {#if project_Person_Role?.project}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <DateTimeInput css="form-control" bind:value={project_Person_Role.project.deadline} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{project_Person_Role.project.deadline}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project Type <span style="cursor:pointer;" on:click={() => openFindProject__projectType(project_Person_Role.project)}
                    ><Icon name="search" /></span></Label>
        {#if project_Person_Role?.project}
            
{#if true}
    <ProjectTypeLookupQuickSearch bind:selectedObject={project_Person_Role.project.projectType} selectedId={0} isReadOnly={false}/>
{:else if true}
    <ProjectTypeLookupQuickSearch bind:selectedObject={project_Person_Role.project.projectType} selectedId={0} isReadOnly={true}/>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">ProjectType</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectType.ProjectTypeId</Label>
        {#if project_Person_Role?.project?.projectType}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={project_Person_Role.project.projectType.projectTypeId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectType.ProjectTypeName</Label>
        {#if project_Person_Role?.project?.projectType}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={project_Person_Role.project.projectType.projectTypeName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{project_Person_Role.project.projectType.projectTypeName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Person</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.PersonId</Label>
        {#if project_Person_Role?.person}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={project_Person_Role.person.personId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>User Name</Label>
        {#if project_Person_Role?.person}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={project_Person_Role.person.userName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{project_Person_Role.person.userName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Salary</Label>
        {#if project_Person_Role?.person}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="number" bind:value={project_Person_Role.person.salary} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{project_Person_Role.person.salary}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.DepartmentId</Label>
        {#if project_Person_Role?.person}
            
{#if true}
    
    <FBSelect
        css="form-control"
        bind:value={project_Person_Role.person.department}
        objects={$detailsResponse.departments}
        let:object
    >
        <option>{object.departmentName}</option>
    </FBSelect>

{:else if true}
    <span class="form-control">{project_Person_Role.person.department}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">Department</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentId</Label>
        {#if project_Person_Role?.person?.department}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={project_Person_Role.person.department.departmentId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        {#if project_Person_Role?.person?.department}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={project_Person_Role.person.department.departmentName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{project_Person_Role.person.department.departmentName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Role</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Person_Roles.Role.RoleId</Label>
        {#if project_Person_Role?.role}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={project_Person_Role.role.roleId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Role</Label>
        {#if project_Person_Role?.role}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={project_Person_Role.role.roleName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{project_Person_Role.role.roleName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

            </svelte:fragment>
        </FBCard>
            {/each}
        {/if}
    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">
        List of Clients <button class="btn btn-outline-primary btn-sm mb-2" on:click={ () => addClients_to_Person($detailsResponse.person) }><Icon name="plus-square"/> Add Client</button>
    </svelte:fragment>
    <svelte:fragment slot="body">
        {#if $detailsResponse?.person && $detailsResponse?.person?.clients}
            {#each $detailsResponse.person.clients as client (client.clientId)}
        <FBCard>
            <svelte:fragment slot="title">
                Client <button class="btn btn-outline-danger btn-sm"><Icon name="file-excel"/> Delete Client</button>
            </svelte:fragment>
            <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Clients.ClientId</Label>
        {#if client}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={client.clientId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Clients.ClientName</Label>
        {#if client}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={client.clientName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{client.clientName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

            </svelte:fragment>
        </FBCard>
            {/each}
        {/if}
    </svelte:fragment>
</FBCard>

                </svelte:fragment>
                </FBRootCard>
        {:else if $isLoadingDetails}
            <Spinner color="primary" />
        {/if}
    {:else}
        **hidden**
    {/if}
</Container>

<Modal isOpen={modalControllerFindPerson__manager_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Person</ModalHeader>
    <ModalBody>
        <PersonLookup on:ok={onPerson__managerFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindPerson__manager_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindProject_Person_Role__project_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Project</ModalHeader>
    <ModalBody>
        <ProjectLookup on:ok={onProject_Person_Role__projectFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindProject_Person_Role__project_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindProject_Person_Role__person_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Person</ModalHeader>
    <ModalBody>
        <PersonLookup on:ok={onProject_Person_Role__personFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindProject_Person_Role__person_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindProject_Person_Role__role_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Role</ModalHeader>
    <ModalBody>
        <RoleLookup on:ok={onProject_Person_Role__roleFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindProject_Person_Role__role_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindProject__projectType_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find ProjectType</ModalHeader>
    <ModalBody>
        <ProjectTypeLookup on:ok={onProject__projectTypeFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindProject__projectType_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>

<style>
</style>
