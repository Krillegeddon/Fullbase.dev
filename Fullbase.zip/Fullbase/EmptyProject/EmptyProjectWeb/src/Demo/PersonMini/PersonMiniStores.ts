
import { writable } from "svelte/store";
import type {
    PersonDto,
    PersonMiniFilterResponse,
    PersonMiniSearchRequest,
    PersonMiniSearchResponse,
    PersonMiniDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<PersonMiniFilterResponse>(null);
export let searchResponse = writable<PersonMiniSearchResponse>(null);
export let detailsResponse = writable<PersonMiniDetailsResponse>(null);
export let searchRequest = writable<PersonMiniSearchRequest>(null);
export let selectedRow = writable<PersonDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
