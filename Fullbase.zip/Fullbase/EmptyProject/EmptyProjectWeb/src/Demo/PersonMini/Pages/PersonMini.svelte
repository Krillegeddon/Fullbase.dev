
<script lang="ts">
    import { createEventDispatcher } from "svelte";
    import { filterResponse, searchResponse, detailsResponse } from "../PersonMiniStores";
    import PersonMiniFilter from "../Panels/PersonMiniFilter.svelte";
    import PersonMiniSearch from "../Panels/PersonMiniSearch.svelte";
    import PersonMiniQuickSearch from "../Panels/PersonMiniQuickSearch.svelte";
    import PersonMiniDetails from "../Panels/PersonMiniDetails.svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;

    // Relay back to caller...
    function onOk(c) {
        dispatch("ok", c.detail);
    }

    // Reset stores when surfing to page.
    $filterResponse = null;
    $searchResponse = null;
    $detailsResponse = null;
</script>

<PersonMiniFilter />
<hr />
<PersonMiniSearch {isModal} on:ok={onOk}/>
<hr />
<PersonMiniDetails />
