
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        Normalizer,
        NormKey,
        userAuthentication,
PersonDto,GenderDto,DepartmentDto,PersonMiniFilterRequest,PersonMiniFilterResponse,PersonMiniSearchRequest,PersonMiniSearchResponse,PersonMiniDetailsRequest,PersonMiniDetailsResponse
    } from "../../../WebApi";
    import FBSelect from "../../../Components/FBSelect.svelte";
    import FBControl from "../../../Components/FBControl.svelte";
    import FBCard from "../../../Components/FBCard.svelte";
    import FBRootCard from "../../../Components/FBRootCard.svelte";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails } from "../PersonMiniStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Card, CardHeader, CardTitle, CardBody, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean = false;
    let addCounter = -5;

import PersonLookupForManager from "./../../PersonLookupForManager/Pages/PersonLookupForManager.svelte";
import PersonLookupForManagerQuickSearch from "./../../PersonLookupForManager/Panels/PersonLookupForManagerQuickSearch.svelte";



    const addEmployees_to_Person = (parentObject: PersonDto) => {
        var o = new PersonDto();
        o.personId = addCounter;
        addCounter--;
        o.managerId = parentObject.personId;
        o.manager = parentObject;
        if (parentObject.employees == null) {
            parentObject.employees = new Array<PersonDto>();
        }
        parentObject.employees = [... parentObject.employees, o ];
        $detailsResponse = $detailsResponse; // Workaround to get stuff reloaded!
    };



    let isSaving: boolean = false;
    const onSave = async () => {
        isSaving = true;
        var copy = { ...$detailsResponse };

        //$detailsResponse = null;
        $detailsResponse = await fetchers.SavePersonMiniDetails(copy);
        isSaving = false;
    };




    /******* MODAL FOR FINDING manager for Person - START ************/
    let modalControllerFindPerson__manager_IsOpen: boolean;

    let modalPerson__manager: PersonDto;
    const openFindPerson__manager = (x: PersonDto) => {
        modalPerson__manager = x;
        modalControllerFindPerson__manager_IsOpen = true;
    };

    function onPerson__managerFound(c) {
        var person: PersonDto = c.detail;
        modalControllerFindPerson__manager_IsOpen = false;
        modalPerson__manager.manager = person;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING manager for Person - DONE ************/


</script>



<Container>
    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
        {#if $detailsResponse}
            <FBRootCard>
                <svelte:fragment slot="title">
                    Person
                </svelte:fragment>
                <svelte:fragment slot="savebutton">
                    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
                        {#if !isModal}
                            <button class="btn btn-primary" on:click={onSave}><Icon name="save" /> Save</button>
                        {/if}
                        {#if isSaving}
                            <Spinner color="primary" />
                        {/if}
                    {/if}
                </svelte:fragment>
                <svelte:fragment slot="body">
        
<Row> <!-- props container markup! -->

{#if userAuthentication.isAdmin}
    
<div class="col-5">
    <FormGroup>
        <Label>Salary</Label>
        {#if $detailsResponse?.person}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.salary} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin}
    
<div class="col-5">
    <FormGroup>
        <Label>Salary</Label>
        {#if $detailsResponse?.person}
            <span class="form-control">{$detailsResponse.person.salary}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isAdmin}
    
<div class="col-5">
    <FormGroup>
        <Label>Manager <span style="cursor:pointer;" on:click={() => openFindPerson__manager($detailsResponse.person)}
                    ><Icon name="search" /></span></Label>
        {#if $detailsResponse?.person}
            <PersonLookupForManagerQuickSearch bind:selectedObject={$detailsResponse.person.manager} selectedId={0} isReadOnly={false}/>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Manager</Label>
        {#if $detailsResponse?.person}
            <PersonLookupForManagerQuickSearch bind:selectedObject={$detailsResponse.person.manager} selectedId={0} isReadOnly={true}/>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        {#if $detailsResponse?.person}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.gender}
        objects={$detailsResponse.genders}
        let:object
        isReadOnly={false}
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        {#if $detailsResponse?.person}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.gender}
        objects={$detailsResponse.genders}
        let:object
        isReadOnly={true}
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>User Name</Label>
        {#if $detailsResponse?.person}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.userName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>User Name</Label>
        {#if $detailsResponse?.person}
            <span class="form-control">{$detailsResponse.person.userName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isAdmin}
    
<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        {#if $detailsResponse?.person}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.department}
        objects={$detailsResponse.departments}
        let:object
        isReadOnly={false}
    >
        <option>{object.departmentName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin}
    
<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        {#if $detailsResponse?.person}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.department}
        objects={$detailsResponse.departments}
        let:object
        isReadOnly={true}
    >
        <option>{object.departmentName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->
<!-- none Person.Gender --><!-- none Person.Department --><!-- none Person.Manager -->
<FBCard>
    <svelte:fragment slot="title">
        List of Employees <button class="btn btn-outline-primary btn-sm mb-2" on:click={ () => addEmployees_to_Person($detailsResponse.person) }><Icon name="plus-square"/> Add Person</button>
    </svelte:fragment>
    <svelte:fragment slot="body">
        {#if $detailsResponse?.person && $detailsResponse?.person?.employees}
            {#each $detailsResponse.person.employees as person (person.personId)}
        <FBCard>
            <svelte:fragment slot="title">
                Person <button class="btn btn-outline-danger btn-sm"><Icon name="file-excel"/> Delete Person</button>
            </svelte:fragment>
            <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>User Name</Label>
        {#if person}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={person.userName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>User Name</Label>
        {#if person}
            <span class="form-control">{person.userName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Salary</Label>
        {#if person}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={person.salary} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Salary</Label>
        {#if person}
            <span class="form-control">{person.salary}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        {#if person}
            
    <FBSelect
        css="form-control"
        bind:value={person.gender}
        objects={$detailsResponse.genders}
        let:object
        isReadOnly={false}
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        {#if person}
            
    <FBSelect
        css="form-control"
        bind:value={person.gender}
        objects={$detailsResponse.genders}
        let:object
        isReadOnly={true}
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        {#if person}
            
    <FBSelect
        css="form-control"
        bind:value={person.department}
        objects={$detailsResponse.departments}
        let:object
        isReadOnly={false}
    >
        <option>{object.departmentName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        {#if person}
            
    <FBSelect
        css="form-control"
        bind:value={person.department}
        objects={$detailsResponse.departments}
        let:object
        isReadOnly={true}
    >
        <option>{object.departmentName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->
<!-- none Person.Employees.Gender --><!-- none Person.Employees.Department -->
            </svelte:fragment>
        </FBCard>
            {/each}
        {/if}
    </svelte:fragment>
</FBCard>

                </svelte:fragment>
                </FBRootCard>
        {:else if $isLoadingDetails}
            <Spinner color="primary" />
        {/if}
    {:else}
        **hidden**
    {/if}
</Container>

<Modal isOpen={modalControllerFindPerson__manager_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Person</ModalHeader>
    <ModalBody>
        <PersonLookupForManager on:ok={onPerson__managerFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindPerson__manager_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>

<style>
</style>
