
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        Normalizer,
        NormKey,
PersonDto,GenderDto,DepartmentDto,PersonMiniFilterRequest,PersonMiniFilterResponse,PersonMiniSearchRequest,PersonMiniSearchResponse
    } from "../../../WebApi";
    import {createEventDispatcher} from "svelte";
    import { filterResponse,searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingSearch } from "../PersonMiniStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import { Icon } from "sveltestrap";
    const dispatch = createEventDispatcher();

    //export let isModal: boolean;
    let addCounter = -1;

import PersonLookup from "./../../PersonLookup/Pages/PersonLookup.svelte";
import PersonLookupQuickSearch from "./../../PersonLookup/Panels/PersonLookupQuickSearch.svelte";



    const addEmployees_to_Person = (parentObject: PersonDto) => {
        var o = new PersonDto();
        o.personId = addCounter;
        addCounter--;
        o.managerId = parentObject.personId;
        o.manager = parentObject;
        if (parentObject.employees == null) {
            parentObject.employees = new Array<PersonDto>();
        }
        parentObject.employees = [... parentObject.employees, o ];
        $detailsResponse = $detailsResponse; // Workaround to get stuff reloaded!
    };



    onMount(async () => {
        var req = new PersonMiniFilterRequest(); // Default Filter Request
        $filterResponse = await fetchers.GetPersonMiniFilter(req);
        $searchRequest = new PersonMiniSearchRequest();
        $searchRequest.personId = new IntClause();
        $searchRequest.userName = new StringClause();
        $searchRequest.salary = new IntClause();
        $searchRequest.gender_genderId = new IntClause();
        $searchRequest.gender_genderDescription = new StringClause();
        $searchRequest.department_departmentId = new IntClause();
        $searchRequest.department_departmentName = new StringClause();
        $searchRequest.manager_personId = new IntClause();
        $searchRequest.manager_userName = new StringClause();
        $searchRequest.manager_salary = new IntClause();

    });



    const onSearch = async () => {
        $isLoadingSearch = true;
        $searchResponse = null;
        $selectedRow = null;
        $detailsResponse = null;
        $searchResponse = await fetchers.GetPersonMiniSearch($searchRequest);
        $isLoadingSearch = false;
    };




    /******* MODAL FOR SEARCHING manager_personId for PersonMiniSearchRequest - START ************/
    let modalControllerFindPersonMiniSearchRequest__manager_personId_IsOpen: boolean;

    let modalPersonMiniSearchRequest__manager_personId: PersonMiniSearchRequest;
    const openFindPersonMiniSearchRequest__manager_personId = (x: PersonMiniSearchRequest) => {
        modalPersonMiniSearchRequest__manager_personId = x;
        modalControllerFindPersonMiniSearchRequest__manager_personId_IsOpen = true;
    };

    let manager_personId: PersonDto = null;
    function onPersonMiniSearchRequest__manager_personIdFound(c) {
        manager_personId = c.detail;
        modalControllerFindPersonMiniSearchRequest__manager_personId_IsOpen = false;
        modalPersonMiniSearchRequest__manager_personId.manager_personId.exactMatch = manager_personId.personId;
        $searchRequest = $searchRequest;
    }
    /******* MODAL FOR SEARCHING manager_personId for PersonMiniSearchRequest - DONE ************/


</script>



    <Container>
{#if $filterResponse}
        <form on:submit|preventDefault={onSearch}>
            <Row>

<div class="col-10">
    <FormGroup>
        <Label>Person.QuickSearch</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.quickSearch} />
    </FormGroup>
</div>

            </Row>
            <Row>

<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        
        <select class="form-control" bind:value={$searchRequest.department_departmentId.exactMatch}>
            <option value={null}>- all -</option>
            {#each $filterResponse.departments as department}
                <option value={department.departmentId}>{department.departmentName}</option>
            {/each}
        </select>

    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        
        <select class="form-control" bind:value={$searchRequest.gender_genderId.exactMatch}>
            <option value={null}>- all -</option>
            {#each $filterResponse.genders as gender}
                <option value={gender.genderId}>{gender.genderDescription}</option>
            {/each}
        </select>

    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Manager <span style="cursor:pointer;" on:click={() => openFindPersonMiniSearchRequest__manager_personId($searchRequest)}
                    ><Icon name="search" /></span></Label>
        <PersonLookupQuickSearch selectedObject={manager_personId} bind:selectedId={$searchRequest.manager_personId.exactMatch} isReadOnly={false} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label><b style="color:yellow!>>;">User Name</b></Label>
        <input style="color:green;" autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.userName.exactMatch} />
    </FormGroup>
</div>

            </Row>

<Row>
    <div class="col-2">
        <Button color="primary"><Icon name="search"/> Search</Button>
    </div>
</Row>

        </form>
{:else}
    <Spinner color="primary" />
{/if}
    </Container>

<Modal isOpen={modalControllerFindPersonMiniSearchRequest__manager_personId_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find manager_personId</ModalHeader>
    <ModalBody>
        <PersonLookup on:ok={onPersonMiniSearchRequest__manager_personIdFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindPersonMiniSearchRequest__manager_personId_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>

<style>
</style>
