
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        Normalizer,
        NormKey,
PersonDto,GenderDto,DepartmentDto,PersonMiniFilterRequest,PersonMiniFilterResponse,PersonMiniSearchRequest,PersonMiniSearchResponse,PersonMiniDetailsRequest,PersonMiniDetailsResponse
    } from "../../../WebApi";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails, isLoadingSearch } from "../PersonMiniStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;
    let addCounter = -3;


    const addEmployees_to_Person = (parentObject: PersonDto) => {
        var o = new PersonDto();
        o.personId = addCounter;
        addCounter--;
        o.managerId = parentObject.personId;
        o.manager = parentObject;
        if (parentObject.employees == null) {
            parentObject.employees = new Array<PersonDto>();
        }
        parentObject.employees = [... parentObject.employees, o ];
        $detailsResponse = $detailsResponse; // Workaround to get stuff reloaded!
    };
    


    const onDetails = async (x: PersonDto) => {
        var detailsRequest = new PersonMiniDetailsRequest();
        detailsRequest.person = x;
        $selectedRow = x;
        $detailsResponse = null;

        if (isModal) {
            dispatch("ok", x);
            return;
        }

        if ($selectedRow != null) {
            $isLoadingDetails = true;
            $detailsResponse = await fetchers.GetPersonMiniDetails(detailsRequest);
            $isLoadingDetails = false;
        }
    };


    const addPerson = async () => {
        $detailsResponse = null;
        var dr = new PersonMiniDetailsResponse();
        dr.request = new PersonMiniDetailsRequest();
        dr.request.person = new PersonDto();
        dr.request.person.personId = -1;
        dr.person = new PersonDto();
        dr.person.personId = -1;

        var detailsRequest = new PersonMiniDetailsRequest();
        detailsRequest.person = new PersonDto();
        detailsRequest.person.personId = -1;
        $selectedRow = null;
        $detailsResponse = null;
        $isLoadingDetails = true;
        $detailsResponse = await fetchers.GetPersonMiniDetails(detailsRequest);
        $isLoadingDetails = false;
    };


</script>


<Container fluid>

    <button class="btn btn-outline-primary btn-sm" on:click={addPerson}><Icon name="plus-square" /> Add Person</button>
{#if $searchResponse}
    <Table>
        <thead>
            <tr>
<th>User Name</th>
<th>Gender</th>
<th>Department</th>
<th>Person.Manager.PersonId</th>
<th>Manager</th>

            </tr>
        </thead>
        <tbody>
        {#each $searchResponse.persons as row (row.personId)}
            <tr
                on:click={() => onDetails(row)}
                class="clickable"
                class:btn-primary={$selectedRow != null && row.personId === $selectedRow.personId}
            >
<td>{row.userName ? row.userName : "--"}</td>
<td>{row.gender?.genderDescription ? row.gender?.genderDescription : "--"}</td>
<td>{row.department?.departmentName ? row.department?.departmentName : "--"}</td>
<td>{row.manager?.personId ? row.manager?.personId : "--"}</td>
<td>{row.manager?.userName ? row.manager?.userName : "--"}</td>

            </tr>
        {/each}
        </tbody>
    </Table>
{:else if $isLoadingSearch}
    <Spinner color="primary" />
{/if}
</Container>

<style>
    .clickable {
        cursor: pointer;
    }
</style>
