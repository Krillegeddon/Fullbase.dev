
<script lang="ts">
    import { onMount } from "svelte";
    import { Table } from "sveltestrap";
    import { fetchers, GenderLookupSearchRequest, GenderLookupSearchResponse, GenderDto } from "../../../WebApi";

    let value = "";
    export let selectedObject: GenderDto = null;
    export let selectedId: number;
    export let isReadOnly: boolean;

    onMount(async () => {
        if (selectedObject == null) {
            value = "";
            return;
        }
        value = selectedObject.genderDescription;
    });

    var searchResult: GenderLookupSearchResponse = null;

    async function onKeydown() {
        if (value.length < 2) {
            searchResult = null;
            myPopup.style.display = "none";
            return;
        }
        myPopup.style.display = "";
        var req = new GenderLookupSearchRequest();
        req.quickSearch = value;
        searchResult = await fetchers.GetGenderLookupSearch(req);
    }

    let myInput: any;
    let myPopup: any;
    let isShown = false;
    function onFocus() {
        isShown = true;
        var rect = myInput.getBoundingClientRect();

        if (value.length >= 2) myPopup.style.display = "";

        var x = myInput.offsetLeft;
        var y = myInput.offsetTop * 1 + rect.height * 1;
        var width = rect.width;
        myPopup.style.left = x + "px";
        myPopup.style.top = y + "px";
        myPopup.style.minWidth = width + "px";
        myPopup.style.minHeight = "200" + "px";
    }

    function hide() {
        if (value == "") {
            selectedId = null;
            selectedObject = null;
        }
        myPopup.style.display = "none";
    }

    function onBlur() {
        isShown = false;
        setTimeout(hide, 300);
    }

    $: selectedObject && redraw();
    function redraw() {
        value = selectedObject.genderDescription;
    }

    function onSelect(o: GenderDto) {
        selectedObject = o;
        selectedId = o.genderId;
        value = selectedObject.genderDescription;
    }
</script>

{#if isReadOnly == false}
    <input
        type="text"
        bind:value
        on:keyup={onKeydown}
        on:focus={onFocus}
        on:blur={onBlur}
        autocomplete="new-password"
        bind:this={myInput}
        class="form-control"
    />
{:else}
<span class="form-control">{value}</span>
{/if}

<div
    bind:this={myPopup}
    class="popover fade bs-popover-bottom show"
    role="tooltip"
    x-placement="bottom"
    data-popper-placement="bottom"
    style="position: absolute; inset: 0px auto auto 0px; margin: 0px; display:none;"
>
    <div>
        {#if searchResult}
            <Table hover>
                <tbody>
                    {#each searchResult.genders as row}
                        <tr on:click={() => onSelect(row)} style="cursor:pointer">
                            <td>{row.genderDescription}</td>
                        </tr>
                    {/each}
                </tbody>
            </Table>
        {/if}
    </div>
</div>
