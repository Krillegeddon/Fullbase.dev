
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        Normalizer,
        NormKey,
        userAuthentication,
GenderDto,GenderLookupFilterRequest,GenderLookupFilterResponse,GenderLookupSearchRequest,GenderLookupSearchResponse,GenderLookupDetailsRequest,GenderLookupDetailsResponse
    } from "../../../WebApi";
    import FBSelect from "../../../Components/FBSelect.svelte";
    import FBControl from "../../../Components/FBControl.svelte";
    import FBCard from "../../../Components/FBCard.svelte";
    import FBRootCard from "../../../Components/FBRootCard.svelte";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails } from "../GenderLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Card, CardHeader, CardTitle, CardBody, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean = false;
    let addCounter = -5;





    let isSaving: boolean = false;
    const onSave = async () => {
        isSaving = true;
        var copy = { ...$detailsResponse };

        //$detailsResponse = null;
        $detailsResponse = await fetchers.SaveGenderLookupDetails(copy);
        isSaving = false;
    };




</script>



<Container>
    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
        {#if $detailsResponse}
            <FBRootCard>
                <svelte:fragment slot="title">
                    Gender
                </svelte:fragment>
                <svelte:fragment slot="savebutton">
                    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
                        {#if !isModal}
                            <button class="btn btn-primary" on:click={onSave}><Icon name="save" /> Save</button>
                        {/if}
                        {#if isSaving}
                            <Spinner color="primary" />
                        {/if}
                    {/if}
                </svelte:fragment>
                <svelte:fragment slot="body">
        
<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        {#if $detailsResponse?.gender}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.gender.genderId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        {#if $detailsResponse?.gender}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.gender.genderDescription} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.gender.genderDescription}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

                </svelte:fragment>
                </FBRootCard>
        {:else if $isLoadingDetails}
            <Spinner color="primary" />
        {/if}
    {:else}
        **hidden**
    {/if}
</Container>

<style>
</style>
