
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        Normalizer,
        NormKey,
GenderDto,GenderLookupFilterRequest,GenderLookupFilterResponse,GenderLookupSearchRequest,GenderLookupSearchResponse,GenderLookupDetailsRequest,GenderLookupDetailsResponse
    } from "../../../WebApi";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails, isLoadingSearch } from "../GenderLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;
    let addCounter = -3;

    


    const onDetails = async (x: GenderDto) => {
        var detailsRequest = new GenderLookupDetailsRequest();
        detailsRequest.gender = x;
        $selectedRow = x;
        $detailsResponse = null;

        if (isModal) {
            dispatch("ok", x);
            return;
        }

        if ($selectedRow != null) {
            $isLoadingDetails = true;
            $detailsResponse = await fetchers.GetGenderLookupDetails(detailsRequest);
            $isLoadingDetails = false;
        }
    };


    const addGender = async () => {
        $detailsResponse = null;
        var dr = new GenderLookupDetailsResponse();
        dr.request = new GenderLookupDetailsRequest();
        dr.request.gender = new GenderDto();
        dr.request.gender.genderId = -1;
        dr.gender = new GenderDto();
        dr.gender.genderId = -1;

        var detailsRequest = new GenderLookupDetailsRequest();
        detailsRequest.gender = new GenderDto();
        detailsRequest.gender.genderId = -1;
        $selectedRow = null;
        $detailsResponse = null;
        $isLoadingDetails = true;
        $detailsResponse = await fetchers.GetGenderLookupDetails(detailsRequest);
        $isLoadingDetails = false;
    };


</script>


<Container fluid>

    <button class="btn btn-outline-primary btn-sm" on:click={addGender}><Icon name="plus-square" /> Add Gender</button>
{#if $searchResponse}
    <Table>
        <thead>
            <tr>
<th>Person.Gender.GenderId</th>
<th>Gender</th>

            </tr>
        </thead>
        <tbody>
        {#each $searchResponse.genders as row (row.genderId)}
            <tr
                on:click={() => onDetails(row)}
                class="clickable"
                class:btn-primary={$selectedRow != null && row.genderId === $selectedRow.genderId}
            >
<td>{row.genderId ? row.genderId : "--"}</td>
<td>{row.genderDescription ? row.genderDescription : "--"}</td>

            </tr>
        {/each}
        </tbody>
    </Table>
{:else if $isLoadingSearch}
    <Spinner color="primary" />
{/if}
</Container>

<style>
    .clickable {
        cursor: pointer;
    }
</style>
