
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        DateTimeClause,
        Normalizer,
        NormKey,
GenderDto,GenderLookupFilterRequest,GenderLookupFilterResponse,GenderLookupSearchRequest,GenderLookupSearchResponse
    } from "../../../WebApi";
    import {createEventDispatcher} from "svelte";
    import { filterResponse,searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingSearch } from "../GenderLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import { Icon } from "sveltestrap";
    const dispatch = createEventDispatcher();

    //export let isModal: boolean;
    let addCounter = -1;





    onMount(async () => {
        $filterResponse = new GenderLookupFilterResponse();
        $searchRequest = new GenderLookupSearchRequest();
        $searchRequest.genderId = new IntClause();
        $searchRequest.genderDescription = new StringClause();

    });



    const onSearch = async () => {
        $isLoadingSearch = true;
        $searchResponse = null;
        $selectedRow = null;
        $detailsResponse = null;
        $searchResponse = await fetchers.GetGenderLookupSearch($searchRequest);
        $isLoadingSearch = false;
    };




</script>



    <Container>
{#if $filterResponse}
        <form on:submit|preventDefault={onSearch}>
            <Row>

<div class="col-10">
    <FormGroup>
        <Label>Gender.QuickSearch</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.quickSearch} />
    </FormGroup>
</div>

            </Row>
            <Row>

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.genderId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.genderDescription.exactMatch} />
    </FormGroup>
</div>

            </Row>

<Row>
    <div class="col-2">
        <Button color="primary"><Icon name="search"/> Search</Button>
    </div>
</Row>

        </form>
{:else}
    <Spinner color="primary" />
{/if}
    </Container>

<style>
</style>
