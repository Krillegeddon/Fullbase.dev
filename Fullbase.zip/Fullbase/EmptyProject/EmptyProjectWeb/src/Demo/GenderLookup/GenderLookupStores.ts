
import { writable } from "svelte/store";
import type {
    GenderDto,
    GenderLookupFilterResponse,
    GenderLookupSearchRequest,
    GenderLookupSearchResponse,
    GenderLookupDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<GenderLookupFilterResponse>(null);
export let searchResponse = writable<GenderLookupSearchResponse>(null);
export let detailsResponse = writable<GenderLookupDetailsResponse>(null);
export let searchRequest = writable<GenderLookupSearchRequest>(null);
export let selectedRow = writable<GenderDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
