
<script lang="ts">
    import { createEventDispatcher } from "svelte";
    import { filterResponse, searchResponse, detailsResponse } from "../GenderLookupStores";
    import GenderLookupFilter from "../Panels/GenderLookupFilter.svelte";
    import GenderLookupSearch from "../Panels/GenderLookupSearch.svelte";
    import GenderLookupQuickSearch from "../Panels/GenderLookupQuickSearch.svelte";
    import GenderLookupDetails from "../Panels/GenderLookupDetails.svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;

    // Relay back to caller...
    function onOk(c) {
        dispatch("ok", c.detail);
    }

    // Reset stores when surfing to page.
    $filterResponse = null;
    $searchResponse = null;
    $detailsResponse = null;
</script>

<GenderLookupFilter />
<hr />
<GenderLookupSearch {isModal} on:ok={onOk}/>
<hr />
<GenderLookupDetails />
