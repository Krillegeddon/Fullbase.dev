
import { writable } from "svelte/store";
import type {
    RoleDto,
    RoleLookupFilterResponse,
    RoleLookupSearchRequest,
    RoleLookupSearchResponse,
    RoleLookupDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<RoleLookupFilterResponse>(null);
export let searchResponse = writable<RoleLookupSearchResponse>(null);
export let detailsResponse = writable<RoleLookupDetailsResponse>(null);
export let searchRequest = writable<RoleLookupSearchRequest>(null);
export let selectedRow = writable<RoleDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
