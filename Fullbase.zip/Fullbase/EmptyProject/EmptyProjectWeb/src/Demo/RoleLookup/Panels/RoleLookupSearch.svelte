
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        Normalizer,
        NormKey,
RoleDto,RoleLookupFilterRequest,RoleLookupFilterResponse,RoleLookupSearchRequest,RoleLookupSearchResponse,RoleLookupDetailsRequest,RoleLookupDetailsResponse
    } from "../../../WebApi";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails, isLoadingSearch } from "../RoleLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;
    let addCounter = -3;

    


    const onDetails = async (x: RoleDto) => {
        var detailsRequest = new RoleLookupDetailsRequest();
        detailsRequest.role = x;
        $selectedRow = x;
        $detailsResponse = null;

        if (isModal) {
            dispatch("ok", x);
            return;
        }

        if ($selectedRow != null) {
            $isLoadingDetails = true;
            $detailsResponse = await fetchers.GetRoleLookupDetails(detailsRequest);
            $isLoadingDetails = false;
        }
    };


    const addRole = async () => {
        $detailsResponse = null;
        var dr = new RoleLookupDetailsResponse();
        dr.request = new RoleLookupDetailsRequest();
        dr.request.role = new RoleDto();
        dr.request.role.roleId = -1;
        dr.role = new RoleDto();
        dr.role.roleId = -1;

        var detailsRequest = new RoleLookupDetailsRequest();
        detailsRequest.role = new RoleDto();
        detailsRequest.role.roleId = -1;
        $selectedRow = null;
        $detailsResponse = null;
        $isLoadingDetails = true;
        $detailsResponse = await fetchers.GetRoleLookupDetails(detailsRequest);
        $isLoadingDetails = false;
    };


</script>


<Container fluid>

    <button class="btn btn-outline-primary btn-sm" on:click={addRole}><Icon name="plus-square" /> Add Role</button>
{#if $searchResponse}
    <Table>
        <thead>
            <tr>
<th>Project.Project_Person_Roles.Role.RoleId</th>
<th>Role</th>

            </tr>
        </thead>
        <tbody>
        {#each $searchResponse.roles as row (row.roleId)}
            <tr
                on:click={() => onDetails(row)}
                class="clickable"
                class:btn-primary={$selectedRow != null && row.roleId === $selectedRow.roleId}
            >
<td>{row.roleId ? row.roleId : ""}</td>
<td>{row.roleName ? row.roleName : ""}</td>

            </tr>
        {/each}
        </tbody>
    </Table>
{:else if $isLoadingSearch}
    <Spinner color="primary" />
{/if}
</Container>

<style>
    .clickable {
        cursor: pointer;
    }
</style>
