
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        Normalizer,
        NormKey,
DepartmentDto,DepartmentLookupFilterRequest,DepartmentLookupFilterResponse,DepartmentLookupSearchRequest,DepartmentLookupSearchResponse,DepartmentLookupDetailsRequest,DepartmentLookupDetailsResponse
    } from "../../../WebApi";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails, isLoadingSearch } from "../DepartmentLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;
    let addCounter = -3;

    


    const onDetails = async (x: DepartmentDto) => {
        var detailsRequest = new DepartmentLookupDetailsRequest();
        detailsRequest.department = x;
        $selectedRow = x;
        $detailsResponse = null;

        if (isModal) {
            dispatch("ok", x);
            return;
        }

        if ($selectedRow != null) {
            $isLoadingDetails = true;
            $detailsResponse = await fetchers.GetDepartmentLookupDetails(detailsRequest);
            $isLoadingDetails = false;
        }
    };


    const addDepartment = async () => {
        $detailsResponse = null;
        var dr = new DepartmentLookupDetailsResponse();
        dr.request = new DepartmentLookupDetailsRequest();
        dr.request.department = new DepartmentDto();
        dr.request.department.departmentId = -1;
        dr.department = new DepartmentDto();
        dr.department.departmentId = -1;

        var detailsRequest = new DepartmentLookupDetailsRequest();
        detailsRequest.department = new DepartmentDto();
        detailsRequest.department.departmentId = -1;
        $selectedRow = null;
        $detailsResponse = null;
        $isLoadingDetails = true;
        $detailsResponse = await fetchers.GetDepartmentLookupDetails(detailsRequest);
        $isLoadingDetails = false;
    };


</script>


<Container fluid>

    <button class="btn btn-outline-primary btn-sm" on:click={addDepartment}><Icon name="plus-square" /> Add Department</button>
{#if $searchResponse}
    <Table>
        <thead>
            <tr>
<th>Person.Department.DepartmentId</th>
<th>Department</th>

            </tr>
        </thead>
        <tbody>
        {#each $searchResponse.departments as row (row.departmentId)}
            <tr
                on:click={() => onDetails(row)}
                class="clickable"
                class:btn-primary={$selectedRow != null && row.departmentId === $selectedRow.departmentId}
            >
<td>{row.departmentId ? row.departmentId : ""}</td>
<td>{row.departmentName ? row.departmentName : ""}</td>

            </tr>
        {/each}
        </tbody>
    </Table>
{:else if $isLoadingSearch}
    <Spinner color="primary" />
{/if}
</Container>

<style>
    .clickable {
        cursor: pointer;
    }
</style>
