
<script lang="ts">
    import { createEventDispatcher } from "svelte";
    import { filterResponse, searchResponse, detailsResponse } from "../DepartmentLookupStores";
    import DepartmentLookupFilter from "../Panels/DepartmentLookupFilter.svelte";
    import DepartmentLookupSearch from "../Panels/DepartmentLookupSearch.svelte";
    import DepartmentLookupQuickSearch from "../Panels/DepartmentLookupQuickSearch.svelte";
    import DepartmentLookupDetails from "../Panels/DepartmentLookupDetails.svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;

    // Relay back to caller...
    function onOk(c) {
        dispatch("ok", c.detail);
    }

    // Reset stores when surfing to page.
    $filterResponse = null;
    $searchResponse = null;
    $detailsResponse = null;
</script>

<DepartmentLookupFilter />
<hr />
<DepartmentLookupSearch {isModal} on:ok={onOk}/>
<hr />
<DepartmentLookupDetails />
