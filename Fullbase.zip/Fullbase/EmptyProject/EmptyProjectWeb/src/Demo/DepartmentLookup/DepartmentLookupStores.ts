
import { writable } from "svelte/store";
import type {
    DepartmentDto,
    DepartmentLookupFilterResponse,
    DepartmentLookupSearchRequest,
    DepartmentLookupSearchResponse,
    DepartmentLookupDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<DepartmentLookupFilterResponse>(null);
export let searchResponse = writable<DepartmentLookupSearchResponse>(null);
export let detailsResponse = writable<DepartmentLookupDetailsResponse>(null);
export let searchRequest = writable<DepartmentLookupSearchRequest>(null);
export let selectedRow = writable<DepartmentDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
