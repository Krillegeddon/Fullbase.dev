
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        Normalizer,
        NormKey,
        userAuthentication,
ProjectDto,ProjectTypeDto,ProjectLookupFilterRequest,ProjectLookupFilterResponse,ProjectLookupSearchRequest,ProjectLookupSearchResponse,ProjectLookupDetailsRequest,ProjectLookupDetailsResponse
    } from "../../../WebApi";
    import FBSelect from "../../../Components/FBSelect.svelte";
    import FBControl from "../../../Components/FBControl.svelte";
    import FBCard from "../../../Components/FBCard.svelte";
    import FBRootCard from "../../../Components/FBRootCard.svelte";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails } from "../ProjectLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Card, CardHeader, CardTitle, CardBody, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean = false;
    let addCounter = -5;





    let isSaving: boolean = false;
    const onSave = async () => {
        isSaving = true;
        var copy = { ...$detailsResponse };

        //$detailsResponse = null;
        $detailsResponse = await fetchers.SaveProjectLookupDetails(copy);
        isSaving = false;
    };




</script>



<Container>
    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
        {#if $detailsResponse}
            <FBRootCard>
                <svelte:fragment slot="title">
                    Project
                </svelte:fragment>
                <svelte:fragment slot="savebutton">
                    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
                        {#if !isModal}
                            <button class="btn btn-primary" on:click={onSave}><Icon name="save" /> Save</button>
                        {/if}
                        {#if isSaving}
                            <Spinner color="primary" />
                        {/if}
                    {/if}
                </svelte:fragment>
                <svelte:fragment slot="body">
        
<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectId</Label>
        {#if $detailsResponse?.project}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.project.projectId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project Name</Label>
        {#if $detailsResponse?.project}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.project.projectName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project Name</Label>
        {#if $detailsResponse?.project}
            <span class="form-control">{$detailsResponse.project.projectName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Is Pro-Bono</Label>
        {#if $detailsResponse?.project}
            <div class="form-control">
    <input autocomplete="new-password" class="form-check-input" type="checkbox" bind:checked={$detailsResponse.project.isProBono} />
</div>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Is Pro-Bono</Label>
        {#if $detailsResponse?.project}
            <span class="form-control">{$detailsResponse.project.isProBono}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Deadline</Label>
        {#if $detailsResponse?.project}
            <DateTimeInput css="form-control" bind:value={$detailsResponse.project.deadline} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Deadline</Label>
        {#if $detailsResponse?.project}
            <span class="form-control">{$detailsResponse.project.deadline}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project Type</Label>
        {#if $detailsResponse?.project}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.project.projectType}
        objects={$detailsResponse.projectTypes}
        let:object
        isReadOnly={false}
    >
        <option>{object.projectTypeName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project Type</Label>
        {#if $detailsResponse?.project}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.project.projectType}
        objects={$detailsResponse.projectTypes}
        let:object
        isReadOnly={true}
    >
        <option>{object.projectTypeName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">ProjectType</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectType.ProjectTypeId</Label>
        {#if $detailsResponse?.project?.projectType}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.project.projectType.projectTypeId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectType.ProjectTypeName</Label>
        {#if $detailsResponse?.project?.projectType}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.project.projectType.projectTypeName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectType.ProjectTypeName</Label>
        {#if $detailsResponse?.project?.projectType}
            <span class="form-control">{$detailsResponse.project.projectType.projectTypeName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

                </svelte:fragment>
                </FBRootCard>
        {:else if $isLoadingDetails}
            <Spinner color="primary" />
        {/if}
    {:else}
        **hidden**
    {/if}
</Container>

<style>
</style>
