
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        DateTimeClause,
        Normalizer,
        NormKey,
ProjectDto,ProjectTypeDto,ProjectLookupFilterRequest,ProjectLookupFilterResponse,ProjectLookupSearchRequest,ProjectLookupSearchResponse
    } from "../../../WebApi";
    import {createEventDispatcher} from "svelte";
    import { filterResponse,searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingSearch } from "../ProjectLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import { Icon } from "sveltestrap";
    const dispatch = createEventDispatcher();

    //export let isModal: boolean;
    let addCounter = -1;





    onMount(async () => {
        var req = new ProjectLookupFilterRequest(); // Default Filter Request
        $filterResponse = await fetchers.GetProjectLookupFilter(req);
        $searchRequest = new ProjectLookupSearchRequest();
        $searchRequest.projectId = new IntClause();
        $searchRequest.projectName = new StringClause();
        $searchRequest.isProBono = new BoolClause();
        $searchRequest.deadline = new DateTimeClause();
        $searchRequest.projectType_projectTypeId = new IntClause();
        $searchRequest.projectType_projectTypeName = new StringClause();

    });



    const onSearch = async () => {
        $isLoadingSearch = true;
        $searchResponse = null;
        $selectedRow = null;
        $detailsResponse = null;
        $searchResponse = await fetchers.GetProjectLookupSearch($searchRequest);
        $isLoadingSearch = false;
    };




</script>



    <Container>
{#if $filterResponse}
        <form on:submit|preventDefault={onSearch}>
            <Row>

<div class="col-10">
    <FormGroup>
        <Label>Quick Search</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.quickSearch} />
    </FormGroup>
</div>

            </Row>
            <Row>

<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.projectId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project Type</Label>
        
        <select class="form-control" bind:value={$searchRequest.projectType_projectTypeId.exactMatch}>
            <option value={null}>- all -</option>
            {#each $filterResponse.projectTypes as projectType}
                <option value={projectType.projectTypeId}>{projectType.projectTypeName}</option>
            {/each}
        </select>

    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project Name</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.projectName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Is Pro-Bono</Label>
        
<select class="form-control" bind:value={$searchRequest.isProBono.exactMatch}>
    <option value={null}></option>
    <option value={true}>true</option>
    <option value={false}>false</option>
</select>
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Deadline</Label>
        <DateTimeInput css="form-control" bind:value={$searchRequest.deadline.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectType.ProjectTypeId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.projectType_projectTypeId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectType.ProjectTypeName</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.projectType_projectTypeName.exactMatch} />
    </FormGroup>
</div>

            </Row>

<Row>
    <div class="col-2">
        <Button color="primary"><Icon name="search"/> Search</Button>
    </div>
</Row>

        </form>
{:else}
    <Spinner color="primary" />
{/if}
    </Container>

<style>
</style>
