
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        Normalizer,
        NormKey,
ProjectDto,ProjectTypeDto,ProjectLookupFilterRequest,ProjectLookupFilterResponse,ProjectLookupSearchRequest,ProjectLookupSearchResponse,ProjectLookupDetailsRequest,ProjectLookupDetailsResponse
    } from "../../../WebApi";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails, isLoadingSearch } from "../ProjectLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;
    let addCounter = -3;

    


    const onDetails = async (x: ProjectDto) => {
        var detailsRequest = new ProjectLookupDetailsRequest();
        detailsRequest.project = x;
        $selectedRow = x;
        $detailsResponse = null;

        if (isModal) {
            dispatch("ok", x);
            return;
        }

        if ($selectedRow != null) {
            $isLoadingDetails = true;
            $detailsResponse = await fetchers.GetProjectLookupDetails(detailsRequest);
            $isLoadingDetails = false;
        }
    };


    const addProject = async () => {
        $detailsResponse = null;
        var dr = new ProjectLookupDetailsResponse();
        dr.request = new ProjectLookupDetailsRequest();
        dr.request.project = new ProjectDto();
        dr.request.project.projectId = -1;
        dr.project = new ProjectDto();
        dr.project.projectId = -1;

        var detailsRequest = new ProjectLookupDetailsRequest();
        detailsRequest.project = new ProjectDto();
        detailsRequest.project.projectId = -1;
        $selectedRow = null;
        $detailsResponse = null;
        $isLoadingDetails = true;
        $detailsResponse = await fetchers.GetProjectLookupDetails(detailsRequest);
        $isLoadingDetails = false;
    };


</script>


<Container fluid>

    <button class="btn btn-outline-primary btn-sm" on:click={addProject}><Icon name="plus-square" /> Add Project</button>
{#if $searchResponse}
    <Table>
        <thead>
            <tr>
<th>Project.ProjectId</th>
<th>Project Name</th>
<th>Is Pro-Bono</th>
<th>Deadline</th>
<th>Project.ProjectType.ProjectTypeId</th>
<th>Project.ProjectType.ProjectTypeName</th>

            </tr>
        </thead>
        <tbody>
        {#each $searchResponse.projects as row (row.projectId)}
            <tr
                on:click={() => onDetails(row)}
                class="clickable"
                class:btn-primary={$selectedRow != null && row.projectId === $selectedRow.projectId}
            >
<td>{row.projectId ? row.projectId : "--"}</td>
<td>{row.projectName ? row.projectName : "--"}</td>
<td>{row.isProBono ? row.isProBono : "--"}</td>
<td>{row.deadline ? row.deadline : "--"}</td>
<td>{row.projectType?.projectTypeId ? row.projectType?.projectTypeId : "--"}</td>
<td>{row.projectType?.projectTypeName ? row.projectType?.projectTypeName : "--"}</td>

            </tr>
        {/each}
        </tbody>
    </Table>
{:else if $isLoadingSearch}
    <Spinner color="primary" />
{/if}
</Container>

<style>
    .clickable {
        cursor: pointer;
    }
</style>
