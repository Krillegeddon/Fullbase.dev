
import { writable } from "svelte/store";
import type {
    ProjectDto,
    ProjectLookupFilterResponse,
    ProjectLookupSearchRequest,
    ProjectLookupSearchResponse,
    ProjectLookupDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<ProjectLookupFilterResponse>(null);
export let searchResponse = writable<ProjectLookupSearchResponse>(null);
export let detailsResponse = writable<ProjectLookupDetailsResponse>(null);
export let searchRequest = writable<ProjectLookupSearchRequest>(null);
export let selectedRow = writable<ProjectDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
