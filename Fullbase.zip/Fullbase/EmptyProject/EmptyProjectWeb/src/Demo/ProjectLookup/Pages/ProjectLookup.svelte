
<script lang="ts">
    import { createEventDispatcher } from "svelte";
    import { filterResponse, searchResponse, detailsResponse } from "../ProjectLookupStores";
    import ProjectLookupFilter from "../Panels/ProjectLookupFilter.svelte";
    import ProjectLookupSearch from "../Panels/ProjectLookupSearch.svelte";
    import ProjectLookupQuickSearch from "../Panels/ProjectLookupQuickSearch.svelte";
    import ProjectLookupDetails from "../Panels/ProjectLookupDetails.svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;

    // Relay back to caller...
    function onOk(c) {
        dispatch("ok", c.detail);
    }

    // Reset stores when surfing to page.
    $filterResponse = null;
    $searchResponse = null;
    $detailsResponse = null;
</script>

<ProjectLookupFilter />
<hr />
<ProjectLookupSearch {isModal} on:ok={onOk}/>
<hr />
<ProjectLookupDetails />
