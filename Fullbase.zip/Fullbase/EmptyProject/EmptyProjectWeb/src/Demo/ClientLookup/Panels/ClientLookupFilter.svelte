
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        DateTimeClause,
        Normalizer,
        NormKey,
ClientDto,PersonDto,GenderDto,DepartmentDto,ClientLookupFilterRequest,ClientLookupFilterResponse,ClientLookupSearchRequest,ClientLookupSearchResponse
    } from "../../../WebApi";
    import {createEventDispatcher} from "svelte";
    import { filterResponse,searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingSearch } from "../ClientLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import { Icon } from "sveltestrap";
    const dispatch = createEventDispatcher();

    //export let isModal: boolean;
    let addCounter = -1;

import PersonLookup from "./../../PersonLookup/Pages/PersonLookup.svelte";
import PersonLookupQuickSearch from "./../../PersonLookup/Panels/PersonLookupQuickSearch.svelte";


import GenderLookup from "./../../GenderLookup/Pages/GenderLookup.svelte";
import GenderLookupQuickSearch from "./../../GenderLookup/Panels/GenderLookupQuickSearch.svelte";





    onMount(async () => {
        $filterResponse = new ClientLookupFilterResponse();
        $searchRequest = new ClientLookupSearchRequest();
        $searchRequest.clientId = new NumberClause();
        $searchRequest.clientName = new StringClause();
        $searchRequest.keyAccountManager_personId = new NumberClause();
        $searchRequest.keyAccountManager_userName = new StringClause();
        $searchRequest.keyAccountManager_salary = new NumberClause();
        $searchRequest.keyAccountManager_gender_genderId = new NumberClause();
        $searchRequest.keyAccountManager_gender_genderDescription = new StringClause();
        $searchRequest.keyAccountManager_department_departmentId = new NumberClause();
        $searchRequest.keyAccountManager_department_departmentName = new StringClause();

    });



    const onSearch = async () => {
        $isLoadingSearch = true;
        $searchResponse = null;
        $selectedRow = null;
        $detailsResponse = null;
        $searchResponse = await fetchers.GetClientLookupSearch($searchRequest);
        $isLoadingSearch = false;
    };




    /******* MODAL FOR SEARCHING keyAccountManager_personId for ClientLookupSearchRequest - START ************/
    let modalControllerFindClientLookupSearchRequest__keyAccountManager_personId_IsOpen: boolean;

    let modalClientLookupSearchRequest__keyAccountManager_personId: ClientLookupSearchRequest;
    const openFindClientLookupSearchRequest__keyAccountManager_personId = (x: ClientLookupSearchRequest) => {
        modalClientLookupSearchRequest__keyAccountManager_personId = x;
        modalControllerFindClientLookupSearchRequest__keyAccountManager_personId_IsOpen = true;
    };

    let keyAccountManager_personId: PersonDto = null;
    function onClientLookupSearchRequest__keyAccountManager_personIdFound(c) {
        keyAccountManager_personId = c.detail;
        modalControllerFindClientLookupSearchRequest__keyAccountManager_personId_IsOpen = false;
        modalClientLookupSearchRequest__keyAccountManager_personId.keyAccountManager_personId.exactMatch = keyAccountManager_personId.personId;
        $searchRequest = $searchRequest;
    }
    /******* MODAL FOR SEARCHING keyAccountManager_personId for ClientLookupSearchRequest - DONE ************/


    /******* MODAL FOR SEARCHING keyAccountManager_gender_genderId for ClientLookupSearchRequest - START ************/
    let modalControllerFindClientLookupSearchRequest__keyAccountManager_gender_genderId_IsOpen: boolean;

    let modalClientLookupSearchRequest__keyAccountManager_gender_genderId: ClientLookupSearchRequest;
    const openFindClientLookupSearchRequest__keyAccountManager_gender_genderId = (x: ClientLookupSearchRequest) => {
        modalClientLookupSearchRequest__keyAccountManager_gender_genderId = x;
        modalControllerFindClientLookupSearchRequest__keyAccountManager_gender_genderId_IsOpen = true;
    };

    let keyAccountManager_gender_genderId: GenderDto = null;
    function onClientLookupSearchRequest__keyAccountManager_gender_genderIdFound(c) {
        keyAccountManager_gender_genderId = c.detail;
        modalControllerFindClientLookupSearchRequest__keyAccountManager_gender_genderId_IsOpen = false;
        modalClientLookupSearchRequest__keyAccountManager_gender_genderId.keyAccountManager_gender_genderId.exactMatch = keyAccountManager_gender_genderId.genderId;
        $searchRequest = $searchRequest;
    }
    /******* MODAL FOR SEARCHING keyAccountManager_gender_genderId for ClientLookupSearchRequest - DONE ************/


</script>



    <Container>
{#if $filterResponse}
        <form on:submit|preventDefault={onSearch}>
            <Row>

<div class="col-10">
    <FormGroup>
        <Label>Client.QuickSearch</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.quickSearch} />
    </FormGroup>
</div>

            </Row>
            <Row>

<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Clients.Client.ClientId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.clientId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Key Account Manager <span style="cursor:pointer;" on:click={() => openFindClientLookupSearchRequest__keyAccountManager_personId($searchRequest)}
                    ><Icon name="search" /></span></Label>
        <PersonLookupQuickSearch selectedObject={keyAccountManager_personId} bind:selectedId={$searchRequest.keyAccountManager_personId.exactMatch} isReadOnly={false} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Client Name</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.clientName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Client.KeyAccountManager.PersonId (RAW)</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.keyAccountManager_personId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>KAM Gender <span style="cursor:pointer;" on:click={() => openFindClientLookupSearchRequest__keyAccountManager_gender_genderId($searchRequest)}
                    ><Icon name="search" /></span></Label>
        <GenderLookupQuickSearch selectedObject={keyAccountManager_gender_genderId} bind:selectedId={$searchRequest.keyAccountManager_gender_genderId.exactMatch} isReadOnly={false} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>KAM User name</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.keyAccountManager_userName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.keyAccountManager_gender_genderId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.keyAccountManager_gender_genderDescription.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.keyAccountManager_department_departmentId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.keyAccountManager_department_departmentName.exactMatch} />
    </FormGroup>
</div>

            </Row>

<Row>
    <div class="col-2">
        <Button color="primary"><Icon name="search"/> Search</Button>
    </div>
</Row>

        </form>
{:else}
    <Spinner color="primary" />
{/if}
    </Container>

<Modal isOpen={modalControllerFindClientLookupSearchRequest__keyAccountManager_personId_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find keyAccountManager_personId</ModalHeader>
    <ModalBody>
        <PersonLookup on:ok={onClientLookupSearchRequest__keyAccountManager_personIdFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindClientLookupSearchRequest__keyAccountManager_personId_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindClientLookupSearchRequest__keyAccountManager_gender_genderId_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find keyAccountManager_gender_genderId</ModalHeader>
    <ModalBody>
        <GenderLookup on:ok={onClientLookupSearchRequest__keyAccountManager_gender_genderIdFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindClientLookupSearchRequest__keyAccountManager_gender_genderId_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>

<style>
</style>
