
<script lang="ts">
    import { onMount } from "svelte";
    import { Table } from "sveltestrap";
    import { fetchers, ClientLookupSearchRequest, ClientLookupSearchResponse, ClientDto } from "../../../WebApi";

    let value = "";
    export let selectedObject: ClientDto = null;
    export let selectedId: number;
    export let isReadOnly: boolean;

    onMount(async () => {
        if (selectedObject == null) {
            value = "";
            return;
        }
        value = selectedObject.clientName + " " + selectedObject.keyAccountManager?.userName + " " + selectedObject.keyAccountManager?.gender?.genderDescription + " " + selectedObject.keyAccountManager?.department?.departmentName;
    });

    var searchResult: ClientLookupSearchResponse = null;

    async function onKeydown() {
        if (value.length < 2) {
            searchResult = null;
            myPopup.style.display = "none";
            return;
        }
        myPopup.style.display = "";
        var req = new ClientLookupSearchRequest();
        req.quickSearch = value;
        searchResult = await fetchers.GetClientLookupSearch(req);
    }

    let myInput: any;
    let myPopup: any;
    let isShown = false;
    function onFocus() {
        isShown = true;
        var rect = myInput.getBoundingClientRect();

        if (value.length >= 2) myPopup.style.display = "";

        var x = myInput.offsetLeft;
        var y = myInput.offsetTop * 1 + rect.height * 1;
        var width = rect.width;
        myPopup.style.left = x + "px";
        myPopup.style.top = y + "px";
        myPopup.style.minWidth = width + "px";
        myPopup.style.minHeight = "200" + "px";
    }

    function hide() {
        if (value == "") {
            selectedId = null;
            selectedObject = null;
        }
        myPopup.style.display = "none";
    }

    function onBlur() {
        isShown = false;
        setTimeout(hide, 300);
    }

    $: selectedObject && redraw();
    function redraw() {
        value = selectedObject.clientName + " " + selectedObject.keyAccountManager?.userName + " " + selectedObject.keyAccountManager?.gender?.genderDescription + " " + selectedObject.keyAccountManager?.department?.departmentName;
    }

    function onSelect(o: ClientDto) {
        selectedObject = o;
        selectedId = o.clientId;
        value = selectedObject.clientName + " " + selectedObject.keyAccountManager?.userName + " " + selectedObject.keyAccountManager?.gender?.genderDescription + " " + selectedObject.keyAccountManager?.department?.departmentName;
    }
</script>

{#if isReadOnly == false}
    <input
        type="text"
        bind:value
        on:keyup={onKeydown}
        on:focus={onFocus}
        on:blur={onBlur}
        autocomplete="new-password"
        bind:this={myInput}
        class="form-control"
    />
{:else}
<span class="form-control">{value}</span>
{/if}

<div
    bind:this={myPopup}
    class="popover fade bs-popover-bottom show"
    role="tooltip"
    x-placement="bottom"
    data-popper-placement="bottom"
    style="position: absolute; inset: 0px auto auto 0px; margin: 0px; display:none;"
>
    <div>
        {#if searchResult}
            <Table hover>
                <tbody>
                    {#each searchResult.clients as row}
                        <tr on:click={() => onSelect(row)} style="cursor:pointer">
                            <td>{row.clientName} {row.keyAccountManager?.userName} {row.keyAccountManager?.gender?.genderDescription} {row.keyAccountManager?.department?.departmentName}</td>
                        </tr>
                    {/each}
                </tbody>
            </Table>
        {/if}
    </div>
</div>
