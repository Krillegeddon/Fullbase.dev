
import { writable } from "svelte/store";
import type {
    ClientDto,
    ClientLookupFilterResponse,
    ClientLookupSearchRequest,
    ClientLookupSearchResponse,
    ClientLookupDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<ClientLookupFilterResponse>(null);
export let searchResponse = writable<ClientLookupSearchResponse>(null);
export let detailsResponse = writable<ClientLookupDetailsResponse>(null);
export let searchRequest = writable<ClientLookupSearchRequest>(null);
export let selectedRow = writable<ClientDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
