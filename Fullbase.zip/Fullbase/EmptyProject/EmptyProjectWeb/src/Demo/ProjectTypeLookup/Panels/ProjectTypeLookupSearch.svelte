
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        Normalizer,
        NormKey,
ProjectTypeDto,ProjectTypeLookupFilterRequest,ProjectTypeLookupFilterResponse,ProjectTypeLookupSearchRequest,ProjectTypeLookupSearchResponse,ProjectTypeLookupDetailsRequest,ProjectTypeLookupDetailsResponse
    } from "../../../WebApi";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails, isLoadingSearch } from "../ProjectTypeLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;
    let addCounter = -3;

    


    const onDetails = async (x: ProjectTypeDto) => {
        var detailsRequest = new ProjectTypeLookupDetailsRequest();
        detailsRequest.projectType = x;
        $selectedRow = x;
        $detailsResponse = null;

        if (isModal) {
            dispatch("ok", x);
            return;
        }

        if ($selectedRow != null) {
            $isLoadingDetails = true;
            $detailsResponse = await fetchers.GetProjectTypeLookupDetails(detailsRequest);
            $isLoadingDetails = false;
        }
    };


    const addProjectType = async () => {
        $detailsResponse = null;
        var dr = new ProjectTypeLookupDetailsResponse();
        dr.request = new ProjectTypeLookupDetailsRequest();
        dr.request.projectType = new ProjectTypeDto();
        dr.request.projectType.projectTypeId = -1;
        dr.projectType = new ProjectTypeDto();
        dr.projectType.projectTypeId = -1;

        var detailsRequest = new ProjectTypeLookupDetailsRequest();
        detailsRequest.projectType = new ProjectTypeDto();
        detailsRequest.projectType.projectTypeId = -1;
        $selectedRow = null;
        $detailsResponse = null;
        $isLoadingDetails = true;
        $detailsResponse = await fetchers.GetProjectTypeLookupDetails(detailsRequest);
        $isLoadingDetails = false;
    };


</script>


<Container fluid>

    <button class="btn btn-outline-primary btn-sm" on:click={addProjectType}><Icon name="plus-square" /> Add ProjectType</button>
{#if $searchResponse}
    <Table>
        <thead>
            <tr>
<th>Project Type</th>

            </tr>
        </thead>
        <tbody>
        {#each $searchResponse.projectTypes as row (row.projectTypeId)}
            <tr
                on:click={() => onDetails(row)}
                class="clickable"
                class:btn-primary={$selectedRow != null && row.projectTypeId === $selectedRow.projectTypeId}
            >
<td>{row.projectTypeName ? row.projectTypeName : ""}</td>

            </tr>
        {/each}
        </tbody>
    </Table>
{:else if $isLoadingSearch}
    <Spinner color="primary" />
{/if}
</Container>

<style>
    .clickable {
        cursor: pointer;
    }
</style>
