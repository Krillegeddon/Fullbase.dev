
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        DateTimeClause,
        Normalizer,
        NormKey,
ProjectTypeDto,ProjectTypeLookupFilterRequest,ProjectTypeLookupFilterResponse,ProjectTypeLookupSearchRequest,ProjectTypeLookupSearchResponse
    } from "../../../WebApi";
    import {createEventDispatcher} from "svelte";
    import { filterResponse,searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingSearch } from "../ProjectTypeLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import { Icon } from "sveltestrap";
    const dispatch = createEventDispatcher();

    //export let isModal: boolean;
    let addCounter = -1;





    onMount(async () => {
        $filterResponse = new ProjectTypeLookupFilterResponse();
        $searchRequest = new ProjectTypeLookupSearchRequest();
        $searchRequest.projectTypeId = new NumberClause();
        $searchRequest.projectTypeName = new StringClause();

    });



    const onSearch = async () => {
        $isLoadingSearch = true;
        $searchResponse = null;
        $selectedRow = null;
        $detailsResponse = null;
        $searchResponse = await fetchers.GetProjectTypeLookupSearch($searchRequest);
        $isLoadingSearch = false;
    };




</script>



    <Container>
{#if $filterResponse}
        <form on:submit|preventDefault={onSearch}>
            <Row>

            </Row>
            <Row>

<div class="col-5">
    <FormGroup>
        <Label>Project Type</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.projectTypeName.exactMatch} />
    </FormGroup>
</div>

            </Row>

<Row>
    <div class="col-2">
        <Button color="primary"><Icon name="search"/> Search</Button>
    </div>
</Row>

        </form>
{:else}
    <Spinner color="primary" />
{/if}
    </Container>

<style>
</style>
