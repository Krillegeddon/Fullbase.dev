
import { writable } from "svelte/store";
import type {
    ProjectTypeDto,
    ProjectTypeLookupFilterResponse,
    ProjectTypeLookupSearchRequest,
    ProjectTypeLookupSearchResponse,
    ProjectTypeLookupDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<ProjectTypeLookupFilterResponse>(null);
export let searchResponse = writable<ProjectTypeLookupSearchResponse>(null);
export let detailsResponse = writable<ProjectTypeLookupDetailsResponse>(null);
export let searchRequest = writable<ProjectTypeLookupSearchRequest>(null);
export let selectedRow = writable<ProjectTypeDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
