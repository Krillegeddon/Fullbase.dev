
<script lang="ts">
    import { createEventDispatcher } from "svelte";
    import { filterResponse, searchResponse, detailsResponse } from "../ProjectTypeLookupStores";
    import ProjectTypeLookupFilter from "../Panels/ProjectTypeLookupFilter.svelte";
    import ProjectTypeLookupSearch from "../Panels/ProjectTypeLookupSearch.svelte";
    import ProjectTypeLookupQuickSearch from "../Panels/ProjectTypeLookupQuickSearch.svelte";
    import ProjectTypeLookupDetails from "../Panels/ProjectTypeLookupDetails.svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;

    // Relay back to caller...
    function onOk(c) {
        dispatch("ok", c.detail);
    }

    // Reset stores when surfing to page.
    $filterResponse = null;
    $searchResponse = null;
    $detailsResponse = null;
</script>

<ProjectTypeLookupFilter />
<hr />
<ProjectTypeLookupSearch {isModal} on:ok={onOk}/>
<hr />
<ProjectTypeLookupDetails />
