
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        Normalizer,
        NormKey,
        userAuthentication,
Project_Person_RoleDto,ProjectDto,ProjectTypeDto,PersonDto,DepartmentDto,GenderDto,RoleDto,Project_Person_RoleExtendedFilterRequest,Project_Person_RoleExtendedFilterResponse,Project_Person_RoleExtendedSearchRequest,Project_Person_RoleExtendedSearchResponse,Project_Person_RoleExtendedDetailsRequest,Project_Person_RoleExtendedDetailsResponse
    } from "../../../WebApi";
    import FBSelect from "../../../Components/FBSelect.svelte";
    import FBControl from "../../../Components/FBControl.svelte";
    import FBCard from "../../../Components/FBCard.svelte";
    import FBRootCard from "../../../Components/FBRootCard.svelte";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails } from "../Project_Person_RoleExtendedStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Card, CardHeader, CardTitle, CardBody, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean = false;
    let addCounter = -5;

import ProjectLookup from "./../../ProjectLookup/Pages/ProjectLookup.svelte";
import ProjectLookupQuickSearch from "./../../ProjectLookup/Panels/ProjectLookupQuickSearch.svelte";


import PersonLookup from "./../../PersonLookup/Pages/PersonLookup.svelte";
import PersonLookupQuickSearch from "./../../PersonLookup/Panels/PersonLookupQuickSearch.svelte";





    let isSaving: boolean = false;
    const onSave = async () => {
        isSaving = true;
        var copy = { ...$detailsResponse };

        //$detailsResponse = null;
        $detailsResponse = await fetchers.SaveProject_Person_RoleExtendedDetails(copy);
        isSaving = false;
    };




    /******* MODAL FOR FINDING project for Project_Person_Role - START ************/
    let modalControllerFindProject_Person_Role__project_IsOpen: boolean;

    let modalProject_Person_Role__project: Project_Person_RoleDto;
    const openFindProject_Person_Role__project = (x: Project_Person_RoleDto) => {
        modalProject_Person_Role__project = x;
        modalControllerFindProject_Person_Role__project_IsOpen = true;
    };

    function onProject_Person_Role__projectFound(c) {
        var project: ProjectDto = c.detail;
        modalControllerFindProject_Person_Role__project_IsOpen = false;
        modalProject_Person_Role__project.project = project;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING project for Project_Person_Role - DONE ************/


    /******* MODAL FOR FINDING person for Project_Person_Role - START ************/
    let modalControllerFindProject_Person_Role__person_IsOpen: boolean;

    let modalProject_Person_Role__person: Project_Person_RoleDto;
    const openFindProject_Person_Role__person = (x: Project_Person_RoleDto) => {
        modalProject_Person_Role__person = x;
        modalControllerFindProject_Person_Role__person_IsOpen = true;
    };

    function onProject_Person_Role__personFound(c) {
        var person: PersonDto = c.detail;
        modalControllerFindProject_Person_Role__person_IsOpen = false;
        modalProject_Person_Role__person.person = person;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING person for Project_Person_Role - DONE ************/


</script>



<Container>
    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
        {#if $detailsResponse}
            <FBRootCard>
                <svelte:fragment slot="title">
                    Project_Person_Role
                </svelte:fragment>
                <svelte:fragment slot="savebutton">
                    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
                        {#if !isModal}
                            <button class="btn btn-primary" on:click={onSave}><Icon name="save" /> Save</button>
                        {/if}
                        {#if isSaving}
                            <Spinner color="primary" />
                        {/if}
                    {/if}
                </svelte:fragment>
                <svelte:fragment slot="body">
        
<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project_Person_Role.Project_Person_RoleId</Label>
        {#if $detailsResponse?.project_Person_Role}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.project_Person_Role.project_Person_RoleId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project_Person_Role.ProjectId <span style="cursor:pointer;" on:click={() => openFindProject_Person_Role__project($detailsResponse.project_Person_Role)}
                    ><Icon name="search" /></span></Label>
        {#if $detailsResponse?.project_Person_Role}
            
{#if true}
    <ProjectLookupQuickSearch bind:selectedObject={$detailsResponse.project_Person_Role.project} selectedId={0} isReadOnly={false}/>
{:else if true}
    <ProjectLookupQuickSearch bind:selectedObject={$detailsResponse.project_Person_Role.project} selectedId={0} isReadOnly={true}/>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project_Person_Role.PersonId <span style="cursor:pointer;" on:click={() => openFindProject_Person_Role__person($detailsResponse.project_Person_Role)}
                    ><Icon name="search" /></span></Label>
        {#if $detailsResponse?.project_Person_Role}
            
{#if true}
    <PersonLookupQuickSearch bind:selectedObject={$detailsResponse.project_Person_Role.person} selectedId={0} isReadOnly={false}/>
{:else if true}
    <PersonLookupQuickSearch bind:selectedObject={$detailsResponse.project_Person_Role.person} selectedId={0} isReadOnly={true}/>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project_Person_Role.RoleId</Label>
        {#if $detailsResponse?.project_Person_Role}
            
{#if true}
    
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.project_Person_Role.role}
        objects={$detailsResponse.roles}
        let:object
    >
        <option>{object.roleName}</option>
    </FBSelect>

{:else if true}
    <span class="form-control">{$detailsResponse.project_Person_Role.role}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->
<!-- none Project_Person_Role.Project --><!-- none Project_Person_Role.Person --><!-- none Project_Person_Role.Role -->
                </svelte:fragment>
                </FBRootCard>
        {:else if $isLoadingDetails}
            <Spinner color="primary" />
        {/if}
    {:else}
        **hidden**
    {/if}
</Container>

<Modal isOpen={modalControllerFindProject_Person_Role__project_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Project</ModalHeader>
    <ModalBody>
        <ProjectLookup on:ok={onProject_Person_Role__projectFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindProject_Person_Role__project_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindProject_Person_Role__person_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Person</ModalHeader>
    <ModalBody>
        <PersonLookup on:ok={onProject_Person_Role__personFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindProject_Person_Role__person_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>

<style>
</style>
