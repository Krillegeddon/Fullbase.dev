
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        Normalizer,
        NormKey,
Project_Person_RoleDto,ProjectDto,ProjectTypeDto,PersonDto,DepartmentDto,GenderDto,RoleDto,Project_Person_RoleExtendedFilterRequest,Project_Person_RoleExtendedFilterResponse,Project_Person_RoleExtendedSearchRequest,Project_Person_RoleExtendedSearchResponse,Project_Person_RoleExtendedDetailsRequest,Project_Person_RoleExtendedDetailsResponse
    } from "../../../WebApi";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails, isLoadingSearch } from "../Project_Person_RoleExtendedStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;
    let addCounter = -3;

    


    const onDetails = async (x: Project_Person_RoleDto) => {
        var detailsRequest = new Project_Person_RoleExtendedDetailsRequest();
        detailsRequest.project_Person_Role = x;
        $selectedRow = x;
        $detailsResponse = null;

        if (isModal) {
            dispatch("ok", x);
            return;
        }

        if ($selectedRow != null) {
            $isLoadingDetails = true;
            $detailsResponse = await fetchers.GetProject_Person_RoleExtendedDetails(detailsRequest);
            $isLoadingDetails = false;
        }
    };


    const addProject_Person_Role = async () => {
        $detailsResponse = null;
        var dr = new Project_Person_RoleExtendedDetailsResponse();
        dr.request = new Project_Person_RoleExtendedDetailsRequest();
        dr.request.project_Person_Role = new Project_Person_RoleDto();
        dr.request.project_Person_Role.project_Person_RoleId = -1;
        dr.project_Person_Role = new Project_Person_RoleDto();
        dr.project_Person_Role.project_Person_RoleId = -1;

        var detailsRequest = new Project_Person_RoleExtendedDetailsRequest();
        detailsRequest.project_Person_Role = new Project_Person_RoleDto();
        detailsRequest.project_Person_Role.project_Person_RoleId = -1;
        $selectedRow = null;
        $detailsResponse = null;
        $isLoadingDetails = true;
        $detailsResponse = await fetchers.GetProject_Person_RoleExtendedDetails(detailsRequest);
        $isLoadingDetails = false;
    };


</script>


<Container fluid>

    <button class="btn btn-outline-primary btn-sm" on:click={addProject_Person_Role}><Icon name="plus-square" /> Add Project_Person_Role</button>
{#if $searchResponse}
    <Table>
        <thead>
            <tr>
<th>Project_Person_Role.Project_Person_RoleId</th>

            </tr>
        </thead>
        <tbody>
        {#each $searchResponse.project_Person_Roles as row (row.project_Person_RoleId)}
            <tr
                on:click={() => onDetails(row)}
                class="clickable"
                class:btn-primary={$selectedRow != null && row.project_Person_RoleId === $selectedRow.project_Person_RoleId}
            >
<td>{row.project_Person_RoleId ? row.project_Person_RoleId : ""}</td>

            </tr>
        {/each}
        </tbody>
    </Table>
{:else if $isLoadingSearch}
    <Spinner color="primary" />
{/if}
</Container>

<style>
    .clickable {
        cursor: pointer;
    }
</style>
