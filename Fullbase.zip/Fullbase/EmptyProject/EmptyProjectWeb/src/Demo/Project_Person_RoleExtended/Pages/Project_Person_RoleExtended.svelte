
<script lang="ts">
    import { createEventDispatcher } from "svelte";
    import { filterResponse, searchResponse, detailsResponse } from "../Project_Person_RoleExtendedStores";
    import Project_Person_RoleExtendedFilter from "../Panels/Project_Person_RoleExtendedFilter.svelte";
    import Project_Person_RoleExtendedSearch from "../Panels/Project_Person_RoleExtendedSearch.svelte";
    import Project_Person_RoleExtendedQuickSearch from "../Panels/Project_Person_RoleExtendedQuickSearch.svelte";
    import Project_Person_RoleExtendedDetails from "../Panels/Project_Person_RoleExtendedDetails.svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;

    // Relay back to caller...
    function onOk(c) {
        dispatch("ok", c.detail);
    }

    // Reset stores when surfing to page.
    $filterResponse = null;
    $searchResponse = null;
    $detailsResponse = null;
</script>

<Project_Person_RoleExtendedFilter />
<hr />
<Project_Person_RoleExtendedSearch {isModal} on:ok={onOk}/>
<hr />
<Project_Person_RoleExtendedDetails />
