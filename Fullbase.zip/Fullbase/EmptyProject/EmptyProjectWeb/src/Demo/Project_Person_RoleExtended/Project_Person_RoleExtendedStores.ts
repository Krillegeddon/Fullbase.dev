
import { writable } from "svelte/store";
import type {
    Project_Person_RoleDto,
    Project_Person_RoleExtendedFilterResponse,
    Project_Person_RoleExtendedSearchRequest,
    Project_Person_RoleExtendedSearchResponse,
    Project_Person_RoleExtendedDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<Project_Person_RoleExtendedFilterResponse>(null);
export let searchResponse = writable<Project_Person_RoleExtendedSearchResponse>(null);
export let detailsResponse = writable<Project_Person_RoleExtendedDetailsResponse>(null);
export let searchRequest = writable<Project_Person_RoleExtendedSearchRequest>(null);
export let selectedRow = writable<Project_Person_RoleDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
