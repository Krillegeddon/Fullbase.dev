
<script lang="ts">
    import { createEventDispatcher } from "svelte";
    import { filterResponse, searchResponse, detailsResponse } from "../PersonLookupForManagerStores";
    import PersonLookupForManagerFilter from "../Panels/PersonLookupForManagerFilter.svelte";
    import PersonLookupForManagerSearch from "../Panels/PersonLookupForManagerSearch.svelte";
    import PersonLookupForManagerQuickSearch from "../Panels/PersonLookupForManagerQuickSearch.svelte";
    import PersonLookupForManagerDetails from "../Panels/PersonLookupForManagerDetails.svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;

    // Relay back to caller...
    function onOk(c) {
        dispatch("ok", c.detail);
    }

    // Reset stores when surfing to page.
    $filterResponse = null;
    $searchResponse = null;
    $detailsResponse = null;
</script>

<PersonLookupForManagerFilter />
<hr />
<PersonLookupForManagerSearch {isModal} on:ok={onOk}/>
<hr />
<PersonLookupForManagerDetails />
