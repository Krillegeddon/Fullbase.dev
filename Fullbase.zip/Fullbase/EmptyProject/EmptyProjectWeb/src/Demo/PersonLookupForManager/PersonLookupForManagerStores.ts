
import { writable } from "svelte/store";
import type {
    PersonDto,
    PersonLookupForManagerFilterResponse,
    PersonLookupForManagerSearchRequest,
    PersonLookupForManagerSearchResponse,
    PersonLookupForManagerDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<PersonLookupForManagerFilterResponse>(null);
export let searchResponse = writable<PersonLookupForManagerSearchResponse>(null);
export let detailsResponse = writable<PersonLookupForManagerDetailsResponse>(null);
export let searchRequest = writable<PersonLookupForManagerSearchRequest>(null);
export let selectedRow = writable<PersonDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
