
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        Normalizer,
        NormKey,
PersonDto,PersonLookupForManagerFilterRequest,PersonLookupForManagerFilterResponse,PersonLookupForManagerSearchRequest,PersonLookupForManagerSearchResponse,PersonLookupForManagerDetailsRequest,PersonLookupForManagerDetailsResponse
    } from "../../../WebApi";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails, isLoadingSearch } from "../PersonLookupForManagerStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;
    let addCounter = -3;

    


    const onDetails = async (x: PersonDto) => {
        var detailsRequest = new PersonLookupForManagerDetailsRequest();
        detailsRequest.person = x;
        $selectedRow = x;
        $detailsResponse = null;

        if (isModal) {
            dispatch("ok", x);
            return;
        }

        if ($selectedRow != null) {
            $isLoadingDetails = true;
            $detailsResponse = await fetchers.GetPersonLookupForManagerDetails(detailsRequest);
            $isLoadingDetails = false;
        }
    };


    const addPerson = async () => {
        $detailsResponse = null;
        var dr = new PersonLookupForManagerDetailsResponse();
        dr.request = new PersonLookupForManagerDetailsRequest();
        dr.request.person = new PersonDto();
        dr.request.person.personId = -1;
        dr.person = new PersonDto();
        dr.person.personId = -1;

        var detailsRequest = new PersonLookupForManagerDetailsRequest();
        detailsRequest.person = new PersonDto();
        detailsRequest.person.personId = -1;
        $selectedRow = null;
        $detailsResponse = null;
        $isLoadingDetails = true;
        $detailsResponse = await fetchers.GetPersonLookupForManagerDetails(detailsRequest);
        $isLoadingDetails = false;
    };


</script>


<Container fluid>

    <button class="btn btn-outline-primary btn-sm" on:click={addPerson}><Icon name="plus-square" /> Add Person</button>
{#if $searchResponse}
    <Table>
        <thead>
            <tr>
<th>Manager User Name</th>

            </tr>
        </thead>
        <tbody>
        {#each $searchResponse.persons as row (row.personId)}
            <tr
                on:click={() => onDetails(row)}
                class="clickable"
                class:btn-primary={$selectedRow != null && row.personId === $selectedRow.personId}
            >
<td>{row.userName ? row.userName : "--"}</td>

            </tr>
        {/each}
        </tbody>
    </Table>
{:else if $isLoadingSearch}
    <Spinner color="primary" />
{/if}
</Container>

<style>
    .clickable {
        cursor: pointer;
    }
</style>
