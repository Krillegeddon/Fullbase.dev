
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        Normalizer,
        NormKey,
        userAuthentication,
PersonDto,PersonLookupForManagerFilterRequest,PersonLookupForManagerFilterResponse,PersonLookupForManagerSearchRequest,PersonLookupForManagerSearchResponse,PersonLookupForManagerDetailsRequest,PersonLookupForManagerDetailsResponse
    } from "../../../WebApi";
    import FBSelect from "../../../Components/FBSelect.svelte";
    import FBControl from "../../../Components/FBControl.svelte";
    import FBCard from "../../../Components/FBCard.svelte";
    import FBRootCard from "../../../Components/FBRootCard.svelte";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails } from "../PersonLookupForManagerStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Card, CardHeader, CardTitle, CardBody, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean = false;
    let addCounter = -5;





    let isSaving: boolean = false;
    const onSave = async () => {
        isSaving = true;
        var copy = { ...$detailsResponse };

        //$detailsResponse = null;
        $detailsResponse = await fetchers.SavePersonLookupForManagerDetails(copy);
        isSaving = false;
    };




</script>



<Container>
    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
        {#if $detailsResponse}
            <FBRootCard>
                <svelte:fragment slot="title">
                    Person
                </svelte:fragment>
                <svelte:fragment slot="savebutton">
                    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
                        {#if !isModal}
                            <button class="btn btn-primary" on:click={onSave}><Icon name="save" /> Save</button>
                        {/if}
                        {#if isSaving}
                            <Spinner color="primary" />
                        {/if}
                    {/if}
                </svelte:fragment>
                <svelte:fragment slot="body">
        
<Row> <!-- props container markup! -->

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Manager User Name</Label>
        {#if $detailsResponse?.person}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.userName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Manager User Name</Label>
        {#if $detailsResponse?.person}
            <span class="form-control">{$detailsResponse.person.userName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

                </svelte:fragment>
                </FBRootCard>
        {:else if $isLoadingDetails}
            <Spinner color="primary" />
        {/if}
    {:else}
        **hidden**
    {/if}
</Container>

<style>
</style>
