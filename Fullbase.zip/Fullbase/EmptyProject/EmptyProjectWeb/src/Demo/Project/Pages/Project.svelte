
<script lang="ts">
    import { createEventDispatcher } from "svelte";
    import { filterResponse, searchResponse, detailsResponse } from "../ProjectStores";
    import ProjectFilter from "../Panels/ProjectFilter.svelte";
    import ProjectSearch from "../Panels/ProjectSearch.svelte";
    import ProjectQuickSearch from "../Panels/ProjectQuickSearch.svelte";
    import ProjectDetails from "../Panels/ProjectDetails.svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;

    // Relay back to caller...
    function onOk(c) {
        dispatch("ok", c.detail);
    }

    // Reset stores when surfing to page.
    $filterResponse = null;
    $searchResponse = null;
    $detailsResponse = null;
</script>

<ProjectFilter />
<hr />
<ProjectSearch {isModal} on:ok={onOk}/>
<hr />
<ProjectDetails />
