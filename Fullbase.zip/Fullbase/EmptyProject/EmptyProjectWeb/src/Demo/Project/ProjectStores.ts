
import { writable } from "svelte/store";
import type {
    ProjectDto,
    ProjectFilterResponse,
    ProjectSearchRequest,
    ProjectSearchResponse,
    ProjectDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<ProjectFilterResponse>(null);
export let searchResponse = writable<ProjectSearchResponse>(null);
export let detailsResponse = writable<ProjectDetailsResponse>(null);
export let searchRequest = writable<ProjectSearchRequest>(null);
export let selectedRow = writable<ProjectDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
