
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        Normalizer,
        NormKey,
        userAuthentication,
ProjectDto,ProjectTypeDto,ViewProjectAugDto,Project_Person_RoleDto,PersonDto,DepartmentDto,RoleDto,Project_ClientDto,ClientDto,ProjectFilterRequest,ProjectFilterResponse,ProjectSearchRequest,ProjectSearchResponse,ProjectDetailsRequest,ProjectDetailsResponse
    } from "../../../WebApi";
    import FBSelect from "../../../Components/FBSelect.svelte";
    import FBControl from "../../../Components/FBControl.svelte";
    import FBCard from "../../../Components/FBCard.svelte";
    import FBRootCard from "../../../Components/FBRootCard.svelte";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails } from "../ProjectStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Card, CardHeader, CardTitle, CardBody, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean = false;
    let addCounter = -5;



    import { Project_Person_RoleExtendedDetailsResponse } from "../../../WebApi";
    import Project_Person_RoleExtendedDetails from "./../../Project_Person_RoleExtended/Panels/Project_Person_RoleExtendedDetails.svelte";
    import { detailsResponse as detailsResponseProject_Person_Role } from "./../../Project_Person_RoleExtended/Project_Person_RoleExtendedStores";
    let editProject_Person_Role_isOpen = false;
    let editProject_Person_Role_obj: Project_Person_RoleDto = null;
    let editProject_Person_Role_isInsert: boolean = false;
    let editProject_Person_Role_parentObject: ProjectDto = null;
    
    const editProject_Person_Role = (parentObject: ProjectDto, obj: Project_Person_RoleDto) => {
        editProject_Person_Role_parentObject = parentObject;
        var dd = new Project_Person_RoleExtendedDetailsResponse();
// Lists to pass:
dd.departments = $detailsResponse.departments;
dd.genders = $detailsResponse.genders;
dd.roles = $detailsResponse.roles;

        //dd.securityAccessLevels = $detailsResponse.securityAccessLevels;
        //dd.parameterAccessTypes = $detailsResponse.parameterAccessTypes;

        if (obj == null) {
            addCounter--;
            editProject_Person_Role_obj = new Project_Person_RoleDto();
            editProject_Person_Role_obj.project_Person_RoleId = addCounter;
            editProject_Person_Role_obj.projectId = parentObject.projectId;
            editProject_Person_Role_obj.project = parentObject;
            editProject_Person_Role_isInsert = true;
        } else {
            editProject_Person_Role_obj = obj;
            editProject_Person_Role_isInsert = false;
        }
        dd.project_Person_Role = editProject_Person_Role_obj;
        $detailsResponseProject_Person_Role = dd;
        editProject_Person_Role_isOpen = true;
    };

    const editProject_Person_Role_Done = () => {
        editProject_Person_Role_isOpen = false;
        console.log(editProject_Person_Role_obj);
        if (editProject_Person_Role_isInsert == true) {
            editProject_Person_Role_parentObject.project_Person_Roles = [
                ...editProject_Person_Role_parentObject.project_Person_Roles,
                editProject_Person_Role_obj,
            ];
        }
        $detailsResponse = $detailsResponse; // Force refresh... TBD - something smarter?
    };

    const deleteProject_Person_Role = (obj: Project_Person_RoleDto) => {
        console.log("deleteProject_Person_Role()!");
        obj.isDeleted = true;
        $detailsResponse = $detailsResponse; // Force refresh... TBD - something smarter?
    };


    import { Project_ClientExtendedDetailsResponse } from "../../../WebApi";
    import Project_ClientExtendedDetails from "./../../Project_ClientExtended/Panels/Project_ClientExtendedDetails.svelte";
    import { detailsResponse as detailsResponseProject_Client } from "./../../Project_ClientExtended/Project_ClientExtendedStores";
    let editProject_Client_isOpen = false;
    let editProject_Client_obj: Project_ClientDto = null;
    let editProject_Client_isInsert: boolean = false;
    let editProject_Client_parentObject: ProjectDto = null;
    
    const editProject_Client = (parentObject: ProjectDto, obj: Project_ClientDto) => {
        editProject_Client_parentObject = parentObject;
        var dd = new Project_ClientExtendedDetailsResponse();
// Lists to pass:

        //dd.securityAccessLevels = $detailsResponse.securityAccessLevels;
        //dd.parameterAccessTypes = $detailsResponse.parameterAccessTypes;

        if (obj == null) {
            addCounter--;
            editProject_Client_obj = new Project_ClientDto();
            editProject_Client_obj.project_ClientId = addCounter;
            editProject_Client_obj.projectId = parentObject.projectId;
            editProject_Client_obj.project = parentObject;
            editProject_Client_isInsert = true;
        } else {
            editProject_Client_obj = obj;
            editProject_Client_isInsert = false;
        }
        dd.project_Client = editProject_Client_obj;
        $detailsResponseProject_Client = dd;
        editProject_Client_isOpen = true;
    };

    const editProject_Client_Done = () => {
        editProject_Client_isOpen = false;
        console.log(editProject_Client_obj);
        if (editProject_Client_isInsert == true) {
            editProject_Client_parentObject.project_Clients = [
                ...editProject_Client_parentObject.project_Clients,
                editProject_Client_obj,
            ];
        }
        $detailsResponse = $detailsResponse; // Force refresh... TBD - something smarter?
    };

    const deleteProject_Client = (obj: Project_ClientDto) => {
        console.log("deleteProject_Client()!");
        obj.isDeleted = true;
        $detailsResponse = $detailsResponse; // Force refresh... TBD - something smarter?
    };



    let isSaving: boolean = false;
    const onSave = async () => {
        isSaving = true;
        var copy = { ...$detailsResponse };

        //$detailsResponse = null;
        $detailsResponse = await fetchers.SaveProjectDetails(copy);
        isSaving = false;
    };




</script>



<Container>
    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
        {#if $detailsResponse}
            <FBRootCard>
                <svelte:fragment slot="title">
                    Project
                </svelte:fragment>
                <svelte:fragment slot="savebutton">
                    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
                        {#if !isModal}
                            <button class="btn btn-primary" on:click={onSave}><Icon name="save" /> Save</button>
                        {/if}
                        {#if isSaving}
                            <Spinner color="primary" />
                        {/if}
                    {/if}
                </svelte:fragment>
                <svelte:fragment slot="body">
        
<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project Name</Label>
        {#if $detailsResponse?.project}
            
{#if userAuthentication.isAdmin}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.project.projectName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin}
    <span class="form-control">{$detailsResponse.project.projectName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Is Pro-Bono</Label>
        {#if $detailsResponse?.project}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <div class="form-control">
    <input autocomplete="new-password" class="form-check-input" type="checkbox" bind:checked={$detailsResponse.project.isProBono} />
</div>
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.project.isProBono}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Deadline</Label>
        {#if $detailsResponse?.project}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <DateTimeInput css="form-control" bind:value={$detailsResponse.project.deadline} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.project.deadline}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project Type</Label>
        {#if $detailsResponse?.project}
            
{#if true}
    
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.project.projectType}
        objects={$detailsResponse.projectTypes}
        let:object
    >
        <option>{object.projectTypeName}</option>
    </FBSelect>

{:else if true}
    <span class="form-control">{$detailsResponse.project.projectType}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>TempNum</Label>
        {#if $detailsResponse?.project?.viewProjectAug}
            <span class="form-control">{$detailsResponse.project.viewProjectAug.tempNum}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Quadruple</Label>
        {#if $detailsResponse?.project?.viewProjectAug}
            <span class="form-control">{$detailsResponse.project.viewProjectAug.quadruple}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->
<!-- none Project.ProjectType -->

Project_Person_Roles <button class="btn btn-outline-primary btn-sm mb-2" on:click={() => editProject_Person_Role($detailsResponse.project, null)}><Icon name="plus-square" /></button>
<Table>
    <thead>
        <tr>

<th>Salary</th>

<th>Department</th>

<th>Project.Project_Person_Roles.Project_Person_RoleId</th>

<th>Person.PersonId</th>

<th>User Name</th>

<th>Role</th>

            <th></th>
        </tr>
    </thead>
    <tbody>
        {#if $detailsResponse.project.project_Person_Roles }
            {#each $detailsResponse.project.project_Person_Roles as project_Person_Role (project_Person_Role.project_Person_RoleId)}
                {#if !project_Person_Role.isDeleted}
                    <tr on:click={() => editProject_Person_Role($detailsResponse.project, project_Person_Role)} style="cursor:pointer">
    <td>{project_Person_Role.person.salary}</td><td>{project_Person_Role.person.department.departmentName}</td><td>{project_Person_Role.project_Person_RoleId}</td><td>{project_Person_Role.person.personId}</td><td>{project_Person_Role.person.userName}</td><td>{project_Person_Role.role.roleName}</td>
                        <td>
                            <button on:click|stopPropagation={ () => deleteProject_Person_Role(project_Person_Role)} class="btn btn-outline-danger btn-sm"><Icon name="file-excel"/></button>
                        </td>
                    </tr>
                {/if}
            {/each}
        {/if}
    </tbody>
</Table>

Project_Clients <button class="btn btn-outline-primary btn-sm mb-2" on:click={() => editProject_Client($detailsResponse.project, null)}><Icon name="plus-square" /></button>
<Table>
    <thead>
        <tr>

<th>KAM</th>

<th>Client Name</th>

            <th></th>
        </tr>
    </thead>
    <tbody>
        {#if $detailsResponse.project.project_Clients }
            {#each $detailsResponse.project.project_Clients as project_Client (project_Client.project_ClientId)}
                {#if !project_Client.isDeleted}
                    <tr on:click={() => editProject_Client($detailsResponse.project, project_Client)} style="cursor:pointer">
    <td>{project_Client.client.keyAccountManager.userName}</td><td>{project_Client.client.clientName}</td>
                        <td>
                            <button on:click|stopPropagation={ () => deleteProject_Client(project_Client)} class="btn btn-outline-danger btn-sm"><Icon name="file-excel"/></button>
                        </td>
                    </tr>
                {/if}
            {/each}
        {/if}
    </tbody>
</Table>
                </svelte:fragment>
                </FBRootCard>
        {:else if $isLoadingDetails}
            <Spinner color="primary" />
        {/if}
    {:else}
        **hidden**
    {/if}
</Container>

<Modal isOpen={editProject_Person_Role_isOpen} backdrop={false} size="xl">
    <ModalHeader>Edit Project_Person_Role</ModalHeader>
    <ModalBody>
        <Project_Person_RoleExtendedDetails on:ok={editProject_Person_Role_Done} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="primary" on:click={() => editProject_Person_Role_Done()}>OK</Button>
        <Button color="secondary" on:click={() => (editProject_Person_Role_isOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={editProject_Client_isOpen} backdrop={false} size="xl">
    <ModalHeader>Edit Project_Client</ModalHeader>
    <ModalBody>
        <Project_ClientExtendedDetails on:ok={editProject_Client_Done} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="primary" on:click={() => editProject_Client_Done()}>OK</Button>
        <Button color="secondary" on:click={() => (editProject_Client_isOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>

<style>
</style>
