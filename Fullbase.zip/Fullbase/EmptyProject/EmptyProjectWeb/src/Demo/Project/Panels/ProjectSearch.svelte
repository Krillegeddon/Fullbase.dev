
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        Normalizer,
        NormKey,
ProjectDto,ProjectTypeDto,ViewProjectAugDto,Project_Person_RoleDto,PersonDto,DepartmentDto,RoleDto,Project_ClientDto,ClientDto,ProjectFilterRequest,ProjectFilterResponse,ProjectSearchRequest,ProjectSearchResponse,ProjectDetailsRequest,ProjectDetailsResponse
    } from "../../../WebApi";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails, isLoadingSearch } from "../ProjectStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;
    let addCounter = -3;


    import { Project_Person_RoleExtendedDetailsResponse } from "../../../WebApi";
    import Project_Person_RoleExtendedDetails from "./../../Project_Person_RoleExtended/Panels/Project_Person_RoleExtendedDetails.svelte";
    import { detailsResponse as detailsResponseProject_Person_Role } from "./../../Project_Person_RoleExtended/Project_Person_RoleExtendedStores";
    let editProject_Person_Role_isOpen = false;
    let editProject_Person_Role_obj: Project_Person_RoleDto = null;
    let editProject_Person_Role_isInsert: boolean = false;
    let editProject_Person_Role_parentObject: ProjectDto = null;
    
    const editProject_Person_Role = (parentObject: ProjectDto, obj: Project_Person_RoleDto) => {
        editProject_Person_Role_parentObject = parentObject;
        var dd = new Project_Person_RoleExtendedDetailsResponse();
// Lists to pass:
dd.departments = $detailsResponse.departments;
dd.genders = $detailsResponse.genders;
dd.roles = $detailsResponse.roles;

        //dd.securityAccessLevels = $detailsResponse.securityAccessLevels;
        //dd.parameterAccessTypes = $detailsResponse.parameterAccessTypes;

        if (obj == null) {
            addCounter--;
            editProject_Person_Role_obj = new Project_Person_RoleDto();
            editProject_Person_Role_obj.project_Person_RoleId = addCounter;
            editProject_Person_Role_obj.projectId = parentObject.projectId;
            editProject_Person_Role_obj.project = parentObject;
            editProject_Person_Role_isInsert = true;
        } else {
            editProject_Person_Role_obj = obj;
            editProject_Person_Role_isInsert = false;
        }
        dd.project_Person_Role = editProject_Person_Role_obj;
        $detailsResponseProject_Person_Role = dd;
        editProject_Person_Role_isOpen = true;
    };

    const editProject_Person_Role_Done = () => {
        editProject_Person_Role_isOpen = false;
        console.log(editProject_Person_Role_obj);
        if (editProject_Person_Role_isInsert == true) {
            editProject_Person_Role_parentObject.project_Person_Roles = [
                ...editProject_Person_Role_parentObject.project_Person_Roles,
                editProject_Person_Role_obj,
            ];
        }
        $detailsResponse = $detailsResponse; // Force refresh... TBD - something smarter?
    };

    const deleteProject_Person_Role = (obj: Project_Person_RoleDto) => {
        console.log("deleteProject_Person_Role()!");
        obj.isDeleted = true;
        $detailsResponse = $detailsResponse; // Force refresh... TBD - something smarter?
    };


    import { Project_ClientExtendedDetailsResponse } from "../../../WebApi";
    import Project_ClientExtendedDetails from "./../../Project_ClientExtended/Panels/Project_ClientExtendedDetails.svelte";
    import { detailsResponse as detailsResponseProject_Client } from "./../../Project_ClientExtended/Project_ClientExtendedStores";
    let editProject_Client_isOpen = false;
    let editProject_Client_obj: Project_ClientDto = null;
    let editProject_Client_isInsert: boolean = false;
    let editProject_Client_parentObject: ProjectDto = null;
    
    const editProject_Client = (parentObject: ProjectDto, obj: Project_ClientDto) => {
        editProject_Client_parentObject = parentObject;
        var dd = new Project_ClientExtendedDetailsResponse();
// Lists to pass:

        //dd.securityAccessLevels = $detailsResponse.securityAccessLevels;
        //dd.parameterAccessTypes = $detailsResponse.parameterAccessTypes;

        if (obj == null) {
            addCounter--;
            editProject_Client_obj = new Project_ClientDto();
            editProject_Client_obj.project_ClientId = addCounter;
            editProject_Client_obj.projectId = parentObject.projectId;
            editProject_Client_obj.project = parentObject;
            editProject_Client_isInsert = true;
        } else {
            editProject_Client_obj = obj;
            editProject_Client_isInsert = false;
        }
        dd.project_Client = editProject_Client_obj;
        $detailsResponseProject_Client = dd;
        editProject_Client_isOpen = true;
    };

    const editProject_Client_Done = () => {
        editProject_Client_isOpen = false;
        console.log(editProject_Client_obj);
        if (editProject_Client_isInsert == true) {
            editProject_Client_parentObject.project_Clients = [
                ...editProject_Client_parentObject.project_Clients,
                editProject_Client_obj,
            ];
        }
        $detailsResponse = $detailsResponse; // Force refresh... TBD - something smarter?
    };

    const deleteProject_Client = (obj: Project_ClientDto) => {
        console.log("deleteProject_Client()!");
        obj.isDeleted = true;
        $detailsResponse = $detailsResponse; // Force refresh... TBD - something smarter?
    };
    


    const onDetails = async (x: ProjectDto) => {
        var detailsRequest = new ProjectDetailsRequest();
        detailsRequest.project = x;
        $selectedRow = x;
        $detailsResponse = null;

        if (isModal) {
            dispatch("ok", x);
            return;
        }

        if ($selectedRow != null) {
            $isLoadingDetails = true;
            $detailsResponse = await fetchers.GetProjectDetails(detailsRequest);
            $isLoadingDetails = false;
        }
    };


    const addProject = async () => {
        $detailsResponse = null;
        var dr = new ProjectDetailsResponse();
        dr.request = new ProjectDetailsRequest();
        dr.request.project = new ProjectDto();
        dr.request.project.projectId = -1;
        dr.project = new ProjectDto();
        dr.project.projectId = -1;

        var detailsRequest = new ProjectDetailsRequest();
        detailsRequest.project = new ProjectDto();
        detailsRequest.project.projectId = -1;
        $selectedRow = null;
        $detailsResponse = null;
        $isLoadingDetails = true;
        $detailsResponse = await fetchers.GetProjectDetails(detailsRequest);
        $isLoadingDetails = false;
    };


</script>


<Container fluid>

    <button class="btn btn-outline-primary btn-sm" on:click={addProject}><Icon name="plus-square" /> Add Project</button>
{#if $searchResponse}
    <Table>
        <thead>
            <tr>
<th style="color:yellow;">Project Name</th><th>Is Pro-Bono</th>
<th>Deadline</th>
<th>TempNum</th>
<th>Quadruple</th>

            </tr>
        </thead>
        <tbody>
        {#each $searchResponse.projects as row (row.projectId)}
            <tr
                on:click={() => onDetails(row)}
                class="clickable"
                class:btn-primary={$selectedRow != null && row.projectId === $selectedRow.projectId}
            >
<td style="color:blue;">{row.projectName ? row.projectName : "--"}</td>
<td>{row.isProBono ? row.isProBono : "--"}</td>
<td>{row.deadline ? row.deadline : "--"}</td>
<td>{row.viewProjectAug?.tempNum ? row.viewProjectAug?.tempNum : "--"}</td>
<td>{row.viewProjectAug?.quadruple ? row.viewProjectAug?.quadruple : "--"}</td>

            </tr>
        {/each}
        </tbody>
    </Table>
{:else if $isLoadingSearch}
    <Spinner color="primary" />
{/if}
</Container>

<style>
    .clickable {
        cursor: pointer;
    }
</style>
