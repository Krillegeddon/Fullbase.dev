
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        DateTimeClause,
        Normalizer,
        NormKey,
ProjectDto,ProjectTypeDto,ViewProjectAugDto,Project_Person_RoleDto,PersonDto,DepartmentDto,RoleDto,Project_ClientDto,ClientDto,ProjectFilterRequest,ProjectFilterResponse,ProjectSearchRequest,ProjectSearchResponse
    } from "../../../WebApi";
    import {createEventDispatcher} from "svelte";
    import { filterResponse,searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingSearch } from "../ProjectStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import { Icon } from "sveltestrap";
    const dispatch = createEventDispatcher();

    //export let isModal: boolean;
    let addCounter = -1;



    import { Project_Person_RoleExtendedDetailsResponse } from "../../../WebApi";
    import Project_Person_RoleExtendedDetails from "./../../Project_Person_RoleExtended/Panels/Project_Person_RoleExtendedDetails.svelte";
    import { detailsResponse as detailsResponseProject_Person_Role } from "./../../Project_Person_RoleExtended/Project_Person_RoleExtendedStores";
    let editProject_Person_Role_isOpen = false;
    let editProject_Person_Role_obj: Project_Person_RoleDto = null;
    let editProject_Person_Role_isInsert: boolean = false;
    let editProject_Person_Role_parentObject: ProjectDto = null;
    
    const editProject_Person_Role = (parentObject: ProjectDto, obj: Project_Person_RoleDto) => {
        editProject_Person_Role_parentObject = parentObject;
        var dd = new Project_Person_RoleExtendedDetailsResponse();
// Lists to pass:
dd.departments = $detailsResponse.departments;
dd.genders = $detailsResponse.genders;
dd.roles = $detailsResponse.roles;

        //dd.securityAccessLevels = $detailsResponse.securityAccessLevels;
        //dd.parameterAccessTypes = $detailsResponse.parameterAccessTypes;

        if (obj == null) {
            addCounter--;
            editProject_Person_Role_obj = new Project_Person_RoleDto();
            editProject_Person_Role_obj.project_Person_RoleId = addCounter;
            editProject_Person_Role_obj.projectId = parentObject.projectId;
            editProject_Person_Role_obj.project = parentObject;
            editProject_Person_Role_isInsert = true;
        } else {
            editProject_Person_Role_obj = obj;
            editProject_Person_Role_isInsert = false;
        }
        dd.project_Person_Role = editProject_Person_Role_obj;
        $detailsResponseProject_Person_Role = dd;
        editProject_Person_Role_isOpen = true;
    };

    const editProject_Person_Role_Done = () => {
        editProject_Person_Role_isOpen = false;
        console.log(editProject_Person_Role_obj);
        if (editProject_Person_Role_isInsert == true) {
            editProject_Person_Role_parentObject.project_Person_Roles = [
                ...editProject_Person_Role_parentObject.project_Person_Roles,
                editProject_Person_Role_obj,
            ];
        }
        $detailsResponse = $detailsResponse; // Force refresh... TBD - something smarter?
    };

    const deleteProject_Person_Role = (obj: Project_Person_RoleDto) => {
        console.log("deleteProject_Person_Role()!");
        obj.isDeleted = true;
        $detailsResponse = $detailsResponse; // Force refresh... TBD - something smarter?
    };


    import { Project_ClientExtendedDetailsResponse } from "../../../WebApi";
    import Project_ClientExtendedDetails from "./../../Project_ClientExtended/Panels/Project_ClientExtendedDetails.svelte";
    import { detailsResponse as detailsResponseProject_Client } from "./../../Project_ClientExtended/Project_ClientExtendedStores";
    let editProject_Client_isOpen = false;
    let editProject_Client_obj: Project_ClientDto = null;
    let editProject_Client_isInsert: boolean = false;
    let editProject_Client_parentObject: ProjectDto = null;
    
    const editProject_Client = (parentObject: ProjectDto, obj: Project_ClientDto) => {
        editProject_Client_parentObject = parentObject;
        var dd = new Project_ClientExtendedDetailsResponse();
// Lists to pass:

        //dd.securityAccessLevels = $detailsResponse.securityAccessLevels;
        //dd.parameterAccessTypes = $detailsResponse.parameterAccessTypes;

        if (obj == null) {
            addCounter--;
            editProject_Client_obj = new Project_ClientDto();
            editProject_Client_obj.project_ClientId = addCounter;
            editProject_Client_obj.projectId = parentObject.projectId;
            editProject_Client_obj.project = parentObject;
            editProject_Client_isInsert = true;
        } else {
            editProject_Client_obj = obj;
            editProject_Client_isInsert = false;
        }
        dd.project_Client = editProject_Client_obj;
        $detailsResponseProject_Client = dd;
        editProject_Client_isOpen = true;
    };

    const editProject_Client_Done = () => {
        editProject_Client_isOpen = false;
        console.log(editProject_Client_obj);
        if (editProject_Client_isInsert == true) {
            editProject_Client_parentObject.project_Clients = [
                ...editProject_Client_parentObject.project_Clients,
                editProject_Client_obj,
            ];
        }
        $detailsResponse = $detailsResponse; // Force refresh... TBD - something smarter?
    };

    const deleteProject_Client = (obj: Project_ClientDto) => {
        console.log("deleteProject_Client()!");
        obj.isDeleted = true;
        $detailsResponse = $detailsResponse; // Force refresh... TBD - something smarter?
    };



    onMount(async () => {
        var req = new ProjectFilterRequest(); // Default Filter Request
        $filterResponse = await fetchers.GetProjectFilter(req);
        $searchRequest = new ProjectSearchRequest();
        $searchRequest.projectId = new NumberClause();
        $searchRequest.projectName = new StringClause();
        $searchRequest.isProBono = new BoolClause();
        $searchRequest.deadline = new DateTimeClause();
        $searchRequest.projectType_projectTypeId = new NumberClause();
        $searchRequest.projectType_projectTypeName = new StringClause();
        $searchRequest.viewProjectAug_projectId = new NumberClause();
        $searchRequest.viewProjectAug_tempNum = new NumberClause();
        $searchRequest.viewProjectAug_quadruple = new NumberClause();

    });



    const onSearch = async () => {
        $isLoadingSearch = true;
        $searchResponse = null;
        $selectedRow = null;
        $detailsResponse = null;
        $searchResponse = await fetchers.GetProjectSearch($searchRequest);
        $isLoadingSearch = false;
    };




</script>



    <Container>
{#if $filterResponse}
        <form on:submit|preventDefault={onSearch}>
            <Row>

<div class="col-10">
    <FormGroup>
        <Label>Quick Search</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.quickSearch} />
    </FormGroup>
</div>

            </Row>
            <Row>

<div class="col-5">
    <FormGroup>
        <Label>Quadruple</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.viewProjectAug_quadruple.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Deadline</Label>
        <table>
    <tr>
        <td>
            From:
        </td>
        <td>
            <DateTimeInput css="form-control" bind:value={$searchRequest.deadline.moreThan} />
        </td>
    </tr>
    <tr>
        <td>
            To:
        </td>
        <td>
            <DateTimeInput css="form-control" bind:value={$searchRequest.deadline.lessThan} />
        </td>
    </tr>
</table>
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project Type</Label>
        
        <select class="form-control" bind:value={$searchRequest.projectType_projectTypeId.exactMatch}>
            <option value={null}>- all -</option>
            {#each $filterResponse.projectTypes as projectType}
                <option value={projectType.projectTypeId}>{projectType.projectTypeName}</option>
            {/each}
        </select>

    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project Name</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.projectName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Is Pro-Bono</Label>
        
<select class="form-control" bind:value={$searchRequest.isProBono.exactMatch}>
    <option value={null}></option>
    <option value={true}>true</option>
    <option value={false}>false</option>
</select>
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>TempNum</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.viewProjectAug_tempNum.exactMatch} />
    </FormGroup>
</div>

            </Row>

<Row>
    <div class="col-2">
        <Button color="primary"><Icon name="search"/> Search</Button>
    </div>
</Row>

        </form>
{:else}
    <Spinner color="primary" />
{/if}
    </Container>

<style>
</style>
