
import { writable } from "svelte/store";
import type {
    ClientDto,
    ClientFilterResponse,
    ClientSearchRequest,
    ClientSearchResponse,
    ClientDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<ClientFilterResponse>(null);
export let searchResponse = writable<ClientSearchResponse>(null);
export let detailsResponse = writable<ClientDetailsResponse>(null);
export let searchRequest = writable<ClientSearchRequest>(null);
export let selectedRow = writable<ClientDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
