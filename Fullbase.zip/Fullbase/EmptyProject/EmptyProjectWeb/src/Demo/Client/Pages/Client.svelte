
<script lang="ts">
    import { createEventDispatcher } from "svelte";
    import { filterResponse, searchResponse, detailsResponse } from "../ClientStores";
    import ClientFilter from "../Panels/ClientFilter.svelte";
    import ClientSearch from "../Panels/ClientSearch.svelte";
    import ClientQuickSearch from "../Panels/ClientQuickSearch.svelte";
    import ClientDetails from "../Panels/ClientDetails.svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;

    // Relay back to caller...
    function onOk(c) {
        dispatch("ok", c.detail);
    }

    // Reset stores when surfing to page.
    $filterResponse = null;
    $searchResponse = null;
    $detailsResponse = null;
</script>

<ClientFilter />
<hr />
<ClientSearch {isModal} on:ok={onOk}/>
<hr />
<ClientDetails />
