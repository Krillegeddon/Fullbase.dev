
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        DateTimeClause,
        Normalizer,
        NormKey,
ClientDto,PersonDto,GenderDto,DepartmentDto,ClientFilterRequest,ClientFilterResponse,ClientSearchRequest,ClientSearchResponse
    } from "../../../WebApi";
    import {createEventDispatcher} from "svelte";
    import { filterResponse,searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingSearch } from "../ClientStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import { Icon } from "sveltestrap";
    const dispatch = createEventDispatcher();

    //export let isModal: boolean;
    let addCounter = -1;

import PersonLookup from "./../../PersonLookup/Pages/PersonLookup.svelte";
import PersonLookupQuickSearch from "./../../PersonLookup/Panels/PersonLookupQuickSearch.svelte";


import GenderLookup from "./../../GenderLookup/Pages/GenderLookup.svelte";
import GenderLookupQuickSearch from "./../../GenderLookup/Panels/GenderLookupQuickSearch.svelte";


import DepartmentLookup from "./../../DepartmentLookup/Pages/DepartmentLookup.svelte";
import DepartmentLookupQuickSearch from "./../../DepartmentLookup/Panels/DepartmentLookupQuickSearch.svelte";





    onMount(async () => {
        $filterResponse = new ClientFilterResponse();
        $searchRequest = new ClientSearchRequest();
        $searchRequest.clientId = new NumberClause();
        $searchRequest.clientName = new StringClause();
        $searchRequest.keyAccountManager_personId = new NumberClause();
        $searchRequest.keyAccountManager_userName = new StringClause();
        $searchRequest.keyAccountManager_salary = new NumberClause();
        $searchRequest.keyAccountManager_gender_genderId = new NumberClause();
        $searchRequest.keyAccountManager_gender_genderDescription = new StringClause();
        $searchRequest.keyAccountManager_department_departmentId = new NumberClause();
        $searchRequest.keyAccountManager_department_departmentName = new StringClause();
        $searchRequest.keyAccountManager_manager_personId = new NumberClause();
        $searchRequest.keyAccountManager_manager_userName = new StringClause();
        $searchRequest.keyAccountManager_manager_salary = new NumberClause();
        $searchRequest.keyAccountManager_manager_gender_genderId = new NumberClause();
        $searchRequest.keyAccountManager_manager_gender_genderDescription = new StringClause();
        $searchRequest.keyAccountManager_manager_department_departmentId = new NumberClause();
        $searchRequest.keyAccountManager_manager_department_departmentName = new StringClause();

    });



    const onSearch = async () => {
        $isLoadingSearch = true;
        $searchResponse = null;
        $selectedRow = null;
        $detailsResponse = null;
        $searchResponse = await fetchers.GetClientSearch($searchRequest);
        $isLoadingSearch = false;
    };




    /******* MODAL FOR SEARCHING keyAccountManager_personId for ClientSearchRequest - START ************/
    let modalControllerFindClientSearchRequest__keyAccountManager_personId_IsOpen: boolean;

    let modalClientSearchRequest__keyAccountManager_personId: ClientSearchRequest;
    const openFindClientSearchRequest__keyAccountManager_personId = (x: ClientSearchRequest) => {
        modalClientSearchRequest__keyAccountManager_personId = x;
        modalControllerFindClientSearchRequest__keyAccountManager_personId_IsOpen = true;
    };

    let keyAccountManager_personId: PersonDto = null;
    function onClientSearchRequest__keyAccountManager_personIdFound(c) {
        keyAccountManager_personId = c.detail;
        modalControllerFindClientSearchRequest__keyAccountManager_personId_IsOpen = false;
        modalClientSearchRequest__keyAccountManager_personId.keyAccountManager_personId.exactMatch = keyAccountManager_personId.personId;
        $searchRequest = $searchRequest;
    }
    /******* MODAL FOR SEARCHING keyAccountManager_personId for ClientSearchRequest - DONE ************/


    /******* MODAL FOR SEARCHING keyAccountManager_gender_genderId for ClientSearchRequest - START ************/
    let modalControllerFindClientSearchRequest__keyAccountManager_gender_genderId_IsOpen: boolean;

    let modalClientSearchRequest__keyAccountManager_gender_genderId: ClientSearchRequest;
    const openFindClientSearchRequest__keyAccountManager_gender_genderId = (x: ClientSearchRequest) => {
        modalClientSearchRequest__keyAccountManager_gender_genderId = x;
        modalControllerFindClientSearchRequest__keyAccountManager_gender_genderId_IsOpen = true;
    };

    let keyAccountManager_gender_genderId: GenderDto = null;
    function onClientSearchRequest__keyAccountManager_gender_genderIdFound(c) {
        keyAccountManager_gender_genderId = c.detail;
        modalControllerFindClientSearchRequest__keyAccountManager_gender_genderId_IsOpen = false;
        modalClientSearchRequest__keyAccountManager_gender_genderId.keyAccountManager_gender_genderId.exactMatch = keyAccountManager_gender_genderId.genderId;
        $searchRequest = $searchRequest;
    }
    /******* MODAL FOR SEARCHING keyAccountManager_gender_genderId for ClientSearchRequest - DONE ************/


    /******* MODAL FOR SEARCHING keyAccountManager_manager_personId for ClientSearchRequest - START ************/
    let modalControllerFindClientSearchRequest__keyAccountManager_manager_personId_IsOpen: boolean;

    let modalClientSearchRequest__keyAccountManager_manager_personId: ClientSearchRequest;
    const openFindClientSearchRequest__keyAccountManager_manager_personId = (x: ClientSearchRequest) => {
        modalClientSearchRequest__keyAccountManager_manager_personId = x;
        modalControllerFindClientSearchRequest__keyAccountManager_manager_personId_IsOpen = true;
    };

    let keyAccountManager_manager_personId: PersonDto = null;
    function onClientSearchRequest__keyAccountManager_manager_personIdFound(c) {
        keyAccountManager_manager_personId = c.detail;
        modalControllerFindClientSearchRequest__keyAccountManager_manager_personId_IsOpen = false;
        modalClientSearchRequest__keyAccountManager_manager_personId.keyAccountManager_manager_personId.exactMatch = keyAccountManager_manager_personId.personId;
        $searchRequest = $searchRequest;
    }
    /******* MODAL FOR SEARCHING keyAccountManager_manager_personId for ClientSearchRequest - DONE ************/


    /******* MODAL FOR SEARCHING keyAccountManager_manager_department_departmentId for ClientSearchRequest - START ************/
    let modalControllerFindClientSearchRequest__keyAccountManager_manager_department_departmentId_IsOpen: boolean;

    let modalClientSearchRequest__keyAccountManager_manager_department_departmentId: ClientSearchRequest;
    const openFindClientSearchRequest__keyAccountManager_manager_department_departmentId = (x: ClientSearchRequest) => {
        modalClientSearchRequest__keyAccountManager_manager_department_departmentId = x;
        modalControllerFindClientSearchRequest__keyAccountManager_manager_department_departmentId_IsOpen = true;
    };

    let keyAccountManager_manager_department_departmentId: DepartmentDto = null;
    function onClientSearchRequest__keyAccountManager_manager_department_departmentIdFound(c) {
        keyAccountManager_manager_department_departmentId = c.detail;
        modalControllerFindClientSearchRequest__keyAccountManager_manager_department_departmentId_IsOpen = false;
        modalClientSearchRequest__keyAccountManager_manager_department_departmentId.keyAccountManager_manager_department_departmentId.exactMatch = keyAccountManager_manager_department_departmentId.departmentId;
        $searchRequest = $searchRequest;
    }
    /******* MODAL FOR SEARCHING keyAccountManager_manager_department_departmentId for ClientSearchRequest - DONE ************/


    /******* MODAL FOR SEARCHING keyAccountManager_manager_gender_genderId for ClientSearchRequest - START ************/
    let modalControllerFindClientSearchRequest__keyAccountManager_manager_gender_genderId_IsOpen: boolean;

    let modalClientSearchRequest__keyAccountManager_manager_gender_genderId: ClientSearchRequest;
    const openFindClientSearchRequest__keyAccountManager_manager_gender_genderId = (x: ClientSearchRequest) => {
        modalClientSearchRequest__keyAccountManager_manager_gender_genderId = x;
        modalControllerFindClientSearchRequest__keyAccountManager_manager_gender_genderId_IsOpen = true;
    };

    let keyAccountManager_manager_gender_genderId: GenderDto = null;
    function onClientSearchRequest__keyAccountManager_manager_gender_genderIdFound(c) {
        keyAccountManager_manager_gender_genderId = c.detail;
        modalControllerFindClientSearchRequest__keyAccountManager_manager_gender_genderId_IsOpen = false;
        modalClientSearchRequest__keyAccountManager_manager_gender_genderId.keyAccountManager_manager_gender_genderId.exactMatch = keyAccountManager_manager_gender_genderId.genderId;
        $searchRequest = $searchRequest;
    }
    /******* MODAL FOR SEARCHING keyAccountManager_manager_gender_genderId for ClientSearchRequest - DONE ************/


</script>



    <Container>
{#if $filterResponse}
        <form on:submit|preventDefault={onSearch}>
            <Row>

<div class="col-10">
    <FormGroup>
        <Label>Client.QuickSearch</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.quickSearch} />
    </FormGroup>
</div>

            </Row>
            <Row>

<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Clients.Client.ClientId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.clientId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Client.PersonId (QS) <span style="cursor:pointer;" on:click={() => openFindClientSearchRequest__keyAccountManager_personId($searchRequest)}
                    ><Icon name="search" /></span></Label>
        <PersonLookupQuickSearch selectedObject={keyAccountManager_personId} bind:selectedId={$searchRequest.keyAccountManager_personId.exactMatch} isReadOnly={false} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Client Name</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.clientName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Client.KeyAccountManager.PersonId (RAW)</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.keyAccountManager_personId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>KAM Gender <span style="cursor:pointer;" on:click={() => openFindClientSearchRequest__keyAccountManager_gender_genderId($searchRequest)}
                    ><Icon name="search" /></span></Label>
        <GenderLookupQuickSearch selectedObject={keyAccountManager_gender_genderId} bind:selectedId={$searchRequest.keyAccountManager_gender_genderId.exactMatch} isReadOnly={false} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Client.KeyAccountManager.ManagerId <span style="cursor:pointer;" on:click={() => openFindClientSearchRequest__keyAccountManager_manager_personId($searchRequest)}
                    ><Icon name="search" /></span></Label>
        <PersonLookupQuickSearch selectedObject={keyAccountManager_manager_personId} bind:selectedId={$searchRequest.keyAccountManager_manager_personId.exactMatch} isReadOnly={false} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>KAM User name</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.keyAccountManager_userName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.keyAccountManager_gender_genderId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.keyAccountManager_gender_genderDescription.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.keyAccountManager_department_departmentId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.keyAccountManager_department_departmentName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.PersonId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.keyAccountManager_manager_personId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.DepartmentId <span style="cursor:pointer;" on:click={() => openFindClientSearchRequest__keyAccountManager_manager_department_departmentId($searchRequest)}
                    ><Icon name="search" /></span></Label>
        <DepartmentLookupQuickSearch selectedObject={keyAccountManager_manager_department_departmentId} bind:selectedId={$searchRequest.keyAccountManager_manager_department_departmentId.exactMatch} isReadOnly={false} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.GenderId <span style="cursor:pointer;" on:click={() => openFindClientSearchRequest__keyAccountManager_manager_gender_genderId($searchRequest)}
                    ><Icon name="search" /></span></Label>
        <GenderLookupQuickSearch selectedObject={keyAccountManager_manager_gender_genderId} bind:selectedId={$searchRequest.keyAccountManager_manager_gender_genderId.exactMatch} isReadOnly={false} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.UserName</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.keyAccountManager_manager_userName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.Salary</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.keyAccountManager_manager_salary.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.keyAccountManager_manager_gender_genderId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.keyAccountManager_manager_gender_genderDescription.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.keyAccountManager_manager_department_departmentId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.keyAccountManager_manager_department_departmentName.exactMatch} />
    </FormGroup>
</div>

            </Row>

<Row>
    <div class="col-2">
        <Button color="primary"><Icon name="search"/> Search</Button>
    </div>
</Row>

        </form>
{:else}
    <Spinner color="primary" />
{/if}
    </Container>

<Modal isOpen={modalControllerFindClientSearchRequest__keyAccountManager_personId_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find keyAccountManager_personId</ModalHeader>
    <ModalBody>
        <PersonLookup on:ok={onClientSearchRequest__keyAccountManager_personIdFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindClientSearchRequest__keyAccountManager_personId_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindClientSearchRequest__keyAccountManager_gender_genderId_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find keyAccountManager_gender_genderId</ModalHeader>
    <ModalBody>
        <GenderLookup on:ok={onClientSearchRequest__keyAccountManager_gender_genderIdFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindClientSearchRequest__keyAccountManager_gender_genderId_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindClientSearchRequest__keyAccountManager_manager_personId_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find keyAccountManager_manager_personId</ModalHeader>
    <ModalBody>
        <PersonLookup on:ok={onClientSearchRequest__keyAccountManager_manager_personIdFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindClientSearchRequest__keyAccountManager_manager_personId_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindClientSearchRequest__keyAccountManager_manager_department_departmentId_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find keyAccountManager_manager_department_departmentId</ModalHeader>
    <ModalBody>
        <DepartmentLookup on:ok={onClientSearchRequest__keyAccountManager_manager_department_departmentIdFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindClientSearchRequest__keyAccountManager_manager_department_departmentId_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindClientSearchRequest__keyAccountManager_manager_gender_genderId_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find keyAccountManager_manager_gender_genderId</ModalHeader>
    <ModalBody>
        <GenderLookup on:ok={onClientSearchRequest__keyAccountManager_manager_gender_genderIdFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindClientSearchRequest__keyAccountManager_manager_gender_genderId_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>

<style>
</style>
