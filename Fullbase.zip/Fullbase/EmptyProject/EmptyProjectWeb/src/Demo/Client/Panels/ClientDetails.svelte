
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        Normalizer,
        NormKey,
        userAuthentication,
ClientDto,PersonDto,GenderDto,DepartmentDto,ClientFilterRequest,ClientFilterResponse,ClientSearchRequest,ClientSearchResponse,ClientDetailsRequest,ClientDetailsResponse
    } from "../../../WebApi";
    import FBSelect from "../../../Components/FBSelect.svelte";
    import FBControl from "../../../Components/FBControl.svelte";
    import FBCard from "../../../Components/FBCard.svelte";
    import FBRootCard from "../../../Components/FBRootCard.svelte";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails } from "../ClientStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Card, CardHeader, CardTitle, CardBody, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean = false;
    let addCounter = -5;

import PersonLookup from "./../../PersonLookup/Pages/PersonLookup.svelte";
import PersonLookupQuickSearch from "./../../PersonLookup/Panels/PersonLookupQuickSearch.svelte";


import GenderLookup from "./../../GenderLookup/Pages/GenderLookup.svelte";
import GenderLookupQuickSearch from "./../../GenderLookup/Panels/GenderLookupQuickSearch.svelte";





    let isSaving: boolean = false;
    const onSave = async () => {
        isSaving = true;
        var copy = { ...$detailsResponse };

        //$detailsResponse = null;
        $detailsResponse = await fetchers.SaveClientDetails(copy);
        isSaving = false;
    };




    /******* MODAL FOR FINDING keyAccountManager for Client - START ************/
    let modalControllerFindClient__keyAccountManager_IsOpen: boolean;

    let modalClient__keyAccountManager: ClientDto;
    const openFindClient__keyAccountManager = (x: ClientDto) => {
        modalClient__keyAccountManager = x;
        modalControllerFindClient__keyAccountManager_IsOpen = true;
    };

    function onClient__keyAccountManagerFound(c) {
        var person: PersonDto = c.detail;
        modalControllerFindClient__keyAccountManager_IsOpen = false;
        modalClient__keyAccountManager.keyAccountManager = person;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING keyAccountManager for Client - DONE ************/


    /******* MODAL FOR FINDING gender for Person - START ************/
    let modalControllerFindPerson__gender_IsOpen: boolean;

    let modalPerson__gender: PersonDto;
    const openFindPerson__gender = (x: PersonDto) => {
        modalPerson__gender = x;
        modalControllerFindPerson__gender_IsOpen = true;
    };

    function onPerson__genderFound(c) {
        var gender: GenderDto = c.detail;
        modalControllerFindPerson__gender_IsOpen = false;
        modalPerson__gender.gender = gender;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING gender for Person - DONE ************/


</script>



<Container>
    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
        {#if $detailsResponse}
            <FBRootCard>
                <svelte:fragment slot="title">
                    Client
                </svelte:fragment>
                <svelte:fragment slot="savebutton">
                    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
                        {#if !isModal}
                            <button class="btn btn-primary" on:click={onSave}><Icon name="save" /> Save</button>
                        {/if}
                        {#if isSaving}
                            <Spinner color="primary" />
                        {/if}
                    {/if}
                </svelte:fragment>
                <svelte:fragment slot="body">
        
<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Clients.Client.ClientId</Label>
        {#if $detailsResponse?.client}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.client.clientId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Client Name</Label>
        {#if $detailsResponse?.client}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.client.clientName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.client.clientName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Client.PersonId (QS) <span style="cursor:pointer;" on:click={() => openFindClient__keyAccountManager($detailsResponse.client)}
                    ><Icon name="search" /></span></Label>
        {#if $detailsResponse?.client}
            
{#if true}
    <PersonLookupQuickSearch bind:selectedObject={$detailsResponse.client.keyAccountManager} selectedId={0} isReadOnly={false}/>
{:else if true}
    <PersonLookupQuickSearch bind:selectedObject={$detailsResponse.client.keyAccountManager} selectedId={0} isReadOnly={true}/>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">KeyAccountManager</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Client.KeyAccountManager.PersonId (RAW)</Label>
        {#if $detailsResponse?.client?.keyAccountManager}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.client.keyAccountManager.personId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>KAM User name</Label>
        {#if $detailsResponse?.client?.keyAccountManager}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.client.keyAccountManager.userName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.client.keyAccountManager.userName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>KAM Gender <span style="cursor:pointer;" on:click={() => openFindPerson__gender($detailsResponse.client.keyAccountManager)}
                    ><Icon name="search" /></span></Label>
        {#if $detailsResponse?.client?.keyAccountManager}
            
{#if true}
    <GenderLookupQuickSearch bind:selectedObject={$detailsResponse.client.keyAccountManager.gender} selectedId={0} isReadOnly={false}/>
{:else if true}
    <GenderLookupQuickSearch bind:selectedObject={$detailsResponse.client.keyAccountManager.gender} selectedId={0} isReadOnly={true}/>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">Gender</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        {#if $detailsResponse?.client?.keyAccountManager?.gender}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.client.keyAccountManager.gender.genderId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Gender</Label>
        {#if $detailsResponse?.client?.keyAccountManager?.gender}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.client.keyAccountManager.gender.genderDescription} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.client.keyAccountManager.gender.genderDescription}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Department</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentId</Label>
        {#if $detailsResponse?.client?.keyAccountManager?.department}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.client.keyAccountManager.department.departmentId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Department</Label>
        {#if $detailsResponse?.client?.keyAccountManager?.department}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.client.keyAccountManager.department.departmentName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.client.keyAccountManager.department.departmentName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

    </svelte:fragment>
</FBCard>

                </svelte:fragment>
                </FBRootCard>
        {:else if $isLoadingDetails}
            <Spinner color="primary" />
        {/if}
    {:else}
        **hidden**
    {/if}
</Container>

<Modal isOpen={modalControllerFindClient__keyAccountManager_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Person</ModalHeader>
    <ModalBody>
        <PersonLookup on:ok={onClient__keyAccountManagerFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindClient__keyAccountManager_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindPerson__gender_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Gender</ModalHeader>
    <ModalBody>
        <GenderLookup on:ok={onPerson__genderFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindPerson__gender_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>

<style>
</style>
