
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        Normalizer,
        NormKey,
ClientDto,PersonDto,GenderDto,DepartmentDto,ClientFilterRequest,ClientFilterResponse,ClientSearchRequest,ClientSearchResponse,ClientDetailsRequest,ClientDetailsResponse
    } from "../../../WebApi";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails, isLoadingSearch } from "../ClientStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;
    let addCounter = -3;

    


    const onDetails = async (x: ClientDto) => {
        var detailsRequest = new ClientDetailsRequest();
        detailsRequest.client = x;
        $selectedRow = x;
        $detailsResponse = null;

        if (isModal) {
            dispatch("ok", x);
            return;
        }

        if ($selectedRow != null) {
            $isLoadingDetails = true;
            $detailsResponse = await fetchers.GetClientDetails(detailsRequest);
            $isLoadingDetails = false;
        }
    };


    const addClient = async () => {
        $detailsResponse = null;
        var dr = new ClientDetailsResponse();
        dr.request = new ClientDetailsRequest();
        dr.request.client = new ClientDto();
        dr.request.client.clientId = -1;
        dr.client = new ClientDto();
        dr.client.clientId = -1;

        var detailsRequest = new ClientDetailsRequest();
        detailsRequest.client = new ClientDto();
        detailsRequest.client.clientId = -1;
        $selectedRow = null;
        $detailsResponse = null;
        $isLoadingDetails = true;
        $detailsResponse = await fetchers.GetClientDetails(detailsRequest);
        $isLoadingDetails = false;
    };


</script>


<Container fluid>

    <button class="btn btn-outline-primary btn-sm" on:click={addClient}><Icon name="plus-square" /> Add Client</button>
{#if $searchResponse}
    <Table>
        <thead>
            <tr>
<th>Project.Project_Clients.Client.ClientId</th>
<th>Client Name</th>
<th>Client.KeyAccountManager.PersonId (RAW)</th>
<th>KAM User name</th>
<th>Person.Gender.GenderId</th>
<th>Gender</th>
<th>Person.Department.DepartmentId</th>
<th>Department</th>
<th>Person.Manager.PersonId</th>
<th>Person.Manager.UserName</th>
<th>Person.Manager.Salary</th>
<th>Person.Gender.GenderId</th>
<th>Gender</th>
<th>Person.Department.DepartmentId</th>
<th>Department</th>

            </tr>
        </thead>
        <tbody>
        {#each $searchResponse.clients as row (row.clientId)}
            <tr
                on:click={() => onDetails(row)}
                class="clickable"
                class:btn-primary={$selectedRow != null && row.clientId === $selectedRow.clientId}
            >
<td>{row.clientId ? row.clientId : ""}</td>
<td>{row.clientName ? row.clientName : ""}</td>
<td>{row.keyAccountManager?.personId ? row.keyAccountManager?.personId : ""}</td>
<td>{row.keyAccountManager?.userName ? row.keyAccountManager?.userName : ""}</td>
<td>{row.keyAccountManager?.gender?.genderId ? row.keyAccountManager?.gender?.genderId : ""}</td>
<td>{row.keyAccountManager?.gender?.genderDescription ? row.keyAccountManager?.gender?.genderDescription : ""}</td>
<td>{row.keyAccountManager?.department?.departmentId ? row.keyAccountManager?.department?.departmentId : ""}</td>
<td>{row.keyAccountManager?.department?.departmentName ? row.keyAccountManager?.department?.departmentName : ""}</td>
<td>{row.keyAccountManager?.manager?.personId ? row.keyAccountManager?.manager?.personId : ""}</td>
<td>{row.keyAccountManager?.manager?.userName ? row.keyAccountManager?.manager?.userName : ""}</td>
<td>{row.keyAccountManager?.manager?.salary ? row.keyAccountManager?.manager?.salary : ""}</td>
<td>{row.keyAccountManager?.manager?.gender?.genderId ? row.keyAccountManager?.manager?.gender?.genderId : ""}</td>
<td>{row.keyAccountManager?.manager?.gender?.genderDescription ? row.keyAccountManager?.manager?.gender?.genderDescription : ""}</td>
<td>{row.keyAccountManager?.manager?.department?.departmentId ? row.keyAccountManager?.manager?.department?.departmentId : ""}</td>
<td>{row.keyAccountManager?.manager?.department?.departmentName ? row.keyAccountManager?.manager?.department?.departmentName : ""}</td>

            </tr>
        {/each}
        </tbody>
    </Table>
{:else if $isLoadingSearch}
    <Spinner color="primary" />
{/if}
</Container>

<style>
    .clickable {
        cursor: pointer;
    }
</style>
