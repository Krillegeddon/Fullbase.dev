
<script lang="ts">
    import { createEventDispatcher } from "svelte";
    import { filterResponse, searchResponse, detailsResponse } from "../PersonLookupStores";
    import PersonLookupFilter from "../Panels/PersonLookupFilter.svelte";
    import PersonLookupSearch from "../Panels/PersonLookupSearch.svelte";
    import PersonLookupQuickSearch from "../Panels/PersonLookupQuickSearch.svelte";
    import PersonLookupDetails from "../Panels/PersonLookupDetails.svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;

    // Relay back to caller...
    function onOk(c) {
        dispatch("ok", c.detail);
    }

    // Reset stores when surfing to page.
    $filterResponse = null;
    $searchResponse = null;
    $detailsResponse = null;
</script>

<PersonLookupFilter />
<hr />
<PersonLookupSearch {isModal} on:ok={onOk}/>
<hr />
<PersonLookupDetails />
