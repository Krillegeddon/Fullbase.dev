
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        Normalizer,
        NormKey,
PersonDto,DepartmentDto,GenderDto,PersonLookupFilterRequest,PersonLookupFilterResponse,PersonLookupSearchRequest,PersonLookupSearchResponse
    } from "../../../WebApi";
    import {createEventDispatcher} from "svelte";
    import { filterResponse,searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingSearch } from "../PersonLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import { Icon } from "sveltestrap";
    const dispatch = createEventDispatcher();

    //export let isModal: boolean;
    let addCounter = -1;

import PersonLookup from "./../../PersonLookup/Pages/PersonLookup.svelte";
import PersonLookupQuickSearch from "./../../PersonLookup/Panels/PersonLookupQuickSearch.svelte";





    onMount(async () => {
        var req = new PersonLookupFilterRequest(); // Default Filter Request
        $filterResponse = await fetchers.GetPersonLookupFilter(req);
        $searchRequest = new PersonLookupSearchRequest();
        $searchRequest.personId = new IntClause();
        $searchRequest.userName = new StringClause();
        $searchRequest.salary = new IntClause();
        $searchRequest.department_departmentId = new IntClause();
        $searchRequest.department_departmentName = new StringClause();
        $searchRequest.gender_genderId = new IntClause();
        $searchRequest.gender_genderDescription = new StringClause();
        $searchRequest.manager_personId = new IntClause();
        $searchRequest.manager_userName = new StringClause();
        $searchRequest.manager_salary = new IntClause();

    });



    const onSearch = async () => {
        $isLoadingSearch = true;
        $searchResponse = null;
        $selectedRow = null;
        $detailsResponse = null;
        $searchResponse = await fetchers.GetPersonLookupSearch($searchRequest);
        $isLoadingSearch = false;
    };




    /******* MODAL FOR SEARCHING manager_personId for PersonLookupSearchRequest - START ************/
    let modalControllerFindPersonLookupSearchRequest__manager_personId_IsOpen: boolean;

    let modalPersonLookupSearchRequest__manager_personId: PersonLookupSearchRequest;
    const openFindPersonLookupSearchRequest__manager_personId = (x: PersonLookupSearchRequest) => {
        modalPersonLookupSearchRequest__manager_personId = x;
        modalControllerFindPersonLookupSearchRequest__manager_personId_IsOpen = true;
    };

    let manager_personId: PersonDto = null;
    function onPersonLookupSearchRequest__manager_personIdFound(c) {
        manager_personId = c.detail;
        modalControllerFindPersonLookupSearchRequest__manager_personId_IsOpen = false;
        modalPersonLookupSearchRequest__manager_personId.manager_personId.exactMatch = manager_personId.personId;
        $searchRequest = $searchRequest;
    }
    /******* MODAL FOR SEARCHING manager_personId for PersonLookupSearchRequest - DONE ************/


</script>



    <Container>
{#if $filterResponse}
        <form on:submit|preventDefault={onSearch}>
            <Row>

<div class="col-10">
    <FormGroup>
        <Label>Person.QuickSearch</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.quickSearch} />
    </FormGroup>
</div>

            </Row>
            <Row>

<div class="col-5">
    <FormGroup>
        <Label>Person.PersonId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.personId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.DepartmentId</Label>
        
        <select class="form-control" bind:value={$searchRequest.department_departmentId.exactMatch}>
            <option value={null}>- all -</option>
            {#each $filterResponse.departments as department}
                <option value={department.departmentId}>{department.departmentName}</option>
            {/each}
        </select>

    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.GenderId</Label>
        
        <select class="form-control" bind:value={$searchRequest.gender_genderId.exactMatch}>
            <option value={null}>- all -</option>
            {#each $filterResponse.genders as gender}
                <option value={gender.genderId}>{gender.genderDescription}</option>
            {/each}
        </select>

    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.ManagerId <span style="cursor:pointer;" on:click={() => openFindPersonLookupSearchRequest__manager_personId($searchRequest)}
                    ><Icon name="search" /></span></Label>
        <PersonLookupQuickSearch selectedObject={manager_personId} bind:selectedId={$searchRequest.manager_personId.exactMatch} isReadOnly={false} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>User Name</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.userName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Salary</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.salary.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.department_departmentId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentName</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.department_departmentName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.gender_genderId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderDescription</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.gender_genderDescription.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.PersonId</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.manager_personId.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.UserName</Label>
        <input autocomplete="new-password" class="form-control" type="text" bind:value={$searchRequest.manager_userName.exactMatch} />
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.Salary</Label>
        <input autocomplete="new-password" class="form-control" type="number" bind:value={$searchRequest.manager_salary.exactMatch} />
    </FormGroup>
</div>

            </Row>

<Row>
    <div class="col-2">
        <Button color="primary"><Icon name="search"/> Search</Button>
    </div>
</Row>

        </form>
{:else}
    <Spinner color="primary" />
{/if}
    </Container>

<Modal isOpen={modalControllerFindPersonLookupSearchRequest__manager_personId_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find manager_personId</ModalHeader>
    <ModalBody>
        <PersonLookup on:ok={onPersonLookupSearchRequest__manager_personIdFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindPersonLookupSearchRequest__manager_personId_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>

<style>
</style>
