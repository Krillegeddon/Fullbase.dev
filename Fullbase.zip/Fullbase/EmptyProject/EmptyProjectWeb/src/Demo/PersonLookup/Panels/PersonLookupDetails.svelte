
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        Normalizer,
        NormKey,
        userAuthentication,
PersonDto,DepartmentDto,GenderDto,PersonLookupFilterRequest,PersonLookupFilterResponse,PersonLookupSearchRequest,PersonLookupSearchResponse,PersonLookupDetailsRequest,PersonLookupDetailsResponse
    } from "../../../WebApi";
    import FBSelect from "../../../Components/FBSelect.svelte";
    import FBControl from "../../../Components/FBControl.svelte";
    import FBCard from "../../../Components/FBCard.svelte";
    import FBRootCard from "../../../Components/FBRootCard.svelte";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails } from "../PersonLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Card, CardHeader, CardTitle, CardBody, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean = false;
    let addCounter = -5;

import PersonLookup from "./../../PersonLookup/Pages/PersonLookup.svelte";
import PersonLookupQuickSearch from "./../../PersonLookup/Panels/PersonLookupQuickSearch.svelte";





    let isSaving: boolean = false;
    const onSave = async () => {
        isSaving = true;
        var copy = { ...$detailsResponse };

        //$detailsResponse = null;
        $detailsResponse = await fetchers.SavePersonLookupDetails(copy);
        isSaving = false;
    };




    /******* MODAL FOR FINDING manager for Person - START ************/
    let modalControllerFindPerson__manager_IsOpen: boolean;

    let modalPerson__manager: PersonDto;
    const openFindPerson__manager = (x: PersonDto) => {
        modalPerson__manager = x;
        modalControllerFindPerson__manager_IsOpen = true;
    };

    function onPerson__managerFound(c) {
        var person: PersonDto = c.detail;
        modalControllerFindPerson__manager_IsOpen = false;
        modalPerson__manager.manager = person;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING manager for Person - DONE ************/


</script>



<Container>
    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
        {#if $detailsResponse}
            <FBRootCard>
                <svelte:fragment slot="title">
                    Person
                </svelte:fragment>
                <svelte:fragment slot="savebutton">
                    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
                        {#if !isModal}
                            <button class="btn btn-primary" on:click={onSave}><Icon name="save" /> Save</button>
                        {/if}
                        {#if isSaving}
                            <Spinner color="primary" />
                        {/if}
                    {/if}
                </svelte:fragment>
                <svelte:fragment slot="body">
        
<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.PersonId</Label>
        {#if $detailsResponse?.person}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.personId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>User Name</Label>
        {#if $detailsResponse?.person}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.userName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>User Name</Label>
        {#if $detailsResponse?.person}
            <span class="form-control">{$detailsResponse.person.userName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Salary</Label>
        {#if $detailsResponse?.person}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.salary} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Salary</Label>
        {#if $detailsResponse?.person}
            <span class="form-control">{$detailsResponse.person.salary}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.DepartmentId</Label>
        {#if $detailsResponse?.person}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.department}
        objects={$detailsResponse.departments}
        let:object
        isReadOnly={false}
    >
        <option>{object.departmentName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.DepartmentId</Label>
        {#if $detailsResponse?.person}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.department}
        objects={$detailsResponse.departments}
        let:object
        isReadOnly={true}
    >
        <option>{object.departmentName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.GenderId</Label>
        {#if $detailsResponse?.person}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.gender}
        objects={$detailsResponse.genders}
        let:object
        isReadOnly={false}
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.GenderId</Label>
        {#if $detailsResponse?.person}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.gender}
        objects={$detailsResponse.genders}
        let:object
        isReadOnly={true}
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.ManagerId <span style="cursor:pointer;" on:click={() => openFindPerson__manager($detailsResponse.person)}
                    ><Icon name="search" /></span></Label>
        {#if $detailsResponse?.person}
            <PersonLookupQuickSearch bind:selectedObject={$detailsResponse.person.manager} selectedId={0} isReadOnly={false}/>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.ManagerId</Label>
        {#if $detailsResponse?.person}
            <PersonLookupQuickSearch bind:selectedObject={$detailsResponse.person.manager} selectedId={0} isReadOnly={true}/>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">Department</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentId</Label>
        {#if $detailsResponse?.person?.department}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.department.departmentId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentName</Label>
        {#if $detailsResponse?.person?.department}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.department.departmentName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentName</Label>
        {#if $detailsResponse?.person?.department}
            <span class="form-control">{$detailsResponse.person.department.departmentName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Gender</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        {#if $detailsResponse?.person?.gender}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.gender.genderId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderDescription</Label>
        {#if $detailsResponse?.person?.gender}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.gender.genderDescription} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderDescription</Label>
        {#if $detailsResponse?.person?.gender}
            <span class="form-control">{$detailsResponse.person.gender.genderDescription}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Manager</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.PersonId</Label>
        {#if $detailsResponse?.person?.manager}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.manager.personId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.UserName</Label>
        {#if $detailsResponse?.person?.manager}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.manager.userName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.UserName</Label>
        {#if $detailsResponse?.person?.manager}
            <span class="form-control">{$detailsResponse.person.manager.userName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.Salary</Label>
        {#if $detailsResponse?.person?.manager}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.manager.salary} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.Salary</Label>
        {#if $detailsResponse?.person?.manager}
            <span class="form-control">{$detailsResponse.person.manager.salary}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.DepartmentId</Label>
        {#if $detailsResponse?.person?.manager}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.manager.department}
        objects={$detailsResponse.departments}
        let:object
        isReadOnly={false}
    >
        <option>{object.departmentName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.DepartmentId</Label>
        {#if $detailsResponse?.person?.manager}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.manager.department}
        objects={$detailsResponse.departments}
        let:object
        isReadOnly={true}
    >
        <option>{object.departmentName}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.GenderId</Label>
        {#if $detailsResponse?.person?.manager}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.manager.gender}
        objects={$detailsResponse.genders}
        let:object
        isReadOnly={false}
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.GenderId</Label>
        {#if $detailsResponse?.person?.manager}
            
    <FBSelect
        css="form-control"
        bind:value={$detailsResponse.person.manager.gender}
        objects={$detailsResponse.genders}
        let:object
        isReadOnly={true}
    >
        <option>{object.genderDescription}</option>
    </FBSelect>

        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">Department</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Department.DepartmentId</Label>
        {#if $detailsResponse?.person?.manager?.department}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.manager.department.departmentId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.Department.DepartmentName</Label>
        {#if $detailsResponse?.person?.manager?.department}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.manager.department.departmentName} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.Department.DepartmentName</Label>
        {#if $detailsResponse?.person?.manager?.department}
            <span class="form-control">{$detailsResponse.person.manager.department.departmentName}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Gender</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Person.Gender.GenderId</Label>
        {#if $detailsResponse?.person?.manager?.gender}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.person.manager.gender.genderId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.Gender.GenderDescription</Label>
        {#if $detailsResponse?.person?.manager?.gender}
            <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.person.manager.gender.genderDescription} />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    
<div class="col-5">
    <FormGroup>
        <Label>Person.Manager.Gender.GenderDescription</Label>
        {#if $detailsResponse?.person?.manager?.gender}
            <span class="form-control">{$detailsResponse.person.manager.gender.genderDescription}</span>
        {:else}
            null
        {/if}
    </FormGroup>
</div>

{/if}

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

    </svelte:fragment>
</FBCard>

                </svelte:fragment>
                </FBRootCard>
        {:else if $isLoadingDetails}
            <Spinner color="primary" />
        {/if}
    {:else}
        **hidden**
    {/if}
</Container>

<Modal isOpen={modalControllerFindPerson__manager_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Person</ModalHeader>
    <ModalBody>
        <PersonLookup on:ok={onPerson__managerFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindPerson__manager_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>

<style>
</style>
