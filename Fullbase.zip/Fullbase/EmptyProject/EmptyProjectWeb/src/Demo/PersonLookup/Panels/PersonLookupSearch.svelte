
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        Normalizer,
        NormKey,
PersonDto,DepartmentDto,GenderDto,PersonLookupFilterRequest,PersonLookupFilterResponse,PersonLookupSearchRequest,PersonLookupSearchResponse,PersonLookupDetailsRequest,PersonLookupDetailsResponse
    } from "../../../WebApi";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails, isLoadingSearch } from "../PersonLookupStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;
    let addCounter = -3;

    


    const onDetails = async (x: PersonDto) => {
        var detailsRequest = new PersonLookupDetailsRequest();
        detailsRequest.person = x;
        $selectedRow = x;
        $detailsResponse = null;

        if (isModal) {
            dispatch("ok", x);
            return;
        }

        if ($selectedRow != null) {
            $isLoadingDetails = true;
            $detailsResponse = await fetchers.GetPersonLookupDetails(detailsRequest);
            $isLoadingDetails = false;
        }
    };


    const addPerson = async () => {
        $detailsResponse = null;
        var dr = new PersonLookupDetailsResponse();
        dr.request = new PersonLookupDetailsRequest();
        dr.request.person = new PersonDto();
        dr.request.person.personId = -1;
        dr.person = new PersonDto();
        dr.person.personId = -1;

        var detailsRequest = new PersonLookupDetailsRequest();
        detailsRequest.person = new PersonDto();
        detailsRequest.person.personId = -1;
        $selectedRow = null;
        $detailsResponse = null;
        $isLoadingDetails = true;
        $detailsResponse = await fetchers.GetPersonLookupDetails(detailsRequest);
        $isLoadingDetails = false;
    };


</script>


<Container fluid>

    <button class="btn btn-outline-primary btn-sm" on:click={addPerson}><Icon name="plus-square" /> Add Person</button>
{#if $searchResponse}
    <Table>
        <thead>
            <tr>
<th>Person.PersonId</th>
<th>User Name</th>
<th>Person.Salary</th>
<th>Person.Department.DepartmentId</th>
<th>Person.Department.DepartmentName</th>
<th>Person.Gender.GenderId</th>
<th>Person.Gender.GenderDescription</th>
<th>Person.Manager.PersonId</th>
<th>Person.Manager.UserName</th>
<th>Person.Manager.Salary</th>

            </tr>
        </thead>
        <tbody>
        {#each $searchResponse.persons as row (row.personId)}
            <tr
                on:click={() => onDetails(row)}
                class="clickable"
                class:btn-primary={$selectedRow != null && row.personId === $selectedRow.personId}
            >
<td>{row.personId ? row.personId : "--"}</td>
<td>{row.userName ? row.userName : "--"}</td>
<td>{row.salary ? row.salary : "--"}</td>
<td>{row.department?.departmentId ? row.department?.departmentId : "--"}</td>
<td>{row.department?.departmentName ? row.department?.departmentName : "--"}</td>
<td>{row.gender?.genderId ? row.gender?.genderId : "--"}</td>
<td>{row.gender?.genderDescription ? row.gender?.genderDescription : "--"}</td>
<td>{row.manager?.personId ? row.manager?.personId : "--"}</td>
<td>{row.manager?.userName ? row.manager?.userName : "--"}</td>
<td>{row.manager?.salary ? row.manager?.salary : "--"}</td>

            </tr>
        {/each}
        </tbody>
    </Table>
{:else if $isLoadingSearch}
    <Spinner color="primary" />
{/if}
</Container>

<style>
    .clickable {
        cursor: pointer;
    }
</style>
