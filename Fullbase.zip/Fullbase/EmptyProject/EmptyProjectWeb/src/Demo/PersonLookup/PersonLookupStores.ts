
import { writable } from "svelte/store";
import type {
    PersonDto,
    PersonLookupFilterResponse,
    PersonLookupSearchRequest,
    PersonLookupSearchResponse,
    PersonLookupDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<PersonLookupFilterResponse>(null);
export let searchResponse = writable<PersonLookupSearchResponse>(null);
export let detailsResponse = writable<PersonLookupDetailsResponse>(null);
export let searchRequest = writable<PersonLookupSearchRequest>(null);
export let selectedRow = writable<PersonDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
