
import { writable } from "svelte/store";
import type {
    Project_ClientDto,
    Project_ClientExtendedFilterResponse,
    Project_ClientExtendedSearchRequest,
    Project_ClientExtendedSearchResponse,
    Project_ClientExtendedDetailsResponse,
} from "../../WebApi";
export let filterResponse = writable<Project_ClientExtendedFilterResponse>(null);
export let searchResponse = writable<Project_ClientExtendedSearchResponse>(null);
export let detailsResponse = writable<Project_ClientExtendedDetailsResponse>(null);
export let searchRequest = writable<Project_ClientExtendedSearchRequest>(null);
export let selectedRow = writable<Project_ClientDto>(null);
export let isLoadingSearch = writable<boolean>(false);
export let isLoadingDetails = writable<boolean>(false);
