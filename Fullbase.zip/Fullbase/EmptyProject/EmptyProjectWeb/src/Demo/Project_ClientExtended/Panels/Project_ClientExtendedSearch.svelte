
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        IntClause,
        BoolClause,
        Normalizer,
        NormKey,
Project_ClientDto,ProjectDto,ProjectTypeDto,ClientDto,PersonDto,Project_ClientExtendedFilterRequest,Project_ClientExtendedFilterResponse,Project_ClientExtendedSearchRequest,Project_ClientExtendedSearchResponse,Project_ClientExtendedDetailsRequest,Project_ClientExtendedDetailsResponse
    } from "../../../WebApi";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails, isLoadingSearch } from "../Project_ClientExtendedStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;
    let addCounter = -3;

    


    const onDetails = async (x: Project_ClientDto) => {
        var detailsRequest = new Project_ClientExtendedDetailsRequest();
        detailsRequest.project_Client = x;
        $selectedRow = x;
        $detailsResponse = null;

        if (isModal) {
            dispatch("ok", x);
            return;
        }

        if ($selectedRow != null) {
            $isLoadingDetails = true;
            $detailsResponse = await fetchers.GetProject_ClientExtendedDetails(detailsRequest);
            $isLoadingDetails = false;
        }
    };


    const addProject_Client = async () => {
        $detailsResponse = null;
        var dr = new Project_ClientExtendedDetailsResponse();
        dr.request = new Project_ClientExtendedDetailsRequest();
        dr.request.project_Client = new Project_ClientDto();
        dr.request.project_Client.project_ClientId = -1;
        dr.project_Client = new Project_ClientDto();
        dr.project_Client.project_ClientId = -1;

        var detailsRequest = new Project_ClientExtendedDetailsRequest();
        detailsRequest.project_Client = new Project_ClientDto();
        detailsRequest.project_Client.project_ClientId = -1;
        $selectedRow = null;
        $detailsResponse = null;
        $isLoadingDetails = true;
        $detailsResponse = await fetchers.GetProject_ClientExtendedDetails(detailsRequest);
        $isLoadingDetails = false;
    };


</script>


<Container fluid>

    <button class="btn btn-outline-primary btn-sm" on:click={addProject_Client}><Icon name="plus-square" /> Add Project_Client</button>
{#if $searchResponse}
    <Table>
        <thead>
            <tr>
<th>Project_Client.Project_ClientId</th>

            </tr>
        </thead>
        <tbody>
        {#each $searchResponse.project_Clients as row (row.project_ClientId)}
            <tr
                on:click={() => onDetails(row)}
                class="clickable"
                class:btn-primary={$selectedRow != null && row.project_ClientId === $selectedRow.project_ClientId}
            >
<td>{row.project_ClientId ? row.project_ClientId : "--"}</td>

            </tr>
        {/each}
        </tbody>
    </Table>
{:else if $isLoadingSearch}
    <Spinner color="primary" />
{/if}
</Container>

<style>
    .clickable {
        cursor: pointer;
    }
</style>
