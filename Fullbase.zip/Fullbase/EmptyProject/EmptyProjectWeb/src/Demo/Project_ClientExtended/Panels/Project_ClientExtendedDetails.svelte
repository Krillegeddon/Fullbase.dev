
<script lang="ts">
    import DateTimeInput from "../../../Components/DateTimeInput.svelte";
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import {
        fetchers,
        StringClause,
        NumberClause,
        BoolClause,
        Normalizer,
        NormKey,
        userAuthentication,
Project_ClientDto,ProjectDto,ProjectTypeDto,ClientDto,PersonDto,Project_ClientExtendedFilterRequest,Project_ClientExtendedFilterResponse,Project_ClientExtendedSearchRequest,Project_ClientExtendedSearchResponse,Project_ClientExtendedDetailsRequest,Project_ClientExtendedDetailsResponse
    } from "../../../WebApi";
    import FBSelect from "../../../Components/FBSelect.svelte";
    import FBControl from "../../../Components/FBControl.svelte";
    import FBCard from "../../../Components/FBCard.svelte";
    import FBRootCard from "../../../Components/FBRootCard.svelte";
    import { filterResponse, searchResponse, detailsResponse, searchRequest, selectedRow, isLoadingDetails } from "../Project_ClientExtendedStores";
    import { Col, Container, Row, Form, FormGroup, FormText, Input, Label, Button, Icon, Table, Spinner, Card, CardHeader, CardTitle, CardBody, Modal, ModalHeader, ModalBody, ModalFooter } from "sveltestrap";
    import {createEventDispatcher} from "svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean = false;
    let addCounter = -5;

import ProjectLookup from "./../../ProjectLookup/Pages/ProjectLookup.svelte";
import ProjectLookupQuickSearch from "./../../ProjectLookup/Panels/ProjectLookupQuickSearch.svelte";


import ClientLookup from "./../../ClientLookup/Pages/ClientLookup.svelte";
import ClientLookupQuickSearch from "./../../ClientLookup/Panels/ClientLookupQuickSearch.svelte";


import ProjectTypeLookup from "./../../ProjectTypeLookup/Pages/ProjectTypeLookup.svelte";
import ProjectTypeLookupQuickSearch from "./../../ProjectTypeLookup/Panels/ProjectTypeLookupQuickSearch.svelte";


import PersonLookup from "./../../PersonLookup/Pages/PersonLookup.svelte";
import PersonLookupQuickSearch from "./../../PersonLookup/Panels/PersonLookupQuickSearch.svelte";





    let isSaving: boolean = false;
    const onSave = async () => {
        isSaving = true;
        var copy = { ...$detailsResponse };

        //$detailsResponse = null;
        $detailsResponse = await fetchers.SaveProject_ClientExtendedDetails(copy);
        isSaving = false;
    };




    /******* MODAL FOR FINDING project for Project_Client - START ************/
    let modalControllerFindProject_Client__project_IsOpen: boolean;

    let modalProject_Client__project: Project_ClientDto;
    const openFindProject_Client__project = (x: Project_ClientDto) => {
        modalProject_Client__project = x;
        modalControllerFindProject_Client__project_IsOpen = true;
    };

    function onProject_Client__projectFound(c) {
        var project: ProjectDto = c.detail;
        modalControllerFindProject_Client__project_IsOpen = false;
        modalProject_Client__project.project = project;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING project for Project_Client - DONE ************/


    /******* MODAL FOR FINDING client for Project_Client - START ************/
    let modalControllerFindProject_Client__client_IsOpen: boolean;

    let modalProject_Client__client: Project_ClientDto;
    const openFindProject_Client__client = (x: Project_ClientDto) => {
        modalProject_Client__client = x;
        modalControllerFindProject_Client__client_IsOpen = true;
    };

    function onProject_Client__clientFound(c) {
        var client: ClientDto = c.detail;
        modalControllerFindProject_Client__client_IsOpen = false;
        modalProject_Client__client.client = client;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING client for Project_Client - DONE ************/


    /******* MODAL FOR FINDING projectType for Project - START ************/
    let modalControllerFindProject__projectType_IsOpen: boolean;

    let modalProject__projectType: ProjectDto;
    const openFindProject__projectType = (x: ProjectDto) => {
        modalProject__projectType = x;
        modalControllerFindProject__projectType_IsOpen = true;
    };

    function onProject__projectTypeFound(c) {
        var projectType: ProjectTypeDto = c.detail;
        modalControllerFindProject__projectType_IsOpen = false;
        modalProject__projectType.projectType = projectType;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING projectType for Project - DONE ************/


    /******* MODAL FOR FINDING keyAccountManager for Client - START ************/
    let modalControllerFindClient__keyAccountManager_IsOpen: boolean;

    let modalClient__keyAccountManager: ClientDto;
    const openFindClient__keyAccountManager = (x: ClientDto) => {
        modalClient__keyAccountManager = x;
        modalControllerFindClient__keyAccountManager_IsOpen = true;
    };

    function onClient__keyAccountManagerFound(c) {
        var person: PersonDto = c.detail;
        modalControllerFindClient__keyAccountManager_IsOpen = false;
        modalClient__keyAccountManager.keyAccountManager = person;
        $detailsResponse = $detailsResponse;
    }

    /******* MODAL FOR FINDING keyAccountManager for Client - DONE ************/


</script>



<Container>
    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
        {#if $detailsResponse}
            <FBRootCard>
                <svelte:fragment slot="title">
                    Project_Client
                </svelte:fragment>
                <svelte:fragment slot="savebutton">
                    {#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
                        {#if !isModal}
                            <button class="btn btn-primary" on:click={onSave}><Icon name="save" /> Save</button>
                        {/if}
                        {#if isSaving}
                            <Spinner color="primary" />
                        {/if}
                    {/if}
                </svelte:fragment>
                <svelte:fragment slot="body">
        
<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project_Client.Project_ClientId</Label>
        {#if $detailsResponse?.project_Client}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.project_Client.project_ClientId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project_Client.ProjectId <span style="cursor:pointer;" on:click={() => openFindProject_Client__project($detailsResponse.project_Client)}
                    ><Icon name="search" /></span></Label>
        {#if $detailsResponse?.project_Client}
            
{#if true}
    <ProjectLookupQuickSearch bind:selectedObject={$detailsResponse.project_Client.project} selectedId={0} isReadOnly={false}/>
{:else if true}
    <ProjectLookupQuickSearch bind:selectedObject={$detailsResponse.project_Client.project} selectedId={0} isReadOnly={true}/>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project_Client.ClientId <span style="cursor:pointer;" on:click={() => openFindProject_Client__client($detailsResponse.project_Client)}
                    ><Icon name="search" /></span></Label>
        {#if $detailsResponse?.project_Client}
            
{#if true}
    <ClientLookupQuickSearch bind:selectedObject={$detailsResponse.project_Client.client} selectedId={0} isReadOnly={false}/>
{:else if true}
    <ClientLookupQuickSearch bind:selectedObject={$detailsResponse.project_Client.client} selectedId={0} isReadOnly={true}/>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">Project</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>ProjectId</Label>
        {#if $detailsResponse?.project_Client?.project}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.project_Client.project.projectId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project Name</Label>
        {#if $detailsResponse?.project_Client?.project}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.project_Client.project.projectName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.project_Client.project.projectName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Is Pro-Bono</Label>
        {#if $detailsResponse?.project_Client?.project}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <div class="form-control">
    <input autocomplete="new-password" class="form-check-input" type="checkbox" bind:checked={$detailsResponse.project_Client.project.isProBono} />
</div>
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.project_Client.project.isProBono}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Deadline</Label>
        {#if $detailsResponse?.project_Client?.project}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <DateTimeInput css="form-control" bind:value={$detailsResponse.project_Client.project.deadline} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.project_Client.project.deadline}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project Type <span style="cursor:pointer;" on:click={() => openFindProject__projectType($detailsResponse.project_Client.project)}
                    ><Icon name="search" /></span></Label>
        {#if $detailsResponse?.project_Client?.project}
            
{#if true}
    <ProjectTypeLookupQuickSearch bind:selectedObject={$detailsResponse.project_Client.project.projectType} selectedId={0} isReadOnly={false}/>
{:else if true}
    <ProjectTypeLookupQuickSearch bind:selectedObject={$detailsResponse.project_Client.project.projectType} selectedId={0} isReadOnly={true}/>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">ProjectType</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectType.ProjectTypeId</Label>
        {#if $detailsResponse?.project_Client?.project?.projectType}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.project_Client.project.projectType.projectTypeId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project.ProjectType.ProjectTypeName</Label>
        {#if $detailsResponse?.project_Client?.project?.projectType}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.project_Client.project.projectType.projectTypeName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.project_Client.project.projectType.projectTypeName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

    </svelte:fragment>
</FBCard>

<FBCard>
    <svelte:fragment slot="title">Client</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Clients.Client.ClientId</Label>
        {#if $detailsResponse?.project_Client?.client}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.project_Client.client.clientId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Client Name</Label>
        {#if $detailsResponse?.project_Client?.client}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.project_Client.client.clientName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.project_Client.client.clientName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Clients.Client.PersonId <span style="cursor:pointer;" on:click={() => openFindClient__keyAccountManager($detailsResponse.project_Client.client)}
                    ><Icon name="search" /></span></Label>
        {#if $detailsResponse?.project_Client?.client}
            
{#if true}
    <PersonLookupQuickSearch bind:selectedObject={$detailsResponse.project_Client.client.keyAccountManager} selectedId={0} isReadOnly={false}/>
{:else if true}
    <PersonLookupQuickSearch bind:selectedObject={$detailsResponse.project_Client.client.keyAccountManager} selectedId={0} isReadOnly={true}/>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

<FBCard>
    <svelte:fragment slot="title">KeyAccountManager</svelte:fragment>
    <svelte:fragment slot="body">

<Row> <!-- props container markup! -->

<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Clients.Client.KeyAccountManager.PersonId</Label>
        {#if $detailsResponse?.project_Client?.client?.keyAccountManager}
            <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.project_Client.client.keyAccountManager.personId} disabled />
        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>KAM</Label>
        {#if $detailsResponse?.project_Client?.client?.keyAccountManager}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="text" bind:value={$detailsResponse.project_Client.client.keyAccountManager.userName} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.project_Client.client.keyAccountManager.userName}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

<div class="col-5">
    <FormGroup>
        <Label>Project.Project_Clients.Client.KeyAccountManager.Salary</Label>
        {#if $detailsResponse?.project_Client?.client?.keyAccountManager}
            
{#if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <input autocomplete="new-password" class="form-control" type="number" bind:value={$detailsResponse.project_Client.client.keyAccountManager.salary} />
{:else if userAuthentication.isDefault || userAuthentication.isAdmin || userAuthentication.isGuest}
    <span class="form-control">{$detailsResponse.project_Client.client.keyAccountManager.salary}</span>
{:else}
    **hidden**
{/if}

        {:else}
            null
        {/if}
    </FormGroup>
</div>

</Row> <!-- props container markup! -->

    </svelte:fragment>
</FBCard>

    </svelte:fragment>
</FBCard>

                </svelte:fragment>
                </FBRootCard>
        {:else if $isLoadingDetails}
            <Spinner color="primary" />
        {/if}
    {:else}
        **hidden**
    {/if}
</Container>

<Modal isOpen={modalControllerFindProject_Client__project_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Project</ModalHeader>
    <ModalBody>
        <ProjectLookup on:ok={onProject_Client__projectFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindProject_Client__project_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindProject_Client__client_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Client</ModalHeader>
    <ModalBody>
        <ClientLookup on:ok={onProject_Client__clientFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindProject_Client__client_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindProject__projectType_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find ProjectType</ModalHeader>
    <ModalBody>
        <ProjectTypeLookup on:ok={onProject__projectTypeFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindProject__projectType_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>



<Modal isOpen={modalControllerFindClient__keyAccountManager_IsOpen} backdrop={false} size="xl">
    <ModalHeader>Find Person</ModalHeader>
    <ModalBody>
        <PersonLookup on:ok={onClient__keyAccountManagerFound} isModal={true} />
    </ModalBody>
    <ModalFooter>
        <Button color="secondary" on:click={() => (modalControllerFindClient__keyAccountManager_IsOpen = false)}>Cancel</Button>
    </ModalFooter>
</Modal>

<style>
</style>
