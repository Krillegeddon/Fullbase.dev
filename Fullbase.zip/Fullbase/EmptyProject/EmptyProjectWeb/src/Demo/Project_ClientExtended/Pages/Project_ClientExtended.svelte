
<script lang="ts">
    import { createEventDispatcher } from "svelte";
    import { filterResponse, searchResponse, detailsResponse } from "../Project_ClientExtendedStores";
    import Project_ClientExtendedFilter from "../Panels/Project_ClientExtendedFilter.svelte";
    import Project_ClientExtendedSearch from "../Panels/Project_ClientExtendedSearch.svelte";
    import Project_ClientExtendedQuickSearch from "../Panels/Project_ClientExtendedQuickSearch.svelte";
    import Project_ClientExtendedDetails from "../Panels/Project_ClientExtendedDetails.svelte";
    const dispatch = createEventDispatcher();

    export let isModal: boolean;

    // Relay back to caller...
    function onOk(c) {
        dispatch("ok", c.detail);
    }

    // Reset stores when surfing to page.
    $filterResponse = null;
    $searchResponse = null;
    $detailsResponse = null;
</script>

<Project_ClientExtendedFilter />
<hr />
<Project_ClientExtendedSearch {isModal} on:ok={onOk}/>
<hr />
<Project_ClientExtendedDetails />
