
<script lang="ts">
    import Project from "./Demo/Project/Pages/Project.svelte";
        import PersonMini from "./Demo/PersonMini/Pages/PersonMini.svelte";
        import Person from "./Demo/Person/Pages/Person.svelte";
        import Client from "./Demo/Client/Pages/Client.svelte";
        import ClientLookup from "./Demo/ClientLookup/Pages/ClientLookup.svelte";
        import GenderLookup from "./Demo/GenderLookup/Pages/GenderLookup.svelte";
        import ProjectTypeLookup from "./Demo/ProjectTypeLookup/Pages/ProjectTypeLookup.svelte";
        import DepartmentLookup from "./Demo/DepartmentLookup/Pages/DepartmentLookup.svelte";
        import RoleLookup from "./Demo/RoleLookup/Pages/RoleLookup.svelte";
        import ProjectLookup from "./Demo/ProjectLookup/Pages/ProjectLookup.svelte";
        import PersonLookup from "./Demo/PersonLookup/Pages/PersonLookup.svelte";
        import Project_ClientExtended from "./Demo/Project_ClientExtended/Pages/Project_ClientExtended.svelte";
        import Project_Person_RoleExtended from "./Demo/Project_Person_RoleExtended/Pages/Project_Person_RoleExtended.svelte";

    import Tabs from "./Components/Tabs.svelte";

    let tabs = ["Project", "PersonMini", "Person", "Client", "ClientLookup", "GenderLookup", "ProjectTypeLookup", "DepartmentLookup", "RoleLookup", "ProjectLookup", "PersonLookup", "Project_ClientExtended", "Project_Person_RoleExtended"];
    let activeTab: string = tabs[0];
</script>
<svelte:head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="/demo.min.css" />
</svelte:head>

<Tabs bind:activeTab {tabs} />


{#if activeTab == "Project"}
    <Project  isModal={false} />
{/if}



{#if activeTab == "PersonMini"}
    <PersonMini  isModal={false} />
{/if}



{#if activeTab == "Person"}
    <Person  isModal={false} />
{/if}



{#if activeTab == "Client"}
    <Client  isModal={false} />
{/if}



{#if activeTab == "ClientLookup"}
    <ClientLookup  isModal={false} />
{/if}



{#if activeTab == "GenderLookup"}
    <GenderLookup  isModal={false} />
{/if}



{#if activeTab == "ProjectTypeLookup"}
    <ProjectTypeLookup  isModal={false} />
{/if}



{#if activeTab == "DepartmentLookup"}
    <DepartmentLookup  isModal={false} />
{/if}



{#if activeTab == "RoleLookup"}
    <RoleLookup  isModal={false} />
{/if}



{#if activeTab == "ProjectLookup"}
    <ProjectLookup  isModal={false} />
{/if}



{#if activeTab == "PersonLookup"}
    <PersonLookup  isModal={false} />
{/if}



{#if activeTab == "Project_ClientExtended"}
    <Project_ClientExtended  isModal={false} />
{/if}



{#if activeTab == "Project_Person_RoleExtended"}
    <Project_Person_RoleExtended  isModal={false} />
{/if}


