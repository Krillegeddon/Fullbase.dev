npx degit sveltejs/template DocuCodeWeb
cd DocuCodeWeb
node scripts/setupTypeScript.js
npm install
npm install --save svelte-routing

npm install svelte-file-dropzone
npm install @rollup/plugin-json --save-dev

gå in I rollup.config.js.
Lägg till denna rad LÄNGST UPP:
import json from '@rollup/plugin-json';

Gå sen ner till plugins :[ och lägg ner denna info:
json({
compact: true
}),



API: Nuget:
C:\Users\christian\.nuget\packages\microsoft.entityframeworkcore\3.1.10\
C:\Users\christian\.nuget\packages\microsoft.entityframeworkcore.design\3.1.10\
C:\Users\christian\.nuget\packages\newtonsoft.json\12.0.3\
C:\Users\christian\.nuget\packages\microsoft.entityframeworkcore.tools\3.1.10\
C:\Users\christian\.nuget\packages\microsoft.entityframeworkcore.sqlserver\3.1.10\