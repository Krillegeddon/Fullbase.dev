
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EmptyProjectCore.Utils;
using EmptyProjectCore.Models;

namespace EmptyProjectCore.Models
{
    public class DtoBase
    {
        public bool IsDeleted { get; set; }
        public bool IsTainted { get; set; }
        public virtual string _myName { get; }
    }

    public class IntClause
    {
        public int? ExactMatch { get; set; }
        public int? MoreThan { get; set; }
        public int? LessThan { get; set; }
        //public List<int> AnyOf { get; set; }
    }

    public class DateTimeClause
    {
        public DateTime? ExactMatch { get; set; }
        public DateTime? MoreThan { get; set; }
        public DateTime? LessThan { get; set; }
    }

    public class StringClause
    {
        public string ExactMatch { get; set; }
        public string ContainsMatch { get; set; }
        public string StartsWithMatch { get; set; }
        //public List<string> AnyOf { get; set; }
    }

    public class BoolClause
    {
        public bool? ExactMatch { get; set; }
    }

    public class TransferBase
    {
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public string StackTrace { get; set; }
        public Normalizer Normalizer { get; set; }
        public UserAuthentication UserAuthentication { get; set; }
    }

    public class NormKey
    {
        public string Key { get; set; }
        public object Object { get; set; }
        public string Jansson { get; set; }
        public bool IsDenormalized { get; set; }
    }

    public class Normalizer
    {
        public List<NormKey> DtoObjects { get; set; }

        public void CastDtoObjects(List<NormKey> dtoObjects)
        {
            foreach (var v in dtoObjects)
            {
                var k = v.Key;
                var s = k.Split('_');
                var s2 = new string[s.Length - 1];
                for (int i = 0; i < s.Length - 1; i++)
                {
                    s2[i] = s[i];
                }
                var t = string.Join('_', s2);

                if (t == "Client")
                    v.Object = JsonAux.Deserialize<ClientDto>(v.Jansson, true);

                if (t == "Department")
                    v.Object = JsonAux.Deserialize<DepartmentDto>(v.Jansson, true);

                if (t == "Gender")
                    v.Object = JsonAux.Deserialize<GenderDto>(v.Jansson, true);

                if (t == "Person")
                    v.Object = JsonAux.Deserialize<PersonDto>(v.Jansson, true);

                if (t == "Project")
                    v.Object = JsonAux.Deserialize<ProjectDto>(v.Jansson, true);

                if (t == "ProjectType")
                    v.Object = JsonAux.Deserialize<ProjectTypeDto>(v.Jansson, true);

                if (t == "Project_Client")
                    v.Object = JsonAux.Deserialize<Project_ClientDto>(v.Jansson, true);

                if (t == "Project_Person_Role")
                    v.Object = JsonAux.Deserialize<Project_Person_RoleDto>(v.Jansson, true);

                if (t == "Role")
                    v.Object = JsonAux.Deserialize<RoleDto>(v.Jansson, true);

                if (t == "ViewProjectAug")
                    v.Object = JsonAux.Deserialize<ViewProjectAugDto>(v.Jansson, true);

                if (t == "TestTable")
                    v.Object = JsonAux.Deserialize<TestTableDto>(v.Jansson, true);

                v.Jansson = null;
            }
        }

        /* ***   Normalizers.cs   *** */

        // Normalizer - Load.cs
        public ClientDto LoadClient(Client client)
        {
            // Normalizer - Load - Header.cs
            if (client == null)
                return null;
            var myKey = "Client_" + client.ClientId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            ClientDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return that object
                return (ClientDto)obj.Object;
            }
            else
            {
                retObj = new ClientDto();
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = retObj
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Load - Child tables.cs

            retObj.Project_Clients = new List<Project_ClientDto>();
            if (client?.Project_Clients != null)
                foreach (var x in client.Project_Clients)
                {
                    retObj.Project_Clients.Add(LoadProject_Client(x));
                }

            // Normalizer - Load - Id field.cs

            retObj.ClientId = client.ClientId;

            // Normalizer - Load - Ref fields.cs

            retObj.PersonId = client.PersonId;
            retObj.KeyAccountManager = LoadPerson(client.KeyAccountManager);

            // Normalizer - Load - Data fields.cs

            retObj.ClientName = client.ClientName;

            return retObj;
        }

        // Normalizer - Normalize.cs
        public void NormalizeClient(ClientDto client)
        {
            // Normalizer - Normalize - Header.cs
            if (client == null)
                return;
            var myKey = "Client_" + client.ClientId;
            var isAlreadyNormalized = false;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return. But no... don't do that!
                return;
                //isAlreadyNormalized = true;
            }
            else
            {
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = client
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Normalize - Child tables.cs

            if (!isAlreadyNormalized && client?.Project_Clients != null)
                foreach (var x in client.Project_Clients)
                {
                    NormalizeProject_Client(x);
                }

            // Normalizer - Normalize - Ref fields.cs

            if (!isAlreadyNormalized) // Normalize from table another table
                NormalizePerson(client.KeyAccountManager);
            client.KeyAccountManager = null;

        }

        // Normalizer - Denormalize.cs
        public ClientDto DenormalizeClient(ClientDto client)
        {
            // Normalizer - Denormalize - Header.cs
            if (client == null)
                return null;
            var myKey = "Client_" + client.ClientId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            ClientDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null && obj.Object != null && obj.IsDenormalized)
            {
                // If already denormalized, just return that object
                return (ClientDto)obj.Object;
            }
            else
            {
                if (obj == null)
                {
                    return null; // Wasn't loaded before normalization
                }
                retObj = (ClientDto)obj.Object;
                obj.IsDenormalized = true;
            }

            // Normalizer - Denormalize - Child tables.cs

            if (client?.Project_Clients != null)
                for (int i = 0; i< client?.Project_Clients?.Count; i++)
                {
                    retObj.Project_Clients[i] = DenormalizeProject_Client(client.Project_Clients[i]);
                }

            // Normalizer - Denormalize - Ref fields.cs

            {
                // Denormalize from table another table
                var x = (PersonDto) this.DtoObjects.Where(p => p.Key == "Person_" + client.PersonId).Select(p => p.Object).SingleOrDefault();
                retObj.KeyAccountManager = DenormalizePerson(x);
            }

            return retObj;
        }

        // Normalizer - Load.cs
        public DepartmentDto LoadDepartment(Department department)
        {
            // Normalizer - Load - Header.cs
            if (department == null)
                return null;
            var myKey = "Department_" + department.DepartmentId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            DepartmentDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return that object
                return (DepartmentDto)obj.Object;
            }
            else
            {
                retObj = new DepartmentDto();
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = retObj
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Load - Child tables.cs

            retObj.Persons = new List<PersonDto>();
            if (department?.Persons != null)
                foreach (var x in department.Persons)
                {
                    retObj.Persons.Add(LoadPerson(x));
                }

            // Normalizer - Load - Id field.cs

            retObj.DepartmentId = department.DepartmentId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.DepartmentName = department.DepartmentName;

            return retObj;
        }

        // Normalizer - Normalize.cs
        public void NormalizeDepartment(DepartmentDto department)
        {
            // Normalizer - Normalize - Header.cs
            if (department == null)
                return;
            var myKey = "Department_" + department.DepartmentId;
            var isAlreadyNormalized = false;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return. But no... don't do that!
                return;
                //isAlreadyNormalized = true;
            }
            else
            {
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = department
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Normalize - Child tables.cs

            if (!isAlreadyNormalized && department?.Persons != null)
                foreach (var x in department.Persons)
                {
                    NormalizePerson(x);
                }

            // Normalizer - Normalize - Ref fields.cs

        }

        // Normalizer - Denormalize.cs
        public DepartmentDto DenormalizeDepartment(DepartmentDto department)
        {
            // Normalizer - Denormalize - Header.cs
            if (department == null)
                return null;
            var myKey = "Department_" + department.DepartmentId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            DepartmentDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null && obj.Object != null && obj.IsDenormalized)
            {
                // If already denormalized, just return that object
                return (DepartmentDto)obj.Object;
            }
            else
            {
                if (obj == null)
                {
                    return null; // Wasn't loaded before normalization
                }
                retObj = (DepartmentDto)obj.Object;
                obj.IsDenormalized = true;
            }

            // Normalizer - Denormalize - Child tables.cs

            if (department?.Persons != null)
                for (int i = 0; i< department?.Persons?.Count; i++)
                {
                    retObj.Persons[i] = DenormalizePerson(department.Persons[i]);
                }

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }

        // Normalizer - Load.cs
        public GenderDto LoadGender(Gender gender)
        {
            // Normalizer - Load - Header.cs
            if (gender == null)
                return null;
            var myKey = "Gender_" + gender.GenderId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            GenderDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return that object
                return (GenderDto)obj.Object;
            }
            else
            {
                retObj = new GenderDto();
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = retObj
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Load - Child tables.cs

            retObj.Persons = new List<PersonDto>();
            if (gender?.Persons != null)
                foreach (var x in gender.Persons)
                {
                    retObj.Persons.Add(LoadPerson(x));
                }

            // Normalizer - Load - Id field.cs

            retObj.GenderId = gender.GenderId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.GenderDescription = gender.GenderDescription;

            return retObj;
        }

        // Normalizer - Normalize.cs
        public void NormalizeGender(GenderDto gender)
        {
            // Normalizer - Normalize - Header.cs
            if (gender == null)
                return;
            var myKey = "Gender_" + gender.GenderId;
            var isAlreadyNormalized = false;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return. But no... don't do that!
                return;
                //isAlreadyNormalized = true;
            }
            else
            {
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = gender
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Normalize - Child tables.cs

            if (!isAlreadyNormalized && gender?.Persons != null)
                foreach (var x in gender.Persons)
                {
                    NormalizePerson(x);
                }

            // Normalizer - Normalize - Ref fields.cs

        }

        // Normalizer - Denormalize.cs
        public GenderDto DenormalizeGender(GenderDto gender)
        {
            // Normalizer - Denormalize - Header.cs
            if (gender == null)
                return null;
            var myKey = "Gender_" + gender.GenderId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            GenderDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null && obj.Object != null && obj.IsDenormalized)
            {
                // If already denormalized, just return that object
                return (GenderDto)obj.Object;
            }
            else
            {
                if (obj == null)
                {
                    return null; // Wasn't loaded before normalization
                }
                retObj = (GenderDto)obj.Object;
                obj.IsDenormalized = true;
            }

            // Normalizer - Denormalize - Child tables.cs

            if (gender?.Persons != null)
                for (int i = 0; i< gender?.Persons?.Count; i++)
                {
                    retObj.Persons[i] = DenormalizePerson(gender.Persons[i]);
                }

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }

        // Normalizer - Load.cs
        public PersonDto LoadPerson(Person person)
        {
            // Normalizer - Load - Header.cs
            if (person == null)
                return null;
            var myKey = "Person_" + person.PersonId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            PersonDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return that object
                return (PersonDto)obj.Object;
            }
            else
            {
                retObj = new PersonDto();
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = retObj
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Load - Child tables.cs

            retObj.Clients = new List<ClientDto>();
            if (person?.Clients != null)
                foreach (var x in person.Clients)
                {
                    retObj.Clients.Add(LoadClient(x));
                }

            retObj.Employees = new List<PersonDto>();
            if (person?.Employees != null)
                foreach (var x in person.Employees)
                {
                    retObj.Employees.Add(LoadPerson(x));
                }

            retObj.Project_Person_Roles = new List<Project_Person_RoleDto>();
            if (person?.Project_Person_Roles != null)
                foreach (var x in person.Project_Person_Roles)
                {
                    retObj.Project_Person_Roles.Add(LoadProject_Person_Role(x));
                }

            // Normalizer - Load - Id field.cs

            retObj.PersonId = person.PersonId;

            // Normalizer - Load - Ref fields.cs

            retObj.DepartmentId = person.DepartmentId;
            retObj.Department = LoadDepartment(person.Department);

            retObj.GenderId = person.GenderId;
            retObj.Gender = LoadGender(person.Gender);

            retObj.ManagerId = person.ManagerId;
            retObj.Manager = LoadPerson(person.Manager);

            // Normalizer - Load - Data fields.cs

            retObj.UserName = person.UserName;

            retObj.Salary = person.Salary;

            return retObj;
        }

        // Normalizer - Normalize.cs
        public void NormalizePerson(PersonDto person)
        {
            // Normalizer - Normalize - Header.cs
            if (person == null)
                return;
            var myKey = "Person_" + person.PersonId;
            var isAlreadyNormalized = false;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return. But no... don't do that!
                return;
                //isAlreadyNormalized = true;
            }
            else
            {
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = person
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Normalize - Child tables.cs

            if (!isAlreadyNormalized && person?.Clients != null)
                foreach (var x in person.Clients)
                {
                    NormalizeClient(x);
                }

            if (!isAlreadyNormalized && person?.Employees != null)
                foreach (var x in person.Employees)
                {
                    NormalizePerson(x);
                }

            if (!isAlreadyNormalized && person?.Project_Person_Roles != null)
                foreach (var x in person.Project_Person_Roles)
                {
                    NormalizeProject_Person_Role(x);
                }

            // Normalizer - Normalize - Ref fields.cs

            if (!isAlreadyNormalized) // Normalize from table another table
                NormalizeDepartment(person.Department);
            person.Department = null;

            if (!isAlreadyNormalized) // Normalize from table another table
                NormalizeGender(person.Gender);
            person.Gender = null;

            if (!isAlreadyNormalized) // Normalize from table another table
                NormalizePerson(person.Manager);
            person.Manager = null;

        }

        // Normalizer - Denormalize.cs
        public PersonDto DenormalizePerson(PersonDto person)
        {
            // Normalizer - Denormalize - Header.cs
            if (person == null)
                return null;
            var myKey = "Person_" + person.PersonId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            PersonDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null && obj.Object != null && obj.IsDenormalized)
            {
                // If already denormalized, just return that object
                return (PersonDto)obj.Object;
            }
            else
            {
                if (obj == null)
                {
                    return null; // Wasn't loaded before normalization
                }
                retObj = (PersonDto)obj.Object;
                obj.IsDenormalized = true;
            }

            // Normalizer - Denormalize - Child tables.cs

            if (person?.Clients != null)
                for (int i = 0; i< person?.Clients?.Count; i++)
                {
                    retObj.Clients[i] = DenormalizeClient(person.Clients[i]);
                }

            if (person?.Employees != null)
                for (int i = 0; i< person?.Employees?.Count; i++)
                {
                    retObj.Employees[i] = DenormalizePerson(person.Employees[i]);
                }

            if (person?.Project_Person_Roles != null)
                for (int i = 0; i< person?.Project_Person_Roles?.Count; i++)
                {
                    retObj.Project_Person_Roles[i] = DenormalizeProject_Person_Role(person.Project_Person_Roles[i]);
                }

            // Normalizer - Denormalize - Ref fields.cs

            {
                // Denormalize from table another table
                var x = (DepartmentDto) this.DtoObjects.Where(p => p.Key == "Department_" + person.DepartmentId).Select(p => p.Object).SingleOrDefault();
                retObj.Department = DenormalizeDepartment(x);
            }

            {
                // Denormalize from table another table
                var x = (GenderDto) this.DtoObjects.Where(p => p.Key == "Gender_" + person.GenderId).Select(p => p.Object).SingleOrDefault();
                retObj.Gender = DenormalizeGender(x);
            }

            {
                // Denormalize from table another table
                var x = (PersonDto) this.DtoObjects.Where(p => p.Key == "Person_" + person.ManagerId).Select(p => p.Object).SingleOrDefault();
                retObj.Manager = DenormalizePerson(x);
            }

            return retObj;
        }

        // Normalizer - Load.cs
        public ProjectDto LoadProject(Project project)
        {
            // Normalizer - Load - Header.cs
            if (project == null)
                return null;
            var myKey = "Project_" + project.ProjectId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            ProjectDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return that object
                return (ProjectDto)obj.Object;
            }
            else
            {
                retObj = new ProjectDto();
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = retObj
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Load - Child tables.cs

            retObj.Project_Clients = new List<Project_ClientDto>();
            if (project?.Project_Clients != null)
                foreach (var x in project.Project_Clients)
                {
                    retObj.Project_Clients.Add(LoadProject_Client(x));
                }

            retObj.Project_Person_Roles = new List<Project_Person_RoleDto>();
            if (project?.Project_Person_Roles != null)
                foreach (var x in project.Project_Person_Roles)
                {
                    retObj.Project_Person_Roles.Add(LoadProject_Person_Role(x));
                }

            // Normalizer - Load - Id field.cs

            retObj.ProjectId = project.ProjectId;

            // Normalizer - Load - Ref fields.cs

            retObj.ProjectTypeId = project.ProjectTypeId;
            retObj.ProjectType = LoadProjectType(project.ProjectType);

            retObj.ViewProjectAug = LoadViewProjectAug(project.ViewProjectAug);

            // Normalizer - Load - Data fields.cs

            retObj.ProjectName = project.ProjectName;

            retObj.IsProBono = project.IsProBono;

            retObj.Deadline = project.Deadline;

            return retObj;
        }

        // Normalizer - Normalize.cs
        public void NormalizeProject(ProjectDto project)
        {
            // Normalizer - Normalize - Header.cs
            if (project == null)
                return;
            var myKey = "Project_" + project.ProjectId;
            var isAlreadyNormalized = false;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return. But no... don't do that!
                return;
                //isAlreadyNormalized = true;
            }
            else
            {
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = project
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Normalize - Child tables.cs

            if (!isAlreadyNormalized && project?.Project_Clients != null)
                foreach (var x in project.Project_Clients)
                {
                    NormalizeProject_Client(x);
                }

            if (!isAlreadyNormalized && project?.Project_Person_Roles != null)
                foreach (var x in project.Project_Person_Roles)
                {
                    NormalizeProject_Person_Role(x);
                }

            // Normalizer - Normalize - Ref fields.cs

            if (!isAlreadyNormalized) // Normalize from table another table
                NormalizeProjectType(project.ProjectType);
            project.ProjectType = null;

        }

        // Normalizer - Denormalize.cs
        public ProjectDto DenormalizeProject(ProjectDto project)
        {
            // Normalizer - Denormalize - Header.cs
            if (project == null)
                return null;
            var myKey = "Project_" + project.ProjectId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            ProjectDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null && obj.Object != null && obj.IsDenormalized)
            {
                // If already denormalized, just return that object
                return (ProjectDto)obj.Object;
            }
            else
            {
                if (obj == null)
                {
                    return null; // Wasn't loaded before normalization
                }
                retObj = (ProjectDto)obj.Object;
                obj.IsDenormalized = true;
            }

            // Normalizer - Denormalize - Child tables.cs

            if (project?.Project_Clients != null)
                for (int i = 0; i< project?.Project_Clients?.Count; i++)
                {
                    retObj.Project_Clients[i] = DenormalizeProject_Client(project.Project_Clients[i]);
                }

            if (project?.Project_Person_Roles != null)
                for (int i = 0; i< project?.Project_Person_Roles?.Count; i++)
                {
                    retObj.Project_Person_Roles[i] = DenormalizeProject_Person_Role(project.Project_Person_Roles[i]);
                }

            // Normalizer - Denormalize - Ref fields.cs

            {
                // Denormalize from table another table
                var x = (ProjectTypeDto) this.DtoObjects.Where(p => p.Key == "ProjectType_" + project.ProjectTypeId).Select(p => p.Object).SingleOrDefault();
                retObj.ProjectType = DenormalizeProjectType(x);
            }

            return retObj;
        }

        // Normalizer - Load.cs
        public ProjectTypeDto LoadProjectType(ProjectType projectType)
        {
            // Normalizer - Load - Header.cs
            if (projectType == null)
                return null;
            var myKey = "ProjectType_" + projectType.ProjectTypeId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            ProjectTypeDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return that object
                return (ProjectTypeDto)obj.Object;
            }
            else
            {
                retObj = new ProjectTypeDto();
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = retObj
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Load - Child tables.cs

            retObj.Projects = new List<ProjectDto>();
            if (projectType?.Projects != null)
                foreach (var x in projectType.Projects)
                {
                    retObj.Projects.Add(LoadProject(x));
                }

            // Normalizer - Load - Id field.cs

            retObj.ProjectTypeId = projectType.ProjectTypeId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.ProjectTypeName = projectType.ProjectTypeName;

            return retObj;
        }

        // Normalizer - Normalize.cs
        public void NormalizeProjectType(ProjectTypeDto projectType)
        {
            // Normalizer - Normalize - Header.cs
            if (projectType == null)
                return;
            var myKey = "ProjectType_" + projectType.ProjectTypeId;
            var isAlreadyNormalized = false;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return. But no... don't do that!
                return;
                //isAlreadyNormalized = true;
            }
            else
            {
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = projectType
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Normalize - Child tables.cs

            if (!isAlreadyNormalized && projectType?.Projects != null)
                foreach (var x in projectType.Projects)
                {
                    NormalizeProject(x);
                }

            // Normalizer - Normalize - Ref fields.cs

        }

        // Normalizer - Denormalize.cs
        public ProjectTypeDto DenormalizeProjectType(ProjectTypeDto projectType)
        {
            // Normalizer - Denormalize - Header.cs
            if (projectType == null)
                return null;
            var myKey = "ProjectType_" + projectType.ProjectTypeId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            ProjectTypeDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null && obj.Object != null && obj.IsDenormalized)
            {
                // If already denormalized, just return that object
                return (ProjectTypeDto)obj.Object;
            }
            else
            {
                if (obj == null)
                {
                    return null; // Wasn't loaded before normalization
                }
                retObj = (ProjectTypeDto)obj.Object;
                obj.IsDenormalized = true;
            }

            // Normalizer - Denormalize - Child tables.cs

            if (projectType?.Projects != null)
                for (int i = 0; i< projectType?.Projects?.Count; i++)
                {
                    retObj.Projects[i] = DenormalizeProject(projectType.Projects[i]);
                }

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }

        // Normalizer - Load.cs
        public Project_ClientDto LoadProject_Client(Project_Client project_Client)
        {
            // Normalizer - Load - Header.cs
            if (project_Client == null)
                return null;
            var myKey = "Project_Client_" + project_Client.Project_ClientId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            Project_ClientDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return that object
                return (Project_ClientDto)obj.Object;
            }
            else
            {
                retObj = new Project_ClientDto();
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = retObj
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Load - Child tables.cs

            // Normalizer - Load - Id field.cs

            retObj.Project_ClientId = project_Client.Project_ClientId;

            // Normalizer - Load - Ref fields.cs

            retObj.ProjectId = project_Client.ProjectId;
            retObj.Project = LoadProject(project_Client.Project);

            retObj.ClientId = project_Client.ClientId;
            retObj.Client = LoadClient(project_Client.Client);

            // Normalizer - Load - Data fields.cs

            return retObj;
        }

        // Normalizer - Normalize.cs
        public void NormalizeProject_Client(Project_ClientDto project_Client)
        {
            // Normalizer - Normalize - Header.cs
            if (project_Client == null)
                return;
            var myKey = "Project_Client_" + project_Client.Project_ClientId;
            var isAlreadyNormalized = false;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return. But no... don't do that!
                return;
                //isAlreadyNormalized = true;
            }
            else
            {
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = project_Client
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Normalize - Child tables.cs

            // Normalizer - Normalize - Ref fields.cs

            if (!isAlreadyNormalized) // Normalize from table another table
                NormalizeProject(project_Client.Project);
            project_Client.Project = null;

            if (!isAlreadyNormalized) // Normalize from table another table
                NormalizeClient(project_Client.Client);
            project_Client.Client = null;

        }

        // Normalizer - Denormalize.cs
        public Project_ClientDto DenormalizeProject_Client(Project_ClientDto project_Client)
        {
            // Normalizer - Denormalize - Header.cs
            if (project_Client == null)
                return null;
            var myKey = "Project_Client_" + project_Client.Project_ClientId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            Project_ClientDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null && obj.Object != null && obj.IsDenormalized)
            {
                // If already denormalized, just return that object
                return (Project_ClientDto)obj.Object;
            }
            else
            {
                if (obj == null)
                {
                    return null; // Wasn't loaded before normalization
                }
                retObj = (Project_ClientDto)obj.Object;
                obj.IsDenormalized = true;
            }

            // Normalizer - Denormalize - Child tables.cs

            // Normalizer - Denormalize - Ref fields.cs

            {
                // Denormalize from table another table
                var x = (ProjectDto) this.DtoObjects.Where(p => p.Key == "Project_" + project_Client.ProjectId).Select(p => p.Object).SingleOrDefault();
                retObj.Project = DenormalizeProject(x);
            }

            {
                // Denormalize from table another table
                var x = (ClientDto) this.DtoObjects.Where(p => p.Key == "Client_" + project_Client.ClientId).Select(p => p.Object).SingleOrDefault();
                retObj.Client = DenormalizeClient(x);
            }

            return retObj;
        }

        // Normalizer - Load.cs
        public Project_Person_RoleDto LoadProject_Person_Role(Project_Person_Role project_Person_Role)
        {
            // Normalizer - Load - Header.cs
            if (project_Person_Role == null)
                return null;
            var myKey = "Project_Person_Role_" + project_Person_Role.Project_Person_RoleId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            Project_Person_RoleDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return that object
                return (Project_Person_RoleDto)obj.Object;
            }
            else
            {
                retObj = new Project_Person_RoleDto();
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = retObj
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Load - Child tables.cs

            // Normalizer - Load - Id field.cs

            retObj.Project_Person_RoleId = project_Person_Role.Project_Person_RoleId;

            // Normalizer - Load - Ref fields.cs

            retObj.PersonId = project_Person_Role.PersonId;
            retObj.Person = LoadPerson(project_Person_Role.Person);

            retObj.ProjectId = project_Person_Role.ProjectId;
            retObj.Project = LoadProject(project_Person_Role.Project);

            retObj.RoleId = project_Person_Role.RoleId;
            retObj.Role = LoadRole(project_Person_Role.Role);

            // Normalizer - Load - Data fields.cs

            return retObj;
        }

        // Normalizer - Normalize.cs
        public void NormalizeProject_Person_Role(Project_Person_RoleDto project_Person_Role)
        {
            // Normalizer - Normalize - Header.cs
            if (project_Person_Role == null)
                return;
            var myKey = "Project_Person_Role_" + project_Person_Role.Project_Person_RoleId;
            var isAlreadyNormalized = false;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return. But no... don't do that!
                return;
                //isAlreadyNormalized = true;
            }
            else
            {
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = project_Person_Role
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Normalize - Child tables.cs

            // Normalizer - Normalize - Ref fields.cs

            if (!isAlreadyNormalized) // Normalize from table another table
                NormalizePerson(project_Person_Role.Person);
            project_Person_Role.Person = null;

            if (!isAlreadyNormalized) // Normalize from table another table
                NormalizeProject(project_Person_Role.Project);
            project_Person_Role.Project = null;

            if (!isAlreadyNormalized) // Normalize from table another table
                NormalizeRole(project_Person_Role.Role);
            project_Person_Role.Role = null;

        }

        // Normalizer - Denormalize.cs
        public Project_Person_RoleDto DenormalizeProject_Person_Role(Project_Person_RoleDto project_Person_Role)
        {
            // Normalizer - Denormalize - Header.cs
            if (project_Person_Role == null)
                return null;
            var myKey = "Project_Person_Role_" + project_Person_Role.Project_Person_RoleId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            Project_Person_RoleDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null && obj.Object != null && obj.IsDenormalized)
            {
                // If already denormalized, just return that object
                return (Project_Person_RoleDto)obj.Object;
            }
            else
            {
                if (obj == null)
                {
                    return null; // Wasn't loaded before normalization
                }
                retObj = (Project_Person_RoleDto)obj.Object;
                obj.IsDenormalized = true;
            }

            // Normalizer - Denormalize - Child tables.cs

            // Normalizer - Denormalize - Ref fields.cs

            {
                // Denormalize from table another table
                var x = (PersonDto) this.DtoObjects.Where(p => p.Key == "Person_" + project_Person_Role.PersonId).Select(p => p.Object).SingleOrDefault();
                retObj.Person = DenormalizePerson(x);
            }

            {
                // Denormalize from table another table
                var x = (ProjectDto) this.DtoObjects.Where(p => p.Key == "Project_" + project_Person_Role.ProjectId).Select(p => p.Object).SingleOrDefault();
                retObj.Project = DenormalizeProject(x);
            }

            {
                // Denormalize from table another table
                var x = (RoleDto) this.DtoObjects.Where(p => p.Key == "Role_" + project_Person_Role.RoleId).Select(p => p.Object).SingleOrDefault();
                retObj.Role = DenormalizeRole(x);
            }

            return retObj;
        }

        // Normalizer - Load.cs
        public RoleDto LoadRole(Role role)
        {
            // Normalizer - Load - Header.cs
            if (role == null)
                return null;
            var myKey = "Role_" + role.RoleId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            RoleDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return that object
                return (RoleDto)obj.Object;
            }
            else
            {
                retObj = new RoleDto();
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = retObj
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Load - Child tables.cs

            retObj.Project_Person_Roles = new List<Project_Person_RoleDto>();
            if (role?.Project_Person_Roles != null)
                foreach (var x in role.Project_Person_Roles)
                {
                    retObj.Project_Person_Roles.Add(LoadProject_Person_Role(x));
                }

            // Normalizer - Load - Id field.cs

            retObj.RoleId = role.RoleId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.RoleName = role.RoleName;

            return retObj;
        }

        // Normalizer - Normalize.cs
        public void NormalizeRole(RoleDto role)
        {
            // Normalizer - Normalize - Header.cs
            if (role == null)
                return;
            var myKey = "Role_" + role.RoleId;
            var isAlreadyNormalized = false;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return. But no... don't do that!
                return;
                //isAlreadyNormalized = true;
            }
            else
            {
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = role
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Normalize - Child tables.cs

            if (!isAlreadyNormalized && role?.Project_Person_Roles != null)
                foreach (var x in role.Project_Person_Roles)
                {
                    NormalizeProject_Person_Role(x);
                }

            // Normalizer - Normalize - Ref fields.cs

        }

        // Normalizer - Denormalize.cs
        public RoleDto DenormalizeRole(RoleDto role)
        {
            // Normalizer - Denormalize - Header.cs
            if (role == null)
                return null;
            var myKey = "Role_" + role.RoleId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            RoleDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null && obj.Object != null && obj.IsDenormalized)
            {
                // If already denormalized, just return that object
                return (RoleDto)obj.Object;
            }
            else
            {
                if (obj == null)
                {
                    return null; // Wasn't loaded before normalization
                }
                retObj = (RoleDto)obj.Object;
                obj.IsDenormalized = true;
            }

            // Normalizer - Denormalize - Child tables.cs

            if (role?.Project_Person_Roles != null)
                for (int i = 0; i< role?.Project_Person_Roles?.Count; i++)
                {
                    retObj.Project_Person_Roles[i] = DenormalizeProject_Person_Role(role.Project_Person_Roles[i]);
                }

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }

        // Normalizer - Load.cs
        public ViewProjectAugDto LoadViewProjectAug(ViewProjectAug viewProjectAug)
        {
            // Normalizer - Load - Header.cs
            if (viewProjectAug == null)
                return null;
            var myKey = "ViewProjectAug_" + viewProjectAug.ProjectId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            ViewProjectAugDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return that object
                return (ViewProjectAugDto)obj.Object;
            }
            else
            {
                retObj = new ViewProjectAugDto();
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = retObj
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Load - Child tables.cs

            // Normalizer - Load - Id field.cs

            retObj.ProjectId = viewProjectAug.ProjectId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.TempNum = viewProjectAug.TempNum;

            retObj.Quadruple = viewProjectAug.Quadruple;

            return retObj;
        }

        // Normalizer - Normalize.cs
        public void NormalizeViewProjectAug(ViewProjectAugDto viewProjectAug)
        {
            // Normalizer - Normalize - Header.cs
            if (viewProjectAug == null)
                return;
            var myKey = "ViewProjectAug_" + viewProjectAug.ProjectId;
            var isAlreadyNormalized = false;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return. But no... don't do that!
                return;
                //isAlreadyNormalized = true;
            }
            else
            {
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = viewProjectAug
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Normalize - Child tables.cs

            // Normalizer - Normalize - Ref fields.cs

        }

        // Normalizer - Denormalize.cs
        public ViewProjectAugDto DenormalizeViewProjectAug(ViewProjectAugDto viewProjectAug)
        {
            // Normalizer - Denormalize - Header.cs
            if (viewProjectAug == null)
                return null;
            var myKey = "ViewProjectAug_" + viewProjectAug.ProjectId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            ViewProjectAugDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null && obj.Object != null && obj.IsDenormalized)
            {
                // If already denormalized, just return that object
                return (ViewProjectAugDto)obj.Object;
            }
            else
            {
                if (obj == null)
                {
                    return null; // Wasn't loaded before normalization
                }
                retObj = (ViewProjectAugDto)obj.Object;
                obj.IsDenormalized = true;
            }

            // Normalizer - Denormalize - Child tables.cs

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }

        // Normalizer - Load.cs
        public TestTableDto LoadTestTable(TestTable testTable)
        {
            // Normalizer - Load - Header.cs
            if (testTable == null)
                return null;
            var myKey = "TestTable_" + testTable.TestTableId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            TestTableDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return that object
                return (TestTableDto)obj.Object;
            }
            else
            {
                retObj = new TestTableDto();
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = retObj
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Load - Child tables.cs

            // Normalizer - Load - Id field.cs

            retObj.TestTableId = testTable.TestTableId;

            // Normalizer - Load - Ref fields.cs

            // Normalizer - Load - Data fields.cs

            retObj.Name = testTable.Name;

            retObj.IsValue = testTable.IsValue;

            return retObj;
        }

        // Normalizer - Normalize.cs
        public void NormalizeTestTable(TestTableDto testTable)
        {
            // Normalizer - Normalize - Header.cs
            if (testTable == null)
                return;
            var myKey = "TestTable_" + testTable.TestTableId;
            var isAlreadyNormalized = false;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null)
            {
                // If already loaded, just return. But no... don't do that!
                return;
                //isAlreadyNormalized = true;
            }
            else
            {
                var nk = new NormKey
                {
                    Key = myKey,
                    Jansson = null,
                    Object = testTable
                };
                this.DtoObjects.Add(nk);
            }


            // Normalizer - Normalize - Child tables.cs

            // Normalizer - Normalize - Ref fields.cs

        }

        // Normalizer - Denormalize.cs
        public TestTableDto DenormalizeTestTable(TestTableDto testTable)
        {
            // Normalizer - Denormalize - Header.cs
            if (testTable == null)
                return null;
            var myKey = "TestTable_" + testTable.TestTableId;

            // Get the NormKey. If Json-field is present, then denormalize it. If Object is present - just return that.
            TestTableDto retObj;
            var obj = this.DtoObjects.Where(p => p.Key == myKey).SingleOrDefault();
            if (obj != null && obj.Object != null && obj.IsDenormalized)
            {
                // If already denormalized, just return that object
                return (TestTableDto)obj.Object;
            }
            else
            {
                if (obj == null)
                {
                    return null; // Wasn't loaded before normalization
                }
                retObj = (TestTableDto)obj.Object;
                obj.IsDenormalized = true;
            }

            // Normalizer - Denormalize - Child tables.cs

            // Normalizer - Denormalize - Ref fields.cs

            return retObj;
        }


    } // End normalizers

        // DtoClasses.cs

    public partial class ClientDtoExtraObject
    {
    }

    // VM - class.cs
    public class ClientDto : DtoBase
    {
        // VM - class - id.cs

        public int ClientId { get; set; }

        // VM - class - Child tables.cs

        public List<Project_ClientDto> Project_Clients { get; set; }

        // VM - class - Ref.cs

        public int PersonId { get; set; } // From table, refer to another table via ID

        public PersonDto KeyAccountManager { get; set; } // Refer to table/view

        // VM - class - Data.cs

        public string ClientName { get; set; }

        // Custom object
        public ClientDtoExtraObject ExtraObject { get; set; }
    }

    public partial class DepartmentDtoExtraObject
    {
    }

    // VM - class.cs
    public class DepartmentDto : DtoBase
    {
        // VM - class - id.cs

        public int DepartmentId { get; set; }

        // VM - class - Child tables.cs

        public List<PersonDto> Persons { get; set; }

        // VM - class - Ref.cs

        // VM - class - Data.cs

        public string DepartmentName { get; set; }

        // Custom object
        public DepartmentDtoExtraObject ExtraObject { get; set; }
    }

    public partial class GenderDtoExtraObject
    {
    }

    // VM - class.cs
    public class GenderDto : DtoBase
    {
        // VM - class - id.cs

        public int GenderId { get; set; }

        // VM - class - Child tables.cs

        public List<PersonDto> Persons { get; set; }

        // VM - class - Ref.cs

        // VM - class - Data.cs

        public string GenderDescription { get; set; }

        // Custom object
        public GenderDtoExtraObject ExtraObject { get; set; }
    }

    public partial class PersonDtoExtraObject
    {
    }

    // VM - class.cs
    public class PersonDto : DtoBase
    {
        // VM - class - id.cs

        public int PersonId { get; set; }

        // VM - class - Child tables.cs

        public List<ClientDto> Clients { get; set; }

        public List<PersonDto> Employees { get; set; }

        public List<Project_Person_RoleDto> Project_Person_Roles { get; set; }

        // VM - class - Ref.cs

        public int DepartmentId { get; set; } // From table, refer to another table via ID

        public DepartmentDto Department { get; set; } // Refer to table/view

        public int GenderId { get; set; } // From table, refer to another table via ID

        public GenderDto Gender { get; set; } // Refer to table/view

        public int? ManagerId { get; set; } // From table, refer to another table via ID

        public PersonDto Manager { get; set; } // Refer to table/view

        // VM - class - Data.cs

        public string UserName { get; set; }

        public int Salary { get; set; }

        // Custom object
        public PersonDtoExtraObject ExtraObject { get; set; }
    }

    public partial class ProjectDtoExtraObject
    {
    }

    // VM - class.cs
    public class ProjectDto : DtoBase
    {
        // VM - class - id.cs

        public int ProjectId { get; set; }

        // VM - class - Child tables.cs

        public List<Project_ClientDto> Project_Clients { get; set; }

        public List<Project_Person_RoleDto> Project_Person_Roles { get; set; }

        // VM - class - Ref.cs

        public int ProjectTypeId { get; set; } // From table, refer to another table via ID

        public ProjectTypeDto ProjectType { get; set; } // Refer to table/view

        public ViewProjectAugDto ViewProjectAug { get; set; } // Refer to Augmented View.

        // VM - class - Data.cs

        public string ProjectName { get; set; }

        public bool IsProBono { get; set; }

        public DateTime Deadline { get; set; }

        // Custom object
        public ProjectDtoExtraObject ExtraObject { get; set; }
    }

    public partial class ProjectTypeDtoExtraObject
    {
    }

    // VM - class.cs
    public class ProjectTypeDto : DtoBase
    {
        // VM - class - id.cs

        public int ProjectTypeId { get; set; }

        // VM - class - Child tables.cs

        public List<ProjectDto> Projects { get; set; }

        // VM - class - Ref.cs

        // VM - class - Data.cs

        public string ProjectTypeName { get; set; }

        // Custom object
        public ProjectTypeDtoExtraObject ExtraObject { get; set; }
    }

    public partial class Project_ClientDtoExtraObject
    {
    }

    // VM - class.cs
    public class Project_ClientDto : DtoBase
    {
        // VM - class - id.cs

        public int Project_ClientId { get; set; }

        // VM - class - Child tables.cs

        // VM - class - Ref.cs

        public int ProjectId { get; set; } // From table, refer to another table via ID

        public ProjectDto Project { get; set; } // Refer to table/view

        public int ClientId { get; set; } // From table, refer to another table via ID

        public ClientDto Client { get; set; } // Refer to table/view

        // VM - class - Data.cs

        // Custom object
        public Project_ClientDtoExtraObject ExtraObject { get; set; }
    }

    public partial class Project_Person_RoleDtoExtraObject
    {
    }

    // VM - class.cs
    public class Project_Person_RoleDto : DtoBase
    {
        // VM - class - id.cs

        public int Project_Person_RoleId { get; set; }

        // VM - class - Child tables.cs

        // VM - class - Ref.cs

        public int PersonId { get; set; } // From table, refer to another table via ID

        public PersonDto Person { get; set; } // Refer to table/view

        public int ProjectId { get; set; } // From table, refer to another table via ID

        public ProjectDto Project { get; set; } // Refer to table/view

        public int RoleId { get; set; } // From table, refer to another table via ID

        public RoleDto Role { get; set; } // Refer to table/view

        // VM - class - Data.cs

        // Custom object
        public Project_Person_RoleDtoExtraObject ExtraObject { get; set; }
    }

    public partial class RoleDtoExtraObject
    {
    }

    // VM - class.cs
    public class RoleDto : DtoBase
    {
        // VM - class - id.cs

        public int RoleId { get; set; }

        // VM - class - Child tables.cs

        public List<Project_Person_RoleDto> Project_Person_Roles { get; set; }

        // VM - class - Ref.cs

        // VM - class - Data.cs

        public string RoleName { get; set; }

        // Custom object
        public RoleDtoExtraObject ExtraObject { get; set; }
    }

    public partial class ViewProjectAugDtoExtraObject
    {
    }

    // VM - class.cs
    public class ViewProjectAugDto : DtoBase
    {
        // VM - class - id.cs

        public int ProjectId { get; set; }

        // VM - class - Child tables.cs

        // VM - class - Ref.cs

        // VM - class - Data.cs

        public int TempNum { get; set; }

        public int Quadruple { get; set; }

        // Custom object
        public ViewProjectAugDtoExtraObject ExtraObject { get; set; }
    }

    public partial class TestTableDtoExtraObject
    {
    }

    // VM - class.cs
    public class TestTableDto : DtoBase
    {
        // VM - class - id.cs

        public int TestTableId { get; set; }

        // VM - class - Child tables.cs

        // VM - class - Ref.cs

        // VM - class - Data.cs

        public string Name { get; set; }

        public bool IsValue { get; set; }

        // Custom object
        public TestTableDtoExtraObject ExtraObject { get; set; }
    }


} // End namespace
