using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace EmptyProjectCore.Models
{

    public partial class Client
    {
        public Client()
        {
            Project_Clients = new HashSet<Project_Client>();

        }

        // Primary Key (table)
        [Key]
        [Column("ClientId")]
        public int ClientId { get; set; }
        // Data fields
        public string ClientName { get; set; }
        // Parents
        public int PersonId { get; set; } // From table, ref to another table (ParentChild)
        public virtual Person KeyAccountManager { get; set; } // From table, ref to table or view (ParentChild)
        // Augmented views

        // List properties
        public virtual ICollection<Project_Client> Project_Clients { get; set; }

    }

    public partial class Department
    {
        public Department()
        {
            Persons = new HashSet<Person>();

        }

        // Primary Key (table)
        [Key]
        [Column("DepartmentId")]
        public int DepartmentId { get; set; }
        // Data fields
        public string DepartmentName { get; set; }
        // Parents
        // Augmented views

        // List properties
        public virtual ICollection<Person> Persons { get; set; }

    }

    public partial class Gender
    {
        public Gender()
        {
            Persons = new HashSet<Person>();

        }

        // Primary Key (table)
        [Key]
        [Column("GenderId")]
        public int GenderId { get; set; }
        // Data fields
        public string GenderDescription { get; set; }
        // Parents
        // Augmented views

        // List properties
        public virtual ICollection<Person> Persons { get; set; }

    }

    public partial class Person
    {
        public Person()
        {
            Clients = new HashSet<Client>();
            Employees = new HashSet<Person>();
            Project_Person_Roles = new HashSet<Project_Person_Role>();

        }

        // Primary Key (table)
        [Key]
        [Column("PersonId")]
        public int PersonId { get; set; }
        // Data fields
        public string UserName { get; set; }
        public int Salary { get; set; }
        // Parents
        public int DepartmentId { get; set; } // From table, ref to another table (ParentChild)
        public virtual Department Department { get; set; } // From table, ref to table or view (ParentChild)
        public int GenderId { get; set; } // From table, ref to another table (ParentChild)
        public virtual Gender Gender { get; set; } // From table, ref to table or view (ParentChild)
        public int? ManagerId { get; set; } // From table, ref to another table (ParentChild)
        public virtual Person Manager { get; set; } // From table, ref to table or view (ParentChild)
        // Augmented views

        // List properties
        public virtual ICollection<Client> Clients { get; set; }
        public virtual ICollection<Person> Employees { get; set; }
        public virtual ICollection<Project_Person_Role> Project_Person_Roles { get; set; }

    }

    public partial class Project
    {
        public Project()
        {
            Project_Clients = new HashSet<Project_Client>();
            Project_Person_Roles = new HashSet<Project_Person_Role>();

        }

        // Primary Key (table)
        [Key]
        [Column("ProjectId")]
        public int ProjectId { get; set; }
        // Data fields
        public string ProjectName { get; set; }
        public bool IsProBono { get; set; }
        public DateTime Deadline { get; set; }
        // Parents
        public int ProjectTypeId { get; set; } // From table, ref to another table (ParentChild)
        public virtual ProjectType ProjectType { get; set; } // From table, ref to table or view (ParentChild)
        // Augmented views
        public virtual ViewProjectAug ViewProjectAug { get; set; }

        // List properties
        public virtual ICollection<Project_Client> Project_Clients { get; set; }
        public virtual ICollection<Project_Person_Role> Project_Person_Roles { get; set; }

    }

    public partial class ProjectType
    {
        public ProjectType()
        {
            Projects = new HashSet<Project>();

        }

        // Primary Key (table)
        [Key]
        [Column("ProjectTypeId")]
        public int ProjectTypeId { get; set; }
        // Data fields
        public string ProjectTypeName { get; set; }
        // Parents
        // Augmented views

        // List properties
        public virtual ICollection<Project> Projects { get; set; }

    }

    public partial class Project_Client
    {
        public Project_Client()
        {

        }

        // Primary Key (table)
        [Key]
        [Column("Project_ClientId")]
        public int Project_ClientId { get; set; }
        // Data fields
        // Parents
        public int ProjectId { get; set; } // From table, ref to another table (ParentChild)
        public virtual Project Project { get; set; } // From table, ref to table or view (ParentChild)
        public int ClientId { get; set; } // From table, ref to another table (ParentChild)
        public virtual Client Client { get; set; } // From table, ref to table or view (ParentChild)
        // Augmented views

        // List properties

    }

    public partial class Project_Person_Role
    {
        public Project_Person_Role()
        {

        }

        // Primary Key (table)
        [Key]
        [Column("Project_Person_RoleId")]
        public long Project_Person_RoleId { get; set; }
        // Data fields
        // Parents
        public int PersonId { get; set; } // From table, ref to another table (ParentChild)
        public virtual Person Person { get; set; } // From table, ref to table or view (ParentChild)
        public int ProjectId { get; set; } // From table, ref to another table (ParentChild)
        public virtual Project Project { get; set; } // From table, ref to table or view (ParentChild)
        public long RoleId { get; set; } // From table, ref to another table (ParentChild)
        public virtual Role Role { get; set; } // From table, ref to table or view (ParentChild)
        // Augmented views

        // List properties

    }

    public partial class Role
    {
        public Role()
        {
            Project_Person_Roles = new HashSet<Project_Person_Role>();

        }

        // Primary Key (table)
        [Key]
        [Column("RoleId")]
        public long RoleId { get; set; }
        // Data fields
        public string RoleName { get; set; }
        // Parents
        // Augmented views

        // List properties
        public virtual ICollection<Project_Person_Role> Project_Person_Roles { get; set; }

    }

    public partial class ViewProjectAug
    {
        public ViewProjectAug()
        {

        }

        // Primary Key (augmented view)
        [Key]
        [Column("ProjectId")]
        [ForeignKey("Project")]
        public int ProjectId { get; set; }
        // Data fields
        public int TempNum { get; set; }
        public int Quadruple { get; set; }
        // Parents
        public virtual Project Project { get; set; } // From augmented view - back to its parent

        // List properties

    }

}
