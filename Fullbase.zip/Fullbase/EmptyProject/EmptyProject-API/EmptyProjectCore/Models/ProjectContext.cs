
using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace EmptyProjectCore.Models
{
    public partial class ProjectContext : DbContext
    {
        public ProjectContext()
        {
        }

        public ProjectContext(DbContextOptions<ProjectContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Client> Client { get; set; }
        public virtual DbSet<Department> Department { get; set; }
        public virtual DbSet<Gender> Gender { get; set; }
        public virtual DbSet<Person> Person { get; set; }
        public virtual DbSet<Project> Project { get; set; }
        public virtual DbSet<ProjectType> ProjectType { get; set; }
        public virtual DbSet<Project_Client> Project_Client { get; set; }
        public virtual DbSet<Project_Person_Role> Project_Person_Role { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<ViewProjectAug> ViewProjectAug { get; set; }
        public virtual DbSet<Parameter> Parameter { get; set; }
        public virtual DbSet<ParameterAccessType> ParameterAccessType { get; set; }
        public virtual DbSet<TestTable> TestTable { get; set; }


        public static string QueryString { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(QueryString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Client>(entity =>
            {
                entity.Property(e => e.ClientName);

                // EntityFrameworkContext: - Client/Client, other: Person/Person - normal parent child - I'm a table
                entity.Property(e => e.PersonId).HasColumnName("PersonId");
                entity.HasOne(d => d.KeyAccountManager)
                    .WithMany(p => p.Clients)
                    .HasForeignKey(d => d.PersonId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PersonId_Person");

            });


            modelBuilder.Entity<Department>(entity =>
            {
                entity.Property(e => e.DepartmentName);

            });


            modelBuilder.Entity<Gender>(entity =>
            {
                entity.Property(e => e.GenderDescription);

            });


            modelBuilder.Entity<Person>(entity =>
            {
                entity.Property(e => e.UserName);
                entity.Property(e => e.Salary);

                // EntityFrameworkContext: - Person/Person, other: Department/Department - normal parent child - I'm a table
                entity.Property(e => e.DepartmentId).HasColumnName("DepartmentId");
                entity.HasOne(d => d.Department)
                    .WithMany(p => p.Persons)
                    .HasForeignKey(d => d.DepartmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DepartmentId_Department");

                // EntityFrameworkContext: - Person/Person, other: Gender/Gender - normal parent child - I'm a table
                entity.Property(e => e.GenderId).HasColumnName("GenderId");
                entity.HasOne(d => d.Gender)
                    .WithMany(p => p.Persons)
                    .HasForeignKey(d => d.GenderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GenderId_Gender");

                // EntityFrameworkContext: - Person/Person, other: Person/Person - normal parent child - I'm a table
                entity.Property(e => e.ManagerId).HasColumnName("ManagerId");
                entity.HasOne(d => d.Manager)
                    .WithMany(p => p.Employees)
                    .HasForeignKey(d => d.ManagerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ManagerId_Person");

            });


            modelBuilder.Entity<Project>(entity =>
            {
                entity.Property(e => e.ProjectName);
                entity.Property(e => e.IsProBono);
                entity.Property(e => e.Deadline);

                // EntityFrameworkContext: - Project/Project, other: ProjectType/ProjectType - normal parent child - I'm a table
                entity.Property(e => e.ProjectTypeId).HasColumnName("ProjectTypeId");
                entity.HasOne(d => d.ProjectType)
                    .WithMany(p => p.Projects)
                    .HasForeignKey(d => d.ProjectTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProjectTypeId_ProjectType");

            });


            modelBuilder.Entity<ProjectType>(entity =>
            {
                entity.Property(e => e.ProjectTypeName);

            });


            modelBuilder.Entity<Project_Client>(entity =>
            {

                // EntityFrameworkContext: - Project_Client/Project_Client, other: Project/Project - normal parent child - I'm a table
                entity.Property(e => e.ProjectId).HasColumnName("ProjectId");
                entity.HasOne(d => d.Project)
                    .WithMany(p => p.Project_Clients)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProjectId_Project");

                // EntityFrameworkContext: - Project_Client/Project_Client, other: Client/Client - normal parent child - I'm a table
                entity.Property(e => e.ClientId).HasColumnName("ClientId");
                entity.HasOne(d => d.Client)
                    .WithMany(p => p.Project_Clients)
                    .HasForeignKey(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ClientId_Client");

            });


            modelBuilder.Entity<Project_Person_Role>(entity =>
            {

                // EntityFrameworkContext: - Project_Person_Role/Project_Person_Role, other: Person/Person - normal parent child - I'm a table
                entity.Property(e => e.PersonId).HasColumnName("PersonId");
                entity.HasOne(d => d.Person)
                    .WithMany(p => p.Project_Person_Roles)
                    .HasForeignKey(d => d.PersonId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PersonId_Person");

                // EntityFrameworkContext: - Project_Person_Role/Project_Person_Role, other: Project/Project - normal parent child - I'm a table
                entity.Property(e => e.ProjectId).HasColumnName("ProjectId");
                entity.HasOne(d => d.Project)
                    .WithMany(p => p.Project_Person_Roles)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProjectId_Project");

                // EntityFrameworkContext: - Project_Person_Role/Project_Person_Role, other: Role/Role - normal parent child - I'm a table
                entity.Property(e => e.RoleId).HasColumnName("RoleId");
                entity.HasOne(d => d.Role)
                    .WithMany(p => p.Project_Person_Roles)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RoleId_Role");

            });


            modelBuilder.Entity<Role>(entity =>
            {
                entity.Property(e => e.RoleName);

            });


            modelBuilder.Entity<ViewProjectAug>(entity =>
            {
                entity.HasKey(p => p.ProjectId);
                entity.Property(e => e.TempNum);
                entity.Property(e => e.Quadruple);

            });


            modelBuilder.Entity<Parameter>(entity =>
            {
                entity.Property(e => e.Doid);
                entity.Property(e => e.Description);

                // EntityFrameworkContext: - Parameter/Parameter, other: ParameterAccessType/ParameterAccessType - normal parent child - I'm a table
                entity.Property(e => e.ParameterAccessTypeID).HasColumnName("ParameterAccessTypeID");
                entity.HasOne(d => d.ParameterAccessType)
                    .WithMany(p => p.Parameters)
                    .HasForeignKey(d => d.ParameterAccessTypeID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ParameterAccessTypeID_ParameterAccessType");

            });


            modelBuilder.Entity<ParameterAccessType>(entity =>
            {
                entity.Property(e => e.Name);

            });


            modelBuilder.Entity<TestTable>(entity =>
            {
                entity.Property(e => e.Name);
                entity.Property(e => e.IsValue);

            });



            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
