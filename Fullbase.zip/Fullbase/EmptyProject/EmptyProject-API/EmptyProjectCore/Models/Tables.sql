create table [Department]
(
    [DepartmentId] int not null primary key identity(1,1),
    [DepartmentName] varchar(100)
)

create table [Gender]
(
    [GenderId] int not null primary key identity(1,1),
    [GenderDescription] varchar(100)
)

create table [ProjectType]
(
    [ProjectTypeId] int not null primary key identity(1,1),
    [ProjectTypeName] varchar(100)
)

create table [Role]
(
    [RoleId] int not null primary key identity(1,1),
    [RoleName] varchar(100)
)

create table [TestTable]
(
    [TestTableId] int not null primary key identity(1,1),
    [Name] varchar(100),
    [IsValue] bit
)

create table [Client]
(
    [ClientId] int not null primary key identity(1,1),
    [ClientName] varchar(100),
    [PersonId] int, foreign key ([PersonId]) references [Person] ([PersonId])
)

create table [Project]
(
    [ProjectId] int not null primary key identity(1,1),
    [ProjectName] varchar(100),
    [IsProBono] bit,
    [Deadline] datetime,
    [ProjectTypeId] int, foreign key ([ProjectTypeId]) references [ProjectType] ([ProjectTypeId])
)

create table [Project_Client]
(
    [Project_ClientId] int not null primary key identity(1,1),
    [ProjectId] int, foreign key ([ProjectId]) references [Project] ([ProjectId]),
    [ClientId] int, foreign key ([ClientId]) references [Client] ([ClientId])
)

create table [Person]
(
    [PersonId] int not null primary key identity(1,1),
    [UserName] varchar(100),
    [Salary] int,
    [DepartmentId] int, foreign key ([DepartmentId]) references [Department] ([DepartmentId]),
    [GenderId] int, foreign key ([GenderId]) references [Gender] ([GenderId]),
    [ManagerId] int, foreign key ([ManagerId]) references [Person] ([PersonId])
)

create table [Project_Person_Role]
(
    [Project_Person_RoleId] int not null primary key identity(1,1),
    [PersonId] int, foreign key ([PersonId]) references [Person] ([PersonId]),
    [ProjectId] int, foreign key ([ProjectId]) references [Project] ([ProjectId]),
    [RoleId] int, foreign key ([RoleId]) references [Role] ([RoleId])
)

create view [ViewProjectAug] as
select
    ProjectId,
    ProjectId * 2 as TempNum,
    ProjectId * 4 as Quadruple
from
    Project
