﻿//using EmptyProjectCore.Models;
//using EmptyProjectCore.Utils;
//using System;
//using System.Collections.Generic;
//using System.Text;

//namespace EmptyProjectCore.Models
//{ 
//    public partial class ProjectVmExtraObject
//    {
//        public string Ttt { get; set; }
//        public bool Yooo { get; set; }
//    }
//}

//namespace EmptyProjectCore.Api.Project
//{
//    public partial class ProjectDetailsResponseExtraObject
//    {
//        public string Ttt { get; set; }
//        public bool Yooo { get; set; }
//    }

//    public partial class ProjectApi
//    {
//        partial void AfterGetDetails(ProjectDetailsResponse response)
//        {
//            response.ExtraObject = new ProjectDetailsResponseExtraObject { Ttt = "Tjena på responsen", Yooo = true };
//            response.Project.ExtraObject = new ProjectVmExtraObject { Ttt = "Tjena på projektet", Yooo = true };
//        }

//        partial void BeforeSave(ProjectDetailsResponse taintedResponse)
//        {
//            var a = taintedResponse.Project.ExtraObject;
//            var aa = taintedResponse.ExtraObject;
//            taintedResponse.Project.ProjectName += "#";
//        }
//    }
//}
