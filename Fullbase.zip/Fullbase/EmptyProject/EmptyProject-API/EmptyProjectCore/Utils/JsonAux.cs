﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmptyProjectCore.Utils
{
    public class JsonAux
    {
        public static string Serialize<T>(T obj)
        {
            return Serialize(obj, false);
        }

        public static string Serialize<T>(T obj, bool isCamelCase)
        {
            //var serializer = new JsonSerializer();
            JsonSerializer serializer;
            if (isCamelCase)
            {
                serializer = JsonSerializer.Create(new JsonSerializerSettings
                {
                    ContractResolver = new CamelCasePropertyNamesContractResolver(),
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                });
            }
            else
            {
                serializer = new JsonSerializer();
            }

            using (var ms = new MemoryStream())
            using (var sr = new StreamWriter(ms))
            using (var jsonTextWriter = new JsonTextWriter(sr))
            {
                serializer.Serialize(jsonTextWriter, obj);
                jsonTextWriter.Flush();
                ms.Seek(0, SeekOrigin.Begin);
                var streamReader = new StreamReader(ms);

                var xx = streamReader.ReadToEnd();
                return xx;
            }
        }

        public static void SerializeToFile<T>(T obj, string path)
        {
            var serializer = new JsonSerializer();
            using (var sr = new StreamWriter(path))
            using (var jsonTextWriter = new JsonTextWriter(sr))
            {
                serializer.Serialize(jsonTextWriter, obj);
            }
        }

        //public static byte[] SerializeAndCompress<T>(T obj)
        //{
        //    var serializer = new JsonSerializer();
        //    using (var ms = new MemoryStream())
        //    using (var sr = new StreamWriter(ms))
        //    using (var jsonTextWriter = new JsonTextWriter(sr))
        //    {
        //        serializer.Serialize(jsonTextWriter, obj);
        //        jsonTextWriter.Flush();
        //        ms.Seek(0, SeekOrigin.Begin);
        //        var streamReader = new StreamReader(ms);

        //        var xx = streamReader.ReadToEnd();

        //        var barr = Compress(Encoding.UTF8.GetBytes(xx));

        //        return barr;
        //    }
        //}

        // TODO: Kom på lämplig krypteringsfunktionalitet
        //public static byte[] SerializeAndCompressAndEncrypt<T>(T obj)
        //{
        //    var serializer = new JsonSerializer();
        //    using (var ms = new MemoryStream())
        //    using (var sr = new StreamWriter(ms))
        //    using (var jsonTextWriter = new JsonTextWriter(sr))
        //    {
        //        serializer.Serialize(jsonTextWriter, obj);
        //        jsonTextWriter.Flush();
        //        ms.Seek(0, SeekOrigin.Begin);
        //        var streamReader = new StreamReader(ms);

        //        var xx = streamReader.ReadToEnd();

        //        var barr = Compress(Encoding.UTF8.GetBytes(xx));

        //        // TODO: Lämpligare kryptering än att plussa på varje byte med 1
        //        for (int i = 0; i < barr.Length; i++)
        //        {
        //            barr[i]++;
        //        }

        //        return barr;
        //    }
        //}


        public static T Deserialize<T>(string json, bool isCamelCase)
        {
            JsonSerializer serializer;
            if (isCamelCase)
            {
                serializer = JsonSerializer.Create(new JsonSerializerSettings
                {
                    ContractResolver = new CamelCasePropertyNamesContractResolver()
                });
            }
            else
            {
                serializer = new JsonSerializer();
            }
            using (var sr = new StringReader(json))
            using (var jsonTextReader = new JsonTextReader(sr))
            {
                return serializer.Deserialize<T>(jsonTextReader);
            }
        }

        public static T DeserializeFromFile<T>(string path)
        {
            var serializer = new JsonSerializer();
            using (var sr = new StreamReader(path))
            using (var jsonTextReader = new JsonTextReader(sr))
            {
                return serializer.Deserialize<T>(jsonTextReader);
            }
        }

        //public static T DecompressAndDeserialize<T>(byte[] barr)
        //{
        //    var ms = Decompress(barr);

        //    var streamReader = new BinaryReader(ms);
        //    var decompressedBytes = streamReader.ReadBytes(10000000);
        //    var mswDataJson = Encoding.UTF8.GetString(decompressedBytes);

        //    var serializer = new JsonSerializer();
        //    var dummyStream = new MemoryStream();
        //    var writerDummy = new StreamWriter(dummyStream);
        //    writerDummy.Write(mswDataJson);
        //    writerDummy.Flush();
        //    dummyStream.Position = 0;

        //    using (var sr = new StreamReader(dummyStream))
        //    using (var jsonTextReader = new JsonTextReader(sr))
        //    {
        //        return serializer.Deserialize<T>(jsonTextReader);
        //    }
        //}

        //public static T DecryptAndDecompressAndDeserialize<T>(byte[] barr)
        //{
        //    //TODO: Bättre dekryptering än att plussa på varje byte med 1
        //    for (int i = 0; i < barr.Length; i++)
        //    {
        //        barr[i]--;
        //    }

        //    var ms = Decompress(barr);

        //    var streamReader = new BinaryReader(ms);
        //    var decompressedBytes = streamReader.ReadBytes(10000000);

        //    var mswDataJson = Encoding.UTF8.GetString(decompressedBytes);

        //    var serializer = new JsonSerializer();
        //    var dummyStream = new MemoryStream();
        //    var writerDummy = new StreamWriter(dummyStream);
        //    writerDummy.Write(mswDataJson);
        //    writerDummy.Flush();
        //    dummyStream.Position = 0;

        //    using (var sr = new StreamReader(dummyStream))
        //    using (var jsonTextReader = new JsonTextReader(sr))
        //    {
        //        return serializer.Deserialize<T>(jsonTextReader);
        //    }
        //}


        //private static Stream Decompress(byte[] data)
        //{
        //    var memStream = new MemoryStream(data);
        //    using (var zip = ZipFile.Read(memStream))
        //    {
        //        ICollection<ZipEntry> entries = zip.Entries;
        //        zip.ParallelDeflateThreshold = -1;
        //        return entries.Single().OpenReader(); //.Extract(inStream);
        //    }
        //}

        //private static byte[] Compress(byte[] data)
        //{
        //    var compressed = new MemoryStream();

        //    using (var zip = new ZipFile())
        //    {
        //        zip.CompressionLevel = CompressionLevel.Default;
        //        zip.ParallelDeflateThreshold = -1;
        //        zip.AddEntry("x", data);
        //        zip.Save(compressed);
        //    }

        //    return compressed.ToArray();
        //}

    }
}
