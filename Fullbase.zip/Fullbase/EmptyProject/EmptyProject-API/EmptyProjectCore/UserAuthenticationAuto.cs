namespace EmptyProjectCore
{
    public class UserAuthenticationAuto
    {
       public bool isDefault { get; set;}
       public bool isAdmin { get; set;}
       public bool isGuest { get; set;}

    }
}