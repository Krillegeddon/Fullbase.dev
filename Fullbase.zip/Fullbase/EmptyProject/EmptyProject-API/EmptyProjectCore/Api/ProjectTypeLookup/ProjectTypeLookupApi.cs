
using EmptyProjectCore.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace EmptyProjectCore.Api.ProjectTypeLookup
{

    public partial class ProjectTypeLookupFilterRequestExtraObject
    {
    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    public partial class ProjectTypeLookupFilterRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public ProjectTypeLookupFilterRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class ProjectTypeLookupFilterResponseExtraObject
    {
    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    public partial class ProjectTypeLookupFilterResponse : TransferBase
    {
        // Properties to be transfered

        public ProjectTypeLookupFilterRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ProjectTypeLookupFilterResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Request.Denormalize(Normalizer);

        }


    }

    public partial class ProjectTypeLookupSearchRequestExtraObject
    {
    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    public partial class ProjectTypeLookupSearchRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public ProjectTypeLookupSearchRequestExtraObject ExtraObject { get; set; }

        public string QuickSearch { get; set; }

        public NumberClause<int> ProjectTypeId { get; set; }

        public StringClause ProjectTypeName { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class ProjectTypeLookupSearchResponseExtraObject
    {
    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    public partial class ProjectTypeLookupSearchResponse : TransferBase
    {
        // Properties to be transfered

        public List<ProjectTypeDto> ProjectTypes { get; set; }

        public ProjectTypeLookupSearchRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ProjectTypeLookupSearchResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0; i < ProjectTypes?.Count; i++)
            {
                var x = ProjectTypes[i];
                var projectTypeKey = "ProjectType_" + x.ProjectTypeId;
                var possibleProjectType = normalizer.DtoObjects.Where(p => p.Key == projectTypeKey).SingleOrDefault();
                if (possibleProjectType != null)
                    ProjectTypes[i] = (ProjectTypeDto) possibleProjectType.Object;
                else
                    Normalizer.NormalizeProjectType(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < ProjectTypes?.Count; i++)
            {
                this.ProjectTypes[i] = Normalizer.DenormalizeProjectType(ProjectTypes[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class ProjectTypeLookupDetailsRequestExtraObject
    {
    }

    /// <summary>
    /// Detail request, basically one item from the AugView ProjectType, that user clicked after search was performed.
    /// </summary>
    public partial class ProjectTypeLookupDetailsRequest : TransferBase
    {
        // Properties to be transfered

        public ProjectTypeDto ProjectType { get; set; }


        // Custom properties, not to be transfered
        public ProjectTypeLookupDetailsRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var projectTypeKey = "ProjectType_" + ProjectType.ProjectTypeId;
                var possibleProjectType = normalizer.DtoObjects.Where(p => p.Key == projectTypeKey).SingleOrDefault();
                if (possibleProjectType != null)
                    ProjectType = (ProjectTypeDto)possibleProjectType.Object;
                else
                    Normalizer.NormalizeProjectType(ProjectType);
            }

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            ProjectType = Normalizer.DenormalizeProjectType(ProjectType);

        }


    }

    public partial class ProjectTypeLookupDetailsResponseExtraObject
    {
    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    public partial class ProjectTypeLookupDetailsResponse : TransferBase
    {
        // Properties to be transfered

        public ProjectTypeDto ProjectType { get; set; }

        public ProjectTypeLookupDetailsRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ProjectTypeLookupDetailsResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var projectTypeKey = "ProjectType_" + ProjectType.ProjectTypeId;
                var possibleProjectType = normalizer.DtoObjects.Where(p => p.Key == projectTypeKey).SingleOrDefault();
                if (possibleProjectType != null)
                    ProjectType = (ProjectTypeDto)possibleProjectType.Object;
                else
                    Normalizer.NormalizeProjectType(ProjectType);
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            ProjectType = Normalizer.DenormalizeProjectType(ProjectType);

            Request.Denormalize(Normalizer);

        }


    }

    /// <summary>
    /// Details response - internal DB representation of Details.
    /// </summary>
    public class ProjectTypeLookupDetailsResponseDb
    {
        // Properties in db class

        public Models.ProjectType ProjectType { get; set; }


        // Custom properties, not to be transfered

    }

}
