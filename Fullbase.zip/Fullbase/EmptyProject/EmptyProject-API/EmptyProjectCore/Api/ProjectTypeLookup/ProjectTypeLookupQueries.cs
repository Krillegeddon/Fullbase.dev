
using EmptyProjectCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmptyProjectCore.Api.ProjectTypeLookup
{
    public class ProjectTypeLookupQueries
    {
        private ProjectContext _ctx { get; }

        public ProjectTypeLookupQueries(ProjectContext ctx)
        {
            _ctx = ctx;
        }



            /// <summary>
            /// Based on search criteria, returns the search results.
            /// </summary>
            /// <param name="request"></param>
            /// <returns></returns>
            public ProjectTypeLookupSearchResponse GetSearch(ProjectTypeLookupSearchRequest request)
            {
                var retObj = new ProjectTypeLookupSearchResponse();
                retObj.Normalizer = new Normalizer();
                retObj.Normalizer.DtoObjects = new List<NormKey>();
            var qProjectType0 = _ctx.ProjectType
                  // Tree for  (Parent)
                .AsQueryable();

                if (!string.IsNullOrEmpty(request.QuickSearch))
                {
                    {
                        qProjectType0 = qProjectType0.Where( p =>
                        p.ProjectTypeName.ToLower().Contains(request.QuickSearch.ToLower())
                        );
                    }
                }

                        if (request.ProjectTypeId.ExactMatch.HasValue)
                        {
                            qProjectType0 = qProjectType0.Where(p =>
                                       p.ProjectTypeId == request.ProjectTypeId.ExactMatch.Value  // Foreign key search
                            );
                        }

                        if (!string.IsNullOrEmpty(request.ProjectTypeName.ExactMatch)) // One field, string
                        {
                            qProjectType0 = qProjectType0.Where(p =>
                                       p.ProjectTypeName == request.ProjectTypeName.ExactMatch
                            );
                        }

            retObj.ProjectTypes = qProjectType0.Select(p => retObj.Normalizer.LoadProjectType(p)).ToList();



            return retObj;
            }


        /// <summary>
        /// Based on selected item from search, gets the detail information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ProjectTypeLookupDetailsResponse GetDetails(ProjectTypeLookupDetailsRequest request)
        {
            
            var retObj = new ProjectTypeLookupDetailsResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

if (request.ProjectType.ProjectTypeId > 0) {
            var qProjectType0 = _ctx.ProjectType.Where(x => x.ProjectTypeId == request.ProjectType.ProjectTypeId)
                  // Tree for  (Parent)
                  .FirstOrDefault();

            retObj.ProjectType = retObj.Normalizer.LoadProjectType(qProjectType0);


            }
            else
            {
                retObj.ProjectType = new ProjectTypeDto
                {
                    ProjectTypeId = -1
                };
            }

            return retObj;
        }

        private ProjectTypeLookupDetailsResponseDb GetDetailsDb(ProjectTypeLookupDetailsRequest request)
        {
            
            var retObj = new ProjectTypeLookupDetailsResponseDb();

            var qProjectType0 = _ctx.ProjectType.Where(x => x.ProjectTypeId == request.ProjectType.ProjectTypeId)
                  // Tree for  (Parent)
                  .FirstOrDefault();

            retObj.ProjectType = qProjectType0;



            return retObj;
        }


        public void SaveDetails(ProjectTypeLookupDetailsResponse taintedResponse)
        {
            restart:
            var projectType0Db = GetDetailsDb(taintedResponse.Request).ProjectType; // Get the same thing as request
            var projectType0 = taintedResponse.ProjectType;


            if (projectType0Db == null)
            {
                // No row in db = insert!
                var d = new EmptyProjectCore.Models.ProjectType();
                d.ProjectTypeName = projectType0.ProjectTypeName;

                _ctx.ProjectType.Add(d);
                _ctx.SaveChanges();
                projectType0.ProjectTypeId = d.ProjectTypeId;
                goto restart;
            }




            if (projectType0 != null && projectType0.IsDeleted)
            {
                _ctx.ProjectType.Remove(projectType0Db);
            }
            else if (projectType0 != null && projectType0.IsTainted)
            {
                // Check if id has changed
                if (projectType0Db?.ProjectTypeId != projectType0.ProjectTypeId && projectType0Db?.ProjectTypeId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // projectType0Db?.ProjectTypeId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                projectType0Db.ProjectTypeName = projectType0.ProjectTypeName; // Data field

                if (projectType0Db.ProjectTypeId != 0)
                {
                    _ctx.Update(projectType0Db);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    projectType0.ProjectTypeId = projectType0Db.ProjectTypeId;
                }
                projectType0.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

        }

    }
}
