
using EmptyProjectCore.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace EmptyProjectCore.Api.GenderLookup
{

    public partial class GenderLookupFilterRequestExtraObject
    {
    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    public partial class GenderLookupFilterRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public GenderLookupFilterRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class GenderLookupFilterResponseExtraObject
    {
    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    public partial class GenderLookupFilterResponse : TransferBase
    {
        // Properties to be transfered

        public GenderLookupFilterRequest Request { get; set; }


        // Custom properties, not to be transfered
        public GenderLookupFilterResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Request.Denormalize(Normalizer);

        }


    }

    public partial class GenderLookupSearchRequestExtraObject
    {
    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    public partial class GenderLookupSearchRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public GenderLookupSearchRequestExtraObject ExtraObject { get; set; }

        public string QuickSearch { get; set; }

        public IntClause GenderId { get; set; }

        public StringClause GenderDescription { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class GenderLookupSearchResponseExtraObject
    {
    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    public partial class GenderLookupSearchResponse : TransferBase
    {
        // Properties to be transfered

        public List<GenderDto> Genders { get; set; }

        public GenderLookupSearchRequest Request { get; set; }


        // Custom properties, not to be transfered
        public GenderLookupSearchResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0; i < Genders?.Count; i++)
            {
                var x = Genders[i];
                var genderKey = "Gender_" + x.GenderId;
                var possibleGender = normalizer.DtoObjects.Where(p => p.Key == genderKey).SingleOrDefault();
                if (possibleGender != null)
                    Genders[i] = (GenderDto) possibleGender.Object;
                else
                    Normalizer.NormalizeGender(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < Genders?.Count; i++)
            {
                this.Genders[i] = Normalizer.DenormalizeGender(Genders[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class GenderLookupDetailsRequestExtraObject
    {
    }

    /// <summary>
    /// Detail request, basically one item from the AugView Gender, that user clicked after search was performed.
    /// </summary>
    public partial class GenderLookupDetailsRequest : TransferBase
    {
        // Properties to be transfered

        public GenderDto Gender { get; set; }


        // Custom properties, not to be transfered
        public GenderLookupDetailsRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var genderKey = "Gender_" + Gender.GenderId;
                var possibleGender = normalizer.DtoObjects.Where(p => p.Key == genderKey).SingleOrDefault();
                if (possibleGender != null)
                    Gender = (GenderDto)possibleGender.Object;
                else
                    Normalizer.NormalizeGender(Gender);
            }

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Gender = Normalizer.DenormalizeGender(Gender);

        }


    }

    public partial class GenderLookupDetailsResponseExtraObject
    {
    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    public partial class GenderLookupDetailsResponse : TransferBase
    {
        // Properties to be transfered

        public GenderDto Gender { get; set; }

        public GenderLookupDetailsRequest Request { get; set; }


        // Custom properties, not to be transfered
        public GenderLookupDetailsResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var genderKey = "Gender_" + Gender.GenderId;
                var possibleGender = normalizer.DtoObjects.Where(p => p.Key == genderKey).SingleOrDefault();
                if (possibleGender != null)
                    Gender = (GenderDto)possibleGender.Object;
                else
                    Normalizer.NormalizeGender(Gender);
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Gender = Normalizer.DenormalizeGender(Gender);

            Request.Denormalize(Normalizer);

        }


    }

    /// <summary>
    /// Details response - internal DB representation of Details.
    /// </summary>
    public class GenderLookupDetailsResponseDb
    {
        // Properties in db class

        public Models.Gender Gender { get; set; }


        // Custom properties, not to be transfered

    }

}
