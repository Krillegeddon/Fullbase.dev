
using EmptyProjectCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmptyProjectCore.Api.GenderLookup
{
    public class GenderLookupQueries
    {
        private ProjectContext _ctx { get; }

        public GenderLookupQueries(ProjectContext ctx)
        {
            _ctx = ctx;
        }



        /// <summary>
        /// Based on search criteria, returns the search results.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public GenderLookupSearchResponse GetSearch(GenderLookupSearchRequest request)
        {
            var retObj = new GenderLookupSearchResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();
            {
                var qGender0 = _ctx.Gender
                    // Tree for  (Parent)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(request.QuickSearch))
                {
                    {
                        qGender0 = qGender0.Where(p =>
                        p.GenderDescription.ToLower().Contains(request.QuickSearch.ToLower())
                        );
                    }
                }

                if (request.GenderId.ExactMatch.HasValue)
                {
                    qGender0 = qGender0.Where(p =>
                                p.GenderId == request.GenderId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.GenderDescription.ExactMatch)) // One field, string
                {
                    qGender0 = qGender0.Where(p =>
                                p.GenderDescription == request.GenderDescription.ExactMatch
                    );
                }

                if (!string.IsNullOrEmpty(request.GenderDescription.ContainsMatch)) // One field, string
                {
                    qGender0 = qGender0.Where(p =>
                                p.GenderDescription.Contains(request.GenderDescription.ContainsMatch)
                    );
                }

                if (!string.IsNullOrEmpty(request.GenderDescription.StartsWithMatch)) // One field, string
                {
                    qGender0 = qGender0.Where(p =>
                                p.GenderDescription.StartsWith(request.GenderDescription.StartsWithMatch)
                    );
                }

                //Add custom code here...
                retObj.Genders = qGender0.Select(p => retObj.Normalizer.LoadGender(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on selected item from search, gets the detail information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public GenderLookupDetailsResponse GetDetails(GenderLookupDetailsRequest request)
        {
            
            var retObj = new GenderLookupDetailsResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            if (request.Gender.GenderId > 0)
            {
                var qGender0 = _ctx.Gender.Where(x => x.GenderId == request.Gender.GenderId)
                    // Tree for  (Parent)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Gender = retObj.Normalizer.LoadGender(qGender0);
            }
            else
            {
                retObj.Gender = new GenderDto
                {
                    GenderId = -1
                };
            }


            return retObj;
        }

        private GenderLookupDetailsResponseDb GetDetailsDb(GenderLookupDetailsRequest request)
        {
            
            var retObj = new GenderLookupDetailsResponseDb();

            {
                var qGender0 = _ctx.Gender.Where(x => x.GenderId == request.Gender.GenderId)
                    // Tree for  (Parent)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Gender = qGender0;
            }


            return retObj;
        }


        public void SaveDetails(GenderLookupDetailsResponse taintedResponse)
        {
            restart:
            var gender0Db = GetDetailsDb(taintedResponse.Request).Gender; // Get the same thing as request
            var gender0 = taintedResponse.Gender;


            if (gender0Db == null)
            {
                // No row in db = insert!
                var d = new EmptyProjectCore.Models.Gender();
                d.GenderDescription = gender0.GenderDescription;

                _ctx.Gender.Add(d);
                _ctx.SaveChanges();
                gender0.GenderId = d.GenderId;
                goto restart;
            }




            if (gender0 != null && gender0.IsDeleted)
            {
                _ctx.Gender.Remove(gender0Db);
            }
            else if (gender0 != null && gender0.IsTainted)
            {
                // Check if id has changed
                if (gender0Db?.GenderId != gender0.GenderId && gender0Db?.GenderId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // gender0Db?.GenderId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                gender0Db.GenderDescription = gender0.GenderDescription; // Data field

                if (gender0Db.GenderId != 0)
                {
                    _ctx.Update(gender0Db);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    gender0.GenderId = gender0Db.GenderId;
                }
                gender0.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

        }

    }
}
