
using EmptyProjectCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmptyProjectCore.Api.PersonLookupForManager
{
    public class PersonLookupForManagerQueries
    {
        private ProjectContext _ctx { get; }

        public PersonLookupForManagerQueries(ProjectContext ctx)
        {
            _ctx = ctx;
        }



        /// <summary>
        /// Based on search criteria, returns the search results.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public PersonLookupForManagerSearchResponse GetSearch(PersonLookupForManagerSearchRequest request)
        {
            var retObj = new PersonLookupForManagerSearchResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();
            {
                var qPerson0 = _ctx.Person
                    // Tree for  (Parent)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(request.QuickSearch))
                {
                    {
                        qPerson0 = qPerson0.Where(p =>
                        p.UserName.ToLower().Contains(request.QuickSearch.ToLower())
                        );
                    }
                }

                if (request.PersonId.ExactMatch.HasValue)
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.PersonId == request.PersonId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.UserName.ExactMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.UserName == request.UserName.ExactMatch
                    );
                }

                if (request.Salary.ExactMatch.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Salary == request.Salary.ExactMatch.Value
                    );
                }

                //Add custom code here...
                qPerson0 = qPerson0.Where(p => p.Department.DepartmentName == "Department A");
                
                
                retObj.Persons = qPerson0.Select(p => retObj.Normalizer.LoadPerson(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on selected item from search, gets the detail information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public PersonLookupForManagerDetailsResponse GetDetails(PersonLookupForManagerDetailsRequest request)
        {
            
            var retObj = new PersonLookupForManagerDetailsResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            if (request.Person.PersonId > 0)
            {
                var qPerson0 = _ctx.Person.Where(x => x.PersonId == request.Person.PersonId)
                    // Tree for  (Parent)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Person = retObj.Normalizer.LoadPerson(qPerson0);
            }
            else
            {
                retObj.Person = new PersonDto
                {
                    PersonId = -1
                };
            }


            return retObj;
        }

        private PersonLookupForManagerDetailsResponseDb GetDetailsDb(PersonLookupForManagerDetailsRequest request)
        {
            
            var retObj = new PersonLookupForManagerDetailsResponseDb();

            {
                var qPerson0 = _ctx.Person.Where(x => x.PersonId == request.Person.PersonId)
                    // Tree for  (Parent)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Person = qPerson0;
            }


            return retObj;
        }


        public void SaveDetails(PersonLookupForManagerDetailsResponse taintedResponse)
        {
            restart:
            var person0Db = GetDetailsDb(taintedResponse.Request).Person; // Get the same thing as request
            var person0 = taintedResponse.Person;


            if (person0Db == null)
            {
                // No row in db = insert!
                var d = new EmptyProjectCore.Models.Person();
                d.UserName = person0.UserName;
                d.Salary = person0.Salary;
                d.DepartmentId = person0.DepartmentId;
                d.GenderId = person0.GenderId;
                d.ManagerId = person0.ManagerId;

                _ctx.Person.Add(d);
                _ctx.SaveChanges();
                person0.PersonId = d.PersonId;
                goto restart;
            }




            if (person0 != null && person0.IsDeleted)
            {
                _ctx.Person.Remove(person0Db);
            }
            else if (person0 != null && person0.IsTainted)
            {
                // Check if id has changed
                if (person0Db?.PersonId != person0.PersonId && person0Db?.PersonId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.UserName = person0.UserName; // Data field
                person0Db.Salary = person0.Salary; // Data field
                if (person0 != null && person0.Department != null)
                    person0Db.DepartmentId = person0.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                if (person0 != null && person0.Gender != null)
                    person0Db.GenderId = person0.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                person0Db.ManagerId = person0.Manager?.PersonId; // Nullable parent

                if (person0Db.PersonId != 0)
                {
                    _ctx.Update(person0Db);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.PersonId = person0Db.PersonId;
                }
                person0.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

        }

    }
}
