
using EmptyProjectCore.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace EmptyProjectCore.Api.PersonLookupForManager
{

    public partial class PersonLookupForManagerFilterRequestExtraObject
    {
    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    public partial class PersonLookupForManagerFilterRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public PersonLookupForManagerFilterRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class PersonLookupForManagerFilterResponseExtraObject
    {
    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    public partial class PersonLookupForManagerFilterResponse : TransferBase
    {
        // Properties to be transfered

        public PersonLookupForManagerFilterRequest Request { get; set; }


        // Custom properties, not to be transfered
        public PersonLookupForManagerFilterResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Request.Denormalize(Normalizer);

        }


    }

    public partial class PersonLookupForManagerSearchRequestExtraObject
    {
    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    public partial class PersonLookupForManagerSearchRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public PersonLookupForManagerSearchRequestExtraObject ExtraObject { get; set; }

        public string QuickSearch { get; set; }

        public NumberClause<int> PersonId { get; set; }

        public StringClause UserName { get; set; }

        public NumberClause<int> Salary { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class PersonLookupForManagerSearchResponseExtraObject
    {
    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    public partial class PersonLookupForManagerSearchResponse : TransferBase
    {
        // Properties to be transfered

        public List<PersonDto> Persons { get; set; }

        public PersonLookupForManagerSearchRequest Request { get; set; }


        // Custom properties, not to be transfered
        public PersonLookupForManagerSearchResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0; i < Persons?.Count; i++)
            {
                var x = Persons[i];
                var personKey = "Person_" + x.PersonId;
                var possiblePerson = normalizer.DtoObjects.Where(p => p.Key == personKey).SingleOrDefault();
                if (possiblePerson != null)
                    Persons[i] = (PersonDto) possiblePerson.Object;
                else
                    Normalizer.NormalizePerson(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < Persons?.Count; i++)
            {
                this.Persons[i] = Normalizer.DenormalizePerson(Persons[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class PersonLookupForManagerDetailsRequestExtraObject
    {
    }

    /// <summary>
    /// Detail request, basically one item from the AugView Person, that user clicked after search was performed.
    /// </summary>
    public partial class PersonLookupForManagerDetailsRequest : TransferBase
    {
        // Properties to be transfered

        public PersonDto Person { get; set; }


        // Custom properties, not to be transfered
        public PersonLookupForManagerDetailsRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var personKey = "Person_" + Person.PersonId;
                var possiblePerson = normalizer.DtoObjects.Where(p => p.Key == personKey).SingleOrDefault();
                if (possiblePerson != null)
                    Person = (PersonDto)possiblePerson.Object;
                else
                    Normalizer.NormalizePerson(Person);
            }

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Person = Normalizer.DenormalizePerson(Person);

        }


    }

    public partial class PersonLookupForManagerDetailsResponseExtraObject
    {
    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    public partial class PersonLookupForManagerDetailsResponse : TransferBase
    {
        // Properties to be transfered

        public PersonDto Person { get; set; }

        public PersonLookupForManagerDetailsRequest Request { get; set; }


        // Custom properties, not to be transfered
        public PersonLookupForManagerDetailsResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var personKey = "Person_" + Person.PersonId;
                var possiblePerson = normalizer.DtoObjects.Where(p => p.Key == personKey).SingleOrDefault();
                if (possiblePerson != null)
                    Person = (PersonDto)possiblePerson.Object;
                else
                    Normalizer.NormalizePerson(Person);
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Person = Normalizer.DenormalizePerson(Person);

            Request.Denormalize(Normalizer);

        }


    }

    /// <summary>
    /// Details response - internal DB representation of Details.
    /// </summary>
    public class PersonLookupForManagerDetailsResponseDb
    {
        // Properties in db class

        public Models.Person Person { get; set; }


        // Custom properties, not to be transfered

    }

}
