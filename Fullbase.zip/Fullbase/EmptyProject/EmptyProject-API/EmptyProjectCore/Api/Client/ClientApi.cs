
using EmptyProjectCore.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace EmptyProjectCore.Api.Client
{

    public partial class ClientFilterRequestExtraObject
    {
    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    public partial class ClientFilterRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public ClientFilterRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class ClientFilterResponseExtraObject
    {
    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    public partial class ClientFilterResponse : TransferBase
    {
        // Properties to be transfered

        public ClientFilterRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ClientFilterResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Request.Denormalize(Normalizer);

        }


    }

    public partial class ClientSearchRequestExtraObject
    {
    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    public partial class ClientSearchRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public ClientSearchRequestExtraObject ExtraObject { get; set; }

        public string QuickSearch { get; set; }

        public NumberClause<int> ClientId { get; set; }

        public StringClause ClientName { get; set; }

        public NumberClause<int> KeyAccountManager_PersonId { get; set; }

        public StringClause KeyAccountManager_UserName { get; set; }

        public NumberClause<int> KeyAccountManager_Salary { get; set; }

        public NumberClause<int> KeyAccountManager_Gender_GenderId { get; set; }

        public StringClause KeyAccountManager_Gender_GenderDescription { get; set; }

        public NumberClause<int> KeyAccountManager_Department_DepartmentId { get; set; }

        public StringClause KeyAccountManager_Department_DepartmentName { get; set; }

        public NumberClause<int> KeyAccountManager_Manager_PersonId { get; set; }

        public StringClause KeyAccountManager_Manager_UserName { get; set; }

        public NumberClause<int> KeyAccountManager_Manager_Salary { get; set; }

        public NumberClause<int> KeyAccountManager_Manager_Gender_GenderId { get; set; }

        public StringClause KeyAccountManager_Manager_Gender_GenderDescription { get; set; }

        public NumberClause<int> KeyAccountManager_Manager_Department_DepartmentId { get; set; }

        public StringClause KeyAccountManager_Manager_Department_DepartmentName { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class ClientSearchResponseExtraObject
    {
    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    public partial class ClientSearchResponse : TransferBase
    {
        // Properties to be transfered

        public List<ClientDto> Clients { get; set; }

        public ClientSearchRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ClientSearchResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0; i < Clients?.Count; i++)
            {
                var x = Clients[i];
                var clientKey = "Client_" + x.ClientId;
                var possibleClient = normalizer.DtoObjects.Where(p => p.Key == clientKey).SingleOrDefault();
                if (possibleClient != null)
                    Clients[i] = (ClientDto) possibleClient.Object;
                else
                    Normalizer.NormalizeClient(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < Clients?.Count; i++)
            {
                this.Clients[i] = Normalizer.DenormalizeClient(Clients[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class ClientDetailsRequestExtraObject
    {
    }

    /// <summary>
    /// Detail request, basically one item from the AugView Client, that user clicked after search was performed.
    /// </summary>
    public partial class ClientDetailsRequest : TransferBase
    {
        // Properties to be transfered

        public ClientDto Client { get; set; }


        // Custom properties, not to be transfered
        public ClientDetailsRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var clientKey = "Client_" + Client.ClientId;
                var possibleClient = normalizer.DtoObjects.Where(p => p.Key == clientKey).SingleOrDefault();
                if (possibleClient != null)
                    Client = (ClientDto)possibleClient.Object;
                else
                    Normalizer.NormalizeClient(Client);
            }

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Client = Normalizer.DenormalizeClient(Client);

        }


    }

    public partial class ClientDetailsResponseExtraObject
    {
    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    public partial class ClientDetailsResponse : TransferBase
    {
        // Properties to be transfered

        public ClientDto Client { get; set; }

        public ClientDetailsRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ClientDetailsResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var clientKey = "Client_" + Client.ClientId;
                var possibleClient = normalizer.DtoObjects.Where(p => p.Key == clientKey).SingleOrDefault();
                if (possibleClient != null)
                    Client = (ClientDto)possibleClient.Object;
                else
                    Normalizer.NormalizeClient(Client);
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Client = Normalizer.DenormalizeClient(Client);

            Request.Denormalize(Normalizer);

        }


    }

    /// <summary>
    /// Details response - internal DB representation of Details.
    /// </summary>
    public class ClientDetailsResponseDb
    {
        // Properties in db class

        public Models.Client Client { get; set; }


        // Custom properties, not to be transfered

    }

}
