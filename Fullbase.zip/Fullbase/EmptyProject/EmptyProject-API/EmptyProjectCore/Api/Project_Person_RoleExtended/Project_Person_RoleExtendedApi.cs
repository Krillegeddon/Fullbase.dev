
using EmptyProjectCore.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace EmptyProjectCore.Api.Project_Person_RoleExtended
{

    public partial class Project_Person_RoleExtendedFilterRequestExtraObject
    {
    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    public partial class Project_Person_RoleExtendedFilterRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public Project_Person_RoleExtendedFilterRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class Project_Person_RoleExtendedFilterResponseExtraObject
    {
    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    public partial class Project_Person_RoleExtendedFilterResponse : TransferBase
    {
        // Properties to be transfered

        public Project_Person_RoleExtendedFilterRequest Request { get; set; }


        // Custom properties, not to be transfered
        public Project_Person_RoleExtendedFilterResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Request.Denormalize(Normalizer);

        }


    }

    public partial class Project_Person_RoleExtendedSearchRequestExtraObject
    {
    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    public partial class Project_Person_RoleExtendedSearchRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public Project_Person_RoleExtendedSearchRequestExtraObject ExtraObject { get; set; }

        public string QuickSearch { get; set; }

        public IntClause Project_Person_RoleId { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class Project_Person_RoleExtendedSearchResponseExtraObject
    {
    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    public partial class Project_Person_RoleExtendedSearchResponse : TransferBase
    {
        // Properties to be transfered

        public List<Project_Person_RoleDto> Project_Person_Roles { get; set; }

        public Project_Person_RoleExtendedSearchRequest Request { get; set; }


        // Custom properties, not to be transfered
        public Project_Person_RoleExtendedSearchResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0 ; i < Project_Person_Roles?.Count ; i++)
            {
                var x = Project_Person_Roles[i];
                var project_Person_RoleKey = "Project_Person_Role_" + x.Project_Person_RoleId;
                var possibleProject_Person_Role = normalizer.DtoObjects.Where(p => p.Key == project_Person_RoleKey).SingleOrDefault();
                if (possibleProject_Person_Role != null)
                    Project_Person_Roles[i] = (Project_Person_RoleDto) possibleProject_Person_Role.Object;
                else
                    Normalizer.NormalizeProject_Person_Role(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < Project_Person_Roles?.Count; i++)
            {
                this.Project_Person_Roles[i] = Normalizer.DenormalizeProject_Person_Role(Project_Person_Roles[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class Project_Person_RoleExtendedDetailsRequestExtraObject
    {
    }

    /// <summary>
    /// Detail request, basically one item from the AugView Project_Person_Role, that user clicked after search was performed.
    /// </summary>
    public partial class Project_Person_RoleExtendedDetailsRequest : TransferBase
    {
        // Properties to be transfered

        public Project_Person_RoleDto Project_Person_Role { get; set; }


        // Custom properties, not to be transfered
        public Project_Person_RoleExtendedDetailsRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            var project_Person_RoleKey = "Project_Person_Role_" + Project_Person_Role.Project_Person_RoleId;
            var possibleProject_Person_Role = normalizer.DtoObjects.Where(p => p.Key == project_Person_RoleKey).SingleOrDefault();
            if (possibleProject_Person_Role != null)
                Project_Person_Role = (Project_Person_RoleDto)possibleProject_Person_Role.Object;
            else
                Normalizer.NormalizeProject_Person_Role(Project_Person_Role);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Project_Person_Role = Normalizer.DenormalizeProject_Person_Role(Project_Person_Role);

        }


    }

    public partial class Project_Person_RoleExtendedDetailsResponseExtraObject
    {
    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    public partial class Project_Person_RoleExtendedDetailsResponse : TransferBase
    {
        // Properties to be transfered

        public Project_Person_RoleDto Project_Person_Role { get; set; }

        public List<DepartmentDto> Departments { get; set; }

        public List<GenderDto> Genders { get; set; }

        public List<RoleDto> Roles { get; set; }

        public Project_Person_RoleExtendedDetailsRequest Request { get; set; }


        // Custom properties, not to be transfered
        public Project_Person_RoleExtendedDetailsResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            var project_Person_RoleKey = "Project_Person_Role_" + Project_Person_Role.Project_Person_RoleId;
            var possibleProject_Person_Role = normalizer.DtoObjects.Where(p => p.Key == project_Person_RoleKey).SingleOrDefault();
            if (possibleProject_Person_Role != null)
                Project_Person_Role = (Project_Person_RoleDto)possibleProject_Person_Role.Object;
            else
                Normalizer.NormalizeProject_Person_Role(Project_Person_Role);

            for (int i = 0 ; i < Departments?.Count ; i++)
            {
                var x = Departments[i];
                var departmentKey = "Department_" + x.DepartmentId;
                var possibleDepartment = normalizer.DtoObjects.Where(p => p.Key == departmentKey).SingleOrDefault();
                if (possibleDepartment != null)
                    Departments[i] = (DepartmentDto) possibleDepartment.Object;
                else
                    Normalizer.NormalizeDepartment(x); ;
            }

            for (int i = 0 ; i < Genders?.Count ; i++)
            {
                var x = Genders[i];
                var genderKey = "Gender_" + x.GenderId;
                var possibleGender = normalizer.DtoObjects.Where(p => p.Key == genderKey).SingleOrDefault();
                if (possibleGender != null)
                    Genders[i] = (GenderDto) possibleGender.Object;
                else
                    Normalizer.NormalizeGender(x); ;
            }

            for (int i = 0 ; i < Roles?.Count ; i++)
            {
                var x = Roles[i];
                var roleKey = "Role_" + x.RoleId;
                var possibleRole = normalizer.DtoObjects.Where(p => p.Key == roleKey).SingleOrDefault();
                if (possibleRole != null)
                    Roles[i] = (RoleDto) possibleRole.Object;
                else
                    Normalizer.NormalizeRole(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Project_Person_Role = Normalizer.DenormalizeProject_Person_Role(Project_Person_Role);

            for (int i = 0; i < Departments?.Count; i++)
            {
                this.Departments[i] = Normalizer.DenormalizeDepartment(Departments[i]);
            }

            for (int i = 0; i < Genders?.Count; i++)
            {
                this.Genders[i] = Normalizer.DenormalizeGender(Genders[i]);
            }

            for (int i = 0; i < Roles?.Count; i++)
            {
                this.Roles[i] = Normalizer.DenormalizeRole(Roles[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    /// <summary>
    /// Details response - internal DB representation of Details.
    /// </summary>
    public class Project_Person_RoleExtendedDetailsResponseDb
    {
        // Properties in db class

        public Models.Project_Person_Role Project_Person_Role { get; set; }

        public List<Models.Department> Departments { get; set; }

        public List<Models.Gender> Genders { get; set; }

        public List<Models.Role> Roles { get; set; }


        // Custom properties, not to be transfered

    }

}
