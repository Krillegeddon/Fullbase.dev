
using EmptyProjectCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmptyProjectCore.Api.Project_Person_RoleExtended
{
    public class Project_Person_RoleExtendedQueries
    {
        private ProjectContext _ctx { get; }

        public Project_Person_RoleExtendedQueries(ProjectContext ctx)
        {
            _ctx = ctx;
        }



        /// <summary>
        /// Based on search criteria, returns the search results.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public Project_Person_RoleExtendedSearchResponse GetSearch(Project_Person_RoleExtendedSearchRequest request)
        {
            var retObj = new Project_Person_RoleExtendedSearchResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();
            {
                var qProject_Person_Role0 = _ctx.Project_Person_Role
                    // Tree for  (Parent)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(request.QuickSearch))
                {
                    {
                        qProject_Person_Role0 = qProject_Person_Role0.Where(p =>
                            true /* nothing to search for, probably a Extended query? */
                        );
                    }
                }

                if (request.Project_Person_RoleId.ExactMatch.HasValue)
                {
                    qProject_Person_Role0 = qProject_Person_Role0.Where(p =>
                                p.Project_Person_RoleId == request.Project_Person_RoleId.ExactMatch.Value  // Foreign key search
                    );
                }

                //Add custom code here...
                qPerson0 = qPerson0.Where(p => p.Department.DepartmentName == "Department A");
                
                
                retObj.Project_Person_Roles = qProject_Person_Role0.Select(p => retObj.Normalizer.LoadProject_Person_Role(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on selected item from search, gets the detail information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public Project_Person_RoleExtendedDetailsResponse GetDetails(Project_Person_RoleExtendedDetailsRequest request)
        {
            
            var retObj = new Project_Person_RoleExtendedDetailsResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            if (request.Project_Person_Role.Project_Person_RoleId > 0)
            {
                var qProject_Person_Role0 = _ctx.Project_Person_Role.Where(x => x.Project_Person_RoleId == request.Project_Person_Role.Project_Person_RoleId)
                    // Tree for ProjectType (Parent)
                    .Include(p => p.Project)
                    .ThenInclude(p => p.ProjectType)
                    // Tree for Department (Parent)
                    .Include(p => p.Person)
                    .ThenInclude(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Person)
                    .ThenInclude(p => p.Gender)
                    // Tree for Role (Parent)
                    .Include(p => p.Role)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Project_Person_Role = retObj.Normalizer.LoadProject_Person_Role(qProject_Person_Role0);
            }
            else
            {
                retObj.Project_Person_Role = new Project_Person_RoleDto
                {
                    Project_Person_RoleId = -1
                };
            }
            {
                var qDepartment1 = _ctx.Department
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Departments = qDepartment1.Select(p => retObj.Normalizer.LoadDepartment(p)).ToList();
            }
            {
                var qGender2 = _ctx.Gender
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Genders = qGender2.Select(p => retObj.Normalizer.LoadGender(p)).ToList();
            }
            {
                var qRole3 = _ctx.Role
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Roles = qRole3.Select(p => retObj.Normalizer.LoadRole(p)).ToList();
            }


            return retObj;
        }

        private Project_Person_RoleExtendedDetailsResponseDb GetDetailsDb(Project_Person_RoleExtendedDetailsRequest request)
        {
            
            var retObj = new Project_Person_RoleExtendedDetailsResponseDb();

            {
                var qProject_Person_Role0 = _ctx.Project_Person_Role.Where(x => x.Project_Person_RoleId == request.Project_Person_Role.Project_Person_RoleId)
                    // Tree for ProjectType (Parent)
                    .Include(p => p.Project)
                    .ThenInclude(p => p.ProjectType)
                    // Tree for Department (Parent)
                    .Include(p => p.Person)
                    .ThenInclude(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Person)
                    .ThenInclude(p => p.Gender)
                    // Tree for Role (Parent)
                    .Include(p => p.Role)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Project_Person_Role = qProject_Person_Role0;
            }
            {
                var qDepartment1 = _ctx.Department
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Departments = qDepartment1;
            }
            {
                var qGender2 = _ctx.Gender
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Genders = qGender2;
            }
            {
                var qRole3 = _ctx.Role
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Roles = qRole3;
            }


            return retObj;
        }


        public void SaveDetails(Project_Person_RoleExtendedDetailsResponse taintedResponse)
        {
            restart:
            var project_Person_Role0Db = GetDetailsDb(taintedResponse.Request).Project_Person_Role; // Get the same thing as request
            var project_Person_Role0 = taintedResponse.Project_Person_Role;


            if (project_Person_Role0Db == null)
            {
                // No row in db = insert!
                var d = new EmptyProjectCore.Models.Project_Person_Role();
                d.PersonId = project_Person_Role0.PersonId;
                d.ProjectId = project_Person_Role0.ProjectId;
                d.RoleId = project_Person_Role0.RoleId;

                _ctx.Project_Person_Role.Add(d);
                _ctx.SaveChanges();
                project_Person_Role0.Project_Person_RoleId = d.Project_Person_RoleId;
                goto restart;
            }




            if (project_Person_Role0 != null && project_Person_Role0.IsDeleted)
            {
                _ctx.Project_Person_Role.Remove(project_Person_Role0Db);
            }
            else if (project_Person_Role0 != null && project_Person_Role0.IsTainted)
            {
                // Check if id has changed
                if (project_Person_Role0Db?.Project_Person_RoleId != project_Person_Role0.Project_Person_RoleId && project_Person_Role0Db?.Project_Person_RoleId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project_Person_Role0Db?.Project_Person_RoleId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                if (project_Person_Role0 != null && project_Person_Role0.Person != null)
                    project_Person_Role0Db.PersonId = project_Person_Role0.Person.PersonId; // Non-nullable parent - if null, we shall not update...
                if (project_Person_Role0 != null && project_Person_Role0.Project != null)
                    project_Person_Role0Db.ProjectId = project_Person_Role0.Project.ProjectId; // Non-nullable parent - if null, we shall not update...
                if (project_Person_Role0 != null && project_Person_Role0.Role != null)
                    project_Person_Role0Db.RoleId = project_Person_Role0.Role.RoleId; // Non-nullable parent - if null, we shall not update...

                if (project_Person_Role0Db.Project_Person_RoleId != 0)
                {
                    _ctx.Update(project_Person_Role0Db);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project_Person_Role0.Project_Person_RoleId = project_Person_Role0Db.Project_Person_RoleId;
                }
                project_Person_Role0.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (project_Person_Role0?.Project != null && project_Person_Role0.Project.IsDeleted)
            {
                _ctx.Project.Remove(project_Person_Role0Db.Project);
            }
            else if (project_Person_Role0?.Project != null && project_Person_Role0.Project.IsTainted)
            {
                // Check if id has changed
                if (project_Person_Role0Db.Project?.ProjectId != project_Person_Role0.Project.ProjectId && project_Person_Role0Db.Project?.ProjectId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project_Person_Role0Db.Project?.ProjectId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project_Person_Role0Db.Project.ProjectName = project_Person_Role0.Project.ProjectName; // Data field
                project_Person_Role0Db.Project.IsProBono = project_Person_Role0.Project.IsProBono; // Data field
                project_Person_Role0Db.Project.Deadline = project_Person_Role0.Project.Deadline; // Data field
                if (project_Person_Role0.Project != null && project_Person_Role0.Project.ProjectType != null)
                    project_Person_Role0Db.Project.ProjectTypeId = project_Person_Role0.Project.ProjectType.ProjectTypeId; // Non-nullable parent - if null, we shall not update...

                if (project_Person_Role0Db.Project.ProjectId != 0)
                {
                    _ctx.Update(project_Person_Role0Db.Project);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project_Person_Role0.Project.ProjectId = project_Person_Role0Db.Project.ProjectId;
                }
                project_Person_Role0.Project.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (project_Person_Role0?.Project?.ProjectType != null && project_Person_Role0.Project.ProjectType.IsDeleted)
            {
                _ctx.ProjectType.Remove(project_Person_Role0Db.Project.ProjectType);
            }
            else if (project_Person_Role0?.Project?.ProjectType != null && project_Person_Role0.Project.ProjectType.IsTainted)
            {
                // Check if id has changed
                if (project_Person_Role0Db.Project.ProjectType?.ProjectTypeId != project_Person_Role0.Project.ProjectType.ProjectTypeId && project_Person_Role0Db.Project.ProjectType?.ProjectTypeId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project_Person_Role0Db.Project.ProjectType?.ProjectTypeId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project_Person_Role0Db.Project.ProjectType.ProjectTypeName = project_Person_Role0.Project.ProjectType.ProjectTypeName; // Data field

                if (project_Person_Role0Db.Project.ProjectType.ProjectTypeId != 0)
                {
                    _ctx.Update(project_Person_Role0Db.Project.ProjectType);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project_Person_Role0.Project.ProjectType.ProjectTypeId = project_Person_Role0Db.Project.ProjectType.ProjectTypeId;
                }
                project_Person_Role0.Project.ProjectType.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (project_Person_Role0?.Person != null && project_Person_Role0.Person.IsDeleted)
            {
                _ctx.Person.Remove(project_Person_Role0Db.Person);
            }
            else if (project_Person_Role0?.Person != null && project_Person_Role0.Person.IsTainted)
            {
                // Check if id has changed
                if (project_Person_Role0Db.Person?.PersonId != project_Person_Role0.Person.PersonId && project_Person_Role0Db.Person?.PersonId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project_Person_Role0Db.Person?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project_Person_Role0Db.Person.UserName = project_Person_Role0.Person.UserName; // Data field
                project_Person_Role0Db.Person.Salary = project_Person_Role0.Person.Salary; // Data field
                if (project_Person_Role0.Person != null && project_Person_Role0.Person.Department != null)
                    project_Person_Role0Db.Person.DepartmentId = project_Person_Role0.Person.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                if (project_Person_Role0.Person != null && project_Person_Role0.Person.Gender != null)
                    project_Person_Role0Db.Person.GenderId = project_Person_Role0.Person.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                project_Person_Role0Db.Person.ManagerId = project_Person_Role0.Person.Manager?.PersonId; // Nullable parent

                if (project_Person_Role0Db.Person.PersonId != 0)
                {
                    _ctx.Update(project_Person_Role0Db.Person);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project_Person_Role0.Person.PersonId = project_Person_Role0Db.Person.PersonId;
                }
                project_Person_Role0.Person.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (project_Person_Role0?.Person?.Department != null && project_Person_Role0.Person.Department.IsDeleted)
            {
                _ctx.Department.Remove(project_Person_Role0Db.Person.Department);
            }
            else if (project_Person_Role0?.Person?.Department != null && project_Person_Role0.Person.Department.IsTainted)
            {
                // Check if id has changed
                if (project_Person_Role0Db.Person.Department?.DepartmentId != project_Person_Role0.Person.Department.DepartmentId && project_Person_Role0Db.Person.Department?.DepartmentId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project_Person_Role0Db.Person.Department?.DepartmentId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project_Person_Role0Db.Person.Department.DepartmentName = project_Person_Role0.Person.Department.DepartmentName; // Data field

                if (project_Person_Role0Db.Person.Department.DepartmentId != 0)
                {
                    _ctx.Update(project_Person_Role0Db.Person.Department);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project_Person_Role0.Person.Department.DepartmentId = project_Person_Role0Db.Person.Department.DepartmentId;
                }
                project_Person_Role0.Person.Department.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (project_Person_Role0?.Person?.Gender != null && project_Person_Role0.Person.Gender.IsDeleted)
            {
                _ctx.Gender.Remove(project_Person_Role0Db.Person.Gender);
            }
            else if (project_Person_Role0?.Person?.Gender != null && project_Person_Role0.Person.Gender.IsTainted)
            {
                // Check if id has changed
                if (project_Person_Role0Db.Person.Gender?.GenderId != project_Person_Role0.Person.Gender.GenderId && project_Person_Role0Db.Person.Gender?.GenderId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project_Person_Role0Db.Person.Gender?.GenderId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project_Person_Role0Db.Person.Gender.GenderDescription = project_Person_Role0.Person.Gender.GenderDescription; // Data field

                if (project_Person_Role0Db.Person.Gender.GenderId != 0)
                {
                    _ctx.Update(project_Person_Role0Db.Person.Gender);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project_Person_Role0.Person.Gender.GenderId = project_Person_Role0Db.Person.Gender.GenderId;
                }
                project_Person_Role0.Person.Gender.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (project_Person_Role0?.Role != null && project_Person_Role0.Role.IsDeleted)
            {
                _ctx.Role.Remove(project_Person_Role0Db.Role);
            }
            else if (project_Person_Role0?.Role != null && project_Person_Role0.Role.IsTainted)
            {
                // Check if id has changed
                if (project_Person_Role0Db.Role?.RoleId != project_Person_Role0.Role.RoleId && project_Person_Role0Db.Role?.RoleId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project_Person_Role0Db.Role?.RoleId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project_Person_Role0Db.Role.RoleName = project_Person_Role0.Role.RoleName; // Data field

                if (project_Person_Role0Db.Role.RoleId != 0)
                {
                    _ctx.Update(project_Person_Role0Db.Role);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project_Person_Role0.Role.RoleId = project_Person_Role0Db.Role.RoleId;
                }
                project_Person_Role0.Role.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

        }

    }
}
