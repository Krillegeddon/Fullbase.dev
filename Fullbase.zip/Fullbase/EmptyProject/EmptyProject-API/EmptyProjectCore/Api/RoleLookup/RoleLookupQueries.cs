
using EmptyProjectCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmptyProjectCore.Api.RoleLookup
{
    public class RoleLookupQueries
    {
        private ProjectContext _ctx { get; }

        public RoleLookupQueries(ProjectContext ctx)
        {
            _ctx = ctx;
        }



        /// <summary>
        /// Based on search criteria, returns the search results.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public RoleLookupSearchResponse GetSearch(RoleLookupSearchRequest request)
        {
            var retObj = new RoleLookupSearchResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();
            {
                var qRole0 = _ctx.Role
                    // Tree for  (Parent)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(request.QuickSearch))
                {
                    {
                        qRole0 = qRole0.Where(p =>
                        p.RoleName.ToLower().Contains(request.QuickSearch.ToLower())
                        );
                    }
                }

                if (request.RoleId.ExactMatch.HasValue)
                {
                    qRole0 = qRole0.Where(p =>
                                p.RoleId == request.RoleId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.RoleName.ExactMatch)) // One field, string
                {
                    qRole0 = qRole0.Where(p =>
                                p.RoleName == request.RoleName.ExactMatch
                    );
                }

                if (!string.IsNullOrEmpty(request.RoleName.ContainsMatch)) // One field, string
                {
                    qRole0 = qRole0.Where(p =>
                                p.RoleName.Contains(request.RoleName.ContainsMatch)
                    );
                }

                if (!string.IsNullOrEmpty(request.RoleName.StartsWithMatch)) // One field, string
                {
                    qRole0 = qRole0.Where(p =>
                                p.RoleName.StartsWith(request.RoleName.StartsWithMatch)
                    );
                }

                //Add custom code here...
                retObj.Roles = qRole0.Select(p => retObj.Normalizer.LoadRole(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on selected item from search, gets the detail information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public RoleLookupDetailsResponse GetDetails(RoleLookupDetailsRequest request)
        {
            
            var retObj = new RoleLookupDetailsResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            if (request.Role.RoleId > 0)
            {
                var qRole0 = _ctx.Role.Where(x => x.RoleId == request.Role.RoleId)
                    // Tree for  (Parent)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Role = retObj.Normalizer.LoadRole(qRole0);
            }
            else
            {
                retObj.Role = new RoleDto
                {
                    RoleId = -1
                };
            }


            return retObj;
        }

        private RoleLookupDetailsResponseDb GetDetailsDb(RoleLookupDetailsRequest request)
        {
            
            var retObj = new RoleLookupDetailsResponseDb();

            {
                var qRole0 = _ctx.Role.Where(x => x.RoleId == request.Role.RoleId)
                    // Tree for  (Parent)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Role = qRole0;
            }


            return retObj;
        }


        public void SaveDetails(RoleLookupDetailsResponse taintedResponse)
        {
            restart:
            var role0Db = GetDetailsDb(taintedResponse.Request).Role; // Get the same thing as request
            var role0 = taintedResponse.Role;


            if (role0Db == null)
            {
                // No row in db = insert!
                var d = new EmptyProjectCore.Models.Role();
                d.RoleName = role0.RoleName;

                _ctx.Role.Add(d);
                _ctx.SaveChanges();
                role0.RoleId = d.RoleId;
                goto restart;
            }




            if (role0 != null && role0.IsDeleted)
            {
                _ctx.Role.Remove(role0Db);
            }
            else if (role0 != null && role0.IsTainted)
            {
                // Check if id has changed
                if (role0Db?.RoleId != role0.RoleId && role0Db?.RoleId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // role0Db?.RoleId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                role0Db.RoleName = role0.RoleName; // Data field

                if (role0Db.RoleId != 0)
                {
                    _ctx.Update(role0Db);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    role0.RoleId = role0Db.RoleId;
                }
                role0.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

        }

    }
}
