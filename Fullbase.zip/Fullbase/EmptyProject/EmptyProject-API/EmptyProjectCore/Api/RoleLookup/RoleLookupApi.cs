
using EmptyProjectCore.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace EmptyProjectCore.Api.RoleLookup
{

    public partial class RoleLookupFilterRequestExtraObject
    {
    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    public partial class RoleLookupFilterRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public RoleLookupFilterRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class RoleLookupFilterResponseExtraObject
    {
    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    public partial class RoleLookupFilterResponse : TransferBase
    {
        // Properties to be transfered

        public RoleLookupFilterRequest Request { get; set; }


        // Custom properties, not to be transfered
        public RoleLookupFilterResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Request.Denormalize(Normalizer);

        }


    }

    public partial class RoleLookupSearchRequestExtraObject
    {
    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    public partial class RoleLookupSearchRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public RoleLookupSearchRequestExtraObject ExtraObject { get; set; }

        public string QuickSearch { get; set; }

        public IntClause RoleId { get; set; }

        public StringClause RoleName { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class RoleLookupSearchResponseExtraObject
    {
    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    public partial class RoleLookupSearchResponse : TransferBase
    {
        // Properties to be transfered

        public List<RoleDto> Roles { get; set; }

        public RoleLookupSearchRequest Request { get; set; }


        // Custom properties, not to be transfered
        public RoleLookupSearchResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0; i < Roles?.Count; i++)
            {
                var x = Roles[i];
                var roleKey = "Role_" + x.RoleId;
                var possibleRole = normalizer.DtoObjects.Where(p => p.Key == roleKey).SingleOrDefault();
                if (possibleRole != null)
                    Roles[i] = (RoleDto) possibleRole.Object;
                else
                    Normalizer.NormalizeRole(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < Roles?.Count; i++)
            {
                this.Roles[i] = Normalizer.DenormalizeRole(Roles[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class RoleLookupDetailsRequestExtraObject
    {
    }

    /// <summary>
    /// Detail request, basically one item from the AugView Role, that user clicked after search was performed.
    /// </summary>
    public partial class RoleLookupDetailsRequest : TransferBase
    {
        // Properties to be transfered

        public RoleDto Role { get; set; }


        // Custom properties, not to be transfered
        public RoleLookupDetailsRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var roleKey = "Role_" + Role.RoleId;
                var possibleRole = normalizer.DtoObjects.Where(p => p.Key == roleKey).SingleOrDefault();
                if (possibleRole != null)
                    Role = (RoleDto)possibleRole.Object;
                else
                    Normalizer.NormalizeRole(Role);
            }

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Role = Normalizer.DenormalizeRole(Role);

        }


    }

    public partial class RoleLookupDetailsResponseExtraObject
    {
    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    public partial class RoleLookupDetailsResponse : TransferBase
    {
        // Properties to be transfered

        public RoleDto Role { get; set; }

        public RoleLookupDetailsRequest Request { get; set; }


        // Custom properties, not to be transfered
        public RoleLookupDetailsResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var roleKey = "Role_" + Role.RoleId;
                var possibleRole = normalizer.DtoObjects.Where(p => p.Key == roleKey).SingleOrDefault();
                if (possibleRole != null)
                    Role = (RoleDto)possibleRole.Object;
                else
                    Normalizer.NormalizeRole(Role);
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Role = Normalizer.DenormalizeRole(Role);

            Request.Denormalize(Normalizer);

        }


    }

    /// <summary>
    /// Details response - internal DB representation of Details.
    /// </summary>
    public class RoleLookupDetailsResponseDb
    {
        // Properties in db class

        public Models.Role Role { get; set; }


        // Custom properties, not to be transfered

    }

}
