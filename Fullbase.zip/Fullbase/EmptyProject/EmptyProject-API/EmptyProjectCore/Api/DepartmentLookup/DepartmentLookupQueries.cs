
using EmptyProjectCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmptyProjectCore.Api.DepartmentLookup
{
    public class DepartmentLookupQueries
    {
        private ProjectContext _ctx { get; }

        public DepartmentLookupQueries(ProjectContext ctx)
        {
            _ctx = ctx;
        }



        /// <summary>
        /// Based on search criteria, returns the search results.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public DepartmentLookupSearchResponse GetSearch(DepartmentLookupSearchRequest request)
        {
            var retObj = new DepartmentLookupSearchResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();
            {
                var qDepartment0 = _ctx.Department
                    // Tree for  (Parent)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(request.QuickSearch))
                {
                    {
                        qDepartment0 = qDepartment0.Where(p =>
                        p.DepartmentName.ToLower().Contains(request.QuickSearch.ToLower())
                        );
                    }
                }

                if (request.DepartmentId.ExactMatch.HasValue)
                {
                    qDepartment0 = qDepartment0.Where(p =>
                                p.DepartmentId == request.DepartmentId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.DepartmentName.ExactMatch)) // One field, string
                {
                    qDepartment0 = qDepartment0.Where(p =>
                                p.DepartmentName == request.DepartmentName.ExactMatch
                    );
                }

                //Add custom code here...
                qPerson0 = qPerson0.Where(p => p.Department.DepartmentName == "Department A");
                
                
                retObj.Departments = qDepartment0.Select(p => retObj.Normalizer.LoadDepartment(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on selected item from search, gets the detail information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public DepartmentLookupDetailsResponse GetDetails(DepartmentLookupDetailsRequest request)
        {
            
            var retObj = new DepartmentLookupDetailsResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            if (request.Department.DepartmentId > 0)
            {
                var qDepartment0 = _ctx.Department.Where(x => x.DepartmentId == request.Department.DepartmentId)
                    // Tree for  (Parent)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Department = retObj.Normalizer.LoadDepartment(qDepartment0);
            }
            else
            {
                retObj.Department = new DepartmentDto
                {
                    DepartmentId = -1
                };
            }


            return retObj;
        }

        private DepartmentLookupDetailsResponseDb GetDetailsDb(DepartmentLookupDetailsRequest request)
        {
            
            var retObj = new DepartmentLookupDetailsResponseDb();

            {
                var qDepartment0 = _ctx.Department.Where(x => x.DepartmentId == request.Department.DepartmentId)
                    // Tree for  (Parent)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Department = qDepartment0;
            }


            return retObj;
        }


        public void SaveDetails(DepartmentLookupDetailsResponse taintedResponse)
        {
            restart:
            var department0Db = GetDetailsDb(taintedResponse.Request).Department; // Get the same thing as request
            var department0 = taintedResponse.Department;


            if (department0Db == null)
            {
                // No row in db = insert!
                var d = new EmptyProjectCore.Models.Department();
                d.DepartmentName = department0.DepartmentName;

                _ctx.Department.Add(d);
                _ctx.SaveChanges();
                department0.DepartmentId = d.DepartmentId;
                goto restart;
            }




            if (department0 != null && department0.IsDeleted)
            {
                _ctx.Department.Remove(department0Db);
            }
            else if (department0 != null && department0.IsTainted)
            {
                // Check if id has changed
                if (department0Db?.DepartmentId != department0.DepartmentId && department0Db?.DepartmentId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // department0Db?.DepartmentId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                department0Db.DepartmentName = department0.DepartmentName; // Data field

                if (department0Db.DepartmentId != 0)
                {
                    _ctx.Update(department0Db);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    department0.DepartmentId = department0Db.DepartmentId;
                }
                department0.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

        }

    }
}
