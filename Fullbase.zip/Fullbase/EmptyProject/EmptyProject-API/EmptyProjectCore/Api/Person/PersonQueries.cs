
using EmptyProjectCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmptyProjectCore.Api.Person
{
    public class PersonQueries
    {
        private ProjectContext _ctx { get; }

        public PersonQueries(ProjectContext ctx)
        {
            _ctx = ctx;
        }


        /// <summary>
        /// Gets all data that is need to show the search criteria
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public PersonFilterResponse GetFilter(PersonFilterRequest request)
        {
            var retObj = new PersonFilterResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            {
                var qGender0 = _ctx.Gender
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Genders = qGender0.Select(p => retObj.Normalizer.LoadGender(p)).ToList();
            }
            {
                var qDepartment1 = _ctx.Department
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Departments = qDepartment1.Select(p => retObj.Normalizer.LoadDepartment(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on search criteria, returns the search results.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public PersonSearchResponse GetSearch(PersonSearchRequest request)
        {
            var retObj = new PersonSearchResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();
            {
                var qPerson0 = _ctx.Person
                    // Tree for Department (Parent)
                    .Include(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Gender)
                    // Tree for Manager (Parent)
                    .Include(p => p.Manager)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(request.QuickSearch))
                {
                    {
                        qPerson0 = qPerson0.Where(p =>
                        p.UserName.ToLower().Contains(request.QuickSearch.ToLower()) ||
                        p.Department.DepartmentName.ToLower().Contains(request.QuickSearch.ToLower()) ||
                        p.Gender.GenderDescription.ToLower().Contains(request.QuickSearch.ToLower()) ||
                        p.Manager.UserName.ToLower().Contains(request.QuickSearch.ToLower())
                        );
                    }
                }

                if (request.PersonId.ExactMatch.HasValue)
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.PersonId == request.PersonId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.UserName.ExactMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.UserName == request.UserName.ExactMatch
                    );
                }

                if (!string.IsNullOrEmpty(request.UserName.ContainsMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.UserName.Contains(request.UserName.ContainsMatch)
                    );
                }

                if (!string.IsNullOrEmpty(request.UserName.StartsWithMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.UserName.StartsWith(request.UserName.StartsWithMatch)
                    );
                }

                if (request.Salary.ExactMatch.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Salary == request.Salary.ExactMatch.Value
                    );
                }

                if (request.Salary.MoreThan.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Salary >= request.Salary.MoreThan.Value
                    );
                }

                if (request.Salary.LessThan.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Salary <= request.Salary.LessThan.Value
                    );
                }

                if (request.Department_DepartmentId.ExactMatch.HasValue)
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Department.DepartmentId == request.Department_DepartmentId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.Department_DepartmentName.ExactMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Department.DepartmentName == request.Department_DepartmentName.ExactMatch
                    );
                }

                if (!string.IsNullOrEmpty(request.Department_DepartmentName.ContainsMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Department.DepartmentName.Contains(request.Department_DepartmentName.ContainsMatch)
                    );
                }

                if (!string.IsNullOrEmpty(request.Department_DepartmentName.StartsWithMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Department.DepartmentName.StartsWith(request.Department_DepartmentName.StartsWithMatch)
                    );
                }

                if (request.Gender_GenderId.ExactMatch.HasValue)
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Gender.GenderId == request.Gender_GenderId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.Gender_GenderDescription.ExactMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Gender.GenderDescription == request.Gender_GenderDescription.ExactMatch
                    );
                }

                if (!string.IsNullOrEmpty(request.Gender_GenderDescription.ContainsMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Gender.GenderDescription.Contains(request.Gender_GenderDescription.ContainsMatch)
                    );
                }

                if (!string.IsNullOrEmpty(request.Gender_GenderDescription.StartsWithMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Gender.GenderDescription.StartsWith(request.Gender_GenderDescription.StartsWithMatch)
                    );
                }

                if (request.Manager_PersonId.ExactMatch.HasValue)
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.PersonId == request.Manager_PersonId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.Manager_UserName.ExactMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.UserName == request.Manager_UserName.ExactMatch
                    );
                }

                if (!string.IsNullOrEmpty(request.Manager_UserName.ContainsMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.UserName.Contains(request.Manager_UserName.ContainsMatch)
                    );
                }

                if (!string.IsNullOrEmpty(request.Manager_UserName.StartsWithMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.UserName.StartsWith(request.Manager_UserName.StartsWithMatch)
                    );
                }

                if (request.Manager_Salary.ExactMatch.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.Salary == request.Manager_Salary.ExactMatch.Value
                    );
                }

                if (request.Manager_Salary.MoreThan.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.Salary >= request.Manager_Salary.MoreThan.Value
                    );
                }

                if (request.Manager_Salary.LessThan.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.Salary <= request.Manager_Salary.LessThan.Value
                    );
                }

                //Add custom code here...
                retObj.Persons = qPerson0.Select(p => retObj.Normalizer.LoadPerson(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on selected item from search, gets the detail information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public PersonDetailsResponse GetDetails(PersonDetailsRequest request)
        {
            
            var retObj = new PersonDetailsResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            if (request.Person.PersonId > 0)
            {
                var qPerson0 = _ctx.Person.Where(x => x.PersonId == request.Person.PersonId)
                    // Tree for Department (Parent)
                    .Include(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Gender)
                    // Tree for Department (Parent)
                    .Include(p => p.Manager)
                    .ThenInclude(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Manager)
                    .ThenInclude(p => p.Gender)
                    // Tree for ProjectType (Parent)
                    .Include(p => p.Project_Person_Roles)
                    .ThenInclude(p => p.Project)
                    .ThenInclude(p => p.ProjectType)
                    // Tree for Department (Parent)
                    .Include(p => p.Project_Person_Roles)
                    .ThenInclude(p => p.Person)
                    .ThenInclude(p => p.Department)
                    // Tree for Role (Parent)
                    .Include(p => p.Project_Person_Roles)
                    .ThenInclude(p => p.Role)
                    // Tree for Clients (Child)
                    .Include(p => p.Clients)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Person = retObj.Normalizer.LoadPerson(qPerson0);
            }
            else
            {
                retObj.Person = new PersonDto
                {
                    PersonId = -1
                };
            }
            {
                var qGender1 = _ctx.Gender
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Genders = qGender1.Select(p => retObj.Normalizer.LoadGender(p)).ToList();
            }
            {
                var qDepartment2 = _ctx.Department
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Departments = qDepartment2.Select(p => retObj.Normalizer.LoadDepartment(p)).ToList();
            }


            return retObj;
        }

        private PersonDetailsResponseDb GetDetailsDb(PersonDetailsRequest request)
        {
            
            var retObj = new PersonDetailsResponseDb();

            {
                var qPerson0 = _ctx.Person.Where(x => x.PersonId == request.Person.PersonId)
                    // Tree for Department (Parent)
                    .Include(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Gender)
                    // Tree for Department (Parent)
                    .Include(p => p.Manager)
                    .ThenInclude(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Manager)
                    .ThenInclude(p => p.Gender)
                    // Tree for ProjectType (Parent)
                    .Include(p => p.Project_Person_Roles)
                    .ThenInclude(p => p.Project)
                    .ThenInclude(p => p.ProjectType)
                    // Tree for Department (Parent)
                    .Include(p => p.Project_Person_Roles)
                    .ThenInclude(p => p.Person)
                    .ThenInclude(p => p.Department)
                    // Tree for Role (Parent)
                    .Include(p => p.Project_Person_Roles)
                    .ThenInclude(p => p.Role)
                    // Tree for Clients (Child)
                    .Include(p => p.Clients)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Person = qPerson0;
            }
            {
                var qGender1 = _ctx.Gender
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Genders = qGender1;
            }
            {
                var qDepartment2 = _ctx.Department
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Departments = qDepartment2;
            }


            return retObj;
        }


        public void SaveDetails(PersonDetailsResponse taintedResponse)
        {
            restart:
            var person0Db = GetDetailsDb(taintedResponse.Request).Person; // Get the same thing as request
            var person0 = taintedResponse.Person;


            if (person0Db == null)
            {
                // No row in db = insert!
                var d = new EmptyProjectCore.Models.Person();
                d.UserName = person0.UserName;
                d.Salary = person0.Salary;
                d.DepartmentId = person0.DepartmentId;
                d.GenderId = person0.GenderId;
                d.ManagerId = person0.ManagerId;

                _ctx.Person.Add(d);
                _ctx.SaveChanges();
                person0.PersonId = d.PersonId;
                goto restart;
            }




            if (person0 != null && person0.IsDeleted)
            {
                _ctx.Person.Remove(person0Db);
            }
            else if (person0 != null && person0.IsTainted)
            {
                // Check if id has changed
                if (person0Db?.PersonId != person0.PersonId && person0Db?.PersonId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.UserName = person0.UserName; // Data field
                person0Db.Salary = person0.Salary; // Data field
                if (person0 != null && person0.Department != null)
                    person0Db.DepartmentId = person0.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                if (person0 != null && person0.Gender != null)
                    person0Db.GenderId = person0.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                person0Db.ManagerId = person0.Manager?.PersonId; // Nullable parent

                if (person0Db.PersonId != 0)
                {
                    _ctx.Update(person0Db);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.PersonId = person0Db.PersonId;
                }
                person0.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Department != null && person0.Department.IsDeleted)
            {
                _ctx.Department.Remove(person0Db.Department);
            }
            else if (person0?.Department != null && person0.Department.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Department?.DepartmentId != person0.Department.DepartmentId && person0Db.Department?.DepartmentId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Department?.DepartmentId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Department.DepartmentName = person0.Department.DepartmentName; // Data field

                if (person0Db.Department.DepartmentId != 0)
                {
                    _ctx.Update(person0Db.Department);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Department.DepartmentId = person0Db.Department.DepartmentId;
                }
                person0.Department.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Gender != null && person0.Gender.IsDeleted)
            {
                _ctx.Gender.Remove(person0Db.Gender);
            }
            else if (person0?.Gender != null && person0.Gender.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Gender?.GenderId != person0.Gender.GenderId && person0Db.Gender?.GenderId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Gender?.GenderId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Gender.GenderDescription = person0.Gender.GenderDescription; // Data field

                if (person0Db.Gender.GenderId != 0)
                {
                    _ctx.Update(person0Db.Gender);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Gender.GenderId = person0Db.Gender.GenderId;
                }
                person0.Gender.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Manager != null && person0.Manager.IsDeleted)
            {
                _ctx.Person.Remove(person0Db.Manager);
            }
            else if (person0?.Manager != null && person0.Manager.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Manager?.PersonId != person0.Manager.PersonId && person0Db.Manager?.PersonId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Manager?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Manager.UserName = person0.Manager.UserName; // Data field
                person0Db.Manager.Salary = person0.Manager.Salary; // Data field
                if (person0.Manager != null && person0.Manager.Department != null)
                    person0Db.Manager.DepartmentId = person0.Manager.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                if (person0.Manager != null && person0.Manager.Gender != null)
                    person0Db.Manager.GenderId = person0.Manager.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                person0Db.Manager.ManagerId = person0.Manager.Manager?.PersonId; // Nullable parent

                if (person0Db.Manager.PersonId != 0)
                {
                    _ctx.Update(person0Db.Manager);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Manager.PersonId = person0Db.Manager.PersonId;
                }
                person0.Manager.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Manager?.Department != null && person0.Manager.Department.IsDeleted)
            {
                _ctx.Department.Remove(person0Db.Manager.Department);
            }
            else if (person0?.Manager?.Department != null && person0.Manager.Department.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Manager.Department?.DepartmentId != person0.Manager.Department.DepartmentId && person0Db.Manager.Department?.DepartmentId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Manager.Department?.DepartmentId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Manager.Department.DepartmentName = person0.Manager.Department.DepartmentName; // Data field

                if (person0Db.Manager.Department.DepartmentId != 0)
                {
                    _ctx.Update(person0Db.Manager.Department);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Manager.Department.DepartmentId = person0Db.Manager.Department.DepartmentId;
                }
                person0.Manager.Department.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Manager?.Gender != null && person0.Manager.Gender.IsDeleted)
            {
                _ctx.Gender.Remove(person0Db.Manager.Gender);
            }
            else if (person0?.Manager?.Gender != null && person0.Manager.Gender.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Manager.Gender?.GenderId != person0.Manager.Gender.GenderId && person0Db.Manager.Gender?.GenderId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Manager.Gender?.GenderId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Manager.Gender.GenderDescription = person0.Manager.Gender.GenderDescription; // Data field

                if (person0Db.Manager.Gender.GenderId != 0)
                {
                    _ctx.Update(person0Db.Manager.Gender);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Manager.Gender.GenderId = person0Db.Manager.Gender.GenderId;
                }
                person0.Manager.Gender.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            // Before checking child
            if (person0 != null && person0.Project_Person_Roles != null)
            {
                foreach (var project_Person_Role1 in person0.Project_Person_Roles)
                {
                    var project_Person_Role1Db = person0Db.Project_Person_Roles.Where(p=>p.Project_Person_RoleId == project_Person_Role1.Project_Person_RoleId).SingleOrDefault();
                    if (project_Person_Role1Db == null && project_Person_Role1.IsDeleted != true)
                    {
                        project_Person_Role1Db = new EmptyProjectCore.Models.Project_Person_Role();
                        _ctx.Project_Person_Role.Add(project_Person_Role1Db);
                    }
                    // Above shall handle the fact that we have added a child

                    if (project_Person_Role1 != null && project_Person_Role1.IsDeleted)
                    {
                        _ctx.Project_Person_Role.Remove(project_Person_Role1Db);
                    }
                    else if (project_Person_Role1 != null && project_Person_Role1.IsTainted)
                    {
                        // Check if id has changed
                        if (project_Person_Role1Db?.Project_Person_RoleId != project_Person_Role1.Project_Person_RoleId && project_Person_Role1Db?.Project_Person_RoleId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // project_Person_Role1Db?.Project_Person_RoleId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        if (project_Person_Role1 != null && project_Person_Role1.Person != null)
                            project_Person_Role1Db.PersonId = project_Person_Role1.Person.PersonId; // Non-nullable parent - if null, we shall not update...
                        if (project_Person_Role1 != null && project_Person_Role1.Project != null)
                            project_Person_Role1Db.ProjectId = project_Person_Role1.Project.ProjectId; // Non-nullable parent - if null, we shall not update...
                        if (project_Person_Role1 != null && project_Person_Role1.Role != null)
                            project_Person_Role1Db.RoleId = project_Person_Role1.Role.RoleId; // Non-nullable parent - if null, we shall not update...

                        if (project_Person_Role1Db.Project_Person_RoleId != 0)
                        {
                            _ctx.Update(project_Person_Role1Db);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            project_Person_Role1.Project_Person_RoleId = project_Person_Role1Db.Project_Person_RoleId;
                        }
                        project_Person_Role1.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                    if (project_Person_Role1?.Project != null && project_Person_Role1.Project.IsDeleted)
                    {
                        _ctx.Project.Remove(project_Person_Role1Db.Project);
                    }
                    else if (project_Person_Role1?.Project != null && project_Person_Role1.Project.IsTainted)
                    {
                        // Check if id has changed
                        if (project_Person_Role1Db.Project?.ProjectId != project_Person_Role1.Project.ProjectId && project_Person_Role1Db.Project?.ProjectId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // project_Person_Role1Db.Project?.ProjectId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        project_Person_Role1Db.Project.ProjectName = project_Person_Role1.Project.ProjectName; // Data field
                        project_Person_Role1Db.Project.IsProBono = project_Person_Role1.Project.IsProBono; // Data field
                        project_Person_Role1Db.Project.Deadline = project_Person_Role1.Project.Deadline; // Data field
                        if (project_Person_Role1.Project != null && project_Person_Role1.Project.ProjectType != null)
                            project_Person_Role1Db.Project.ProjectTypeId = project_Person_Role1.Project.ProjectType.ProjectTypeId; // Non-nullable parent - if null, we shall not update...

                        if (project_Person_Role1Db.Project.ProjectId != 0)
                        {
                            _ctx.Update(project_Person_Role1Db.Project);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            project_Person_Role1.Project.ProjectId = project_Person_Role1Db.Project.ProjectId;
                        }
                        project_Person_Role1.Project.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                    if (project_Person_Role1?.Project?.ProjectType != null && project_Person_Role1.Project.ProjectType.IsDeleted)
                    {
                        _ctx.ProjectType.Remove(project_Person_Role1Db.Project.ProjectType);
                    }
                    else if (project_Person_Role1?.Project?.ProjectType != null && project_Person_Role1.Project.ProjectType.IsTainted)
                    {
                        // Check if id has changed
                        if (project_Person_Role1Db.Project.ProjectType?.ProjectTypeId != project_Person_Role1.Project.ProjectType.ProjectTypeId && project_Person_Role1Db.Project.ProjectType?.ProjectTypeId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // project_Person_Role1Db.Project.ProjectType?.ProjectTypeId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        project_Person_Role1Db.Project.ProjectType.ProjectTypeName = project_Person_Role1.Project.ProjectType.ProjectTypeName; // Data field

                        if (project_Person_Role1Db.Project.ProjectType.ProjectTypeId != 0)
                        {
                            _ctx.Update(project_Person_Role1Db.Project.ProjectType);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            project_Person_Role1.Project.ProjectType.ProjectTypeId = project_Person_Role1Db.Project.ProjectType.ProjectTypeId;
                        }
                        project_Person_Role1.Project.ProjectType.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                    if (project_Person_Role1?.Person != null && project_Person_Role1.Person.IsDeleted)
                    {
                        _ctx.Person.Remove(project_Person_Role1Db.Person);
                    }
                    else if (project_Person_Role1?.Person != null && project_Person_Role1.Person.IsTainted)
                    {
                        // Check if id has changed
                        if (project_Person_Role1Db.Person?.PersonId != project_Person_Role1.Person.PersonId && project_Person_Role1Db.Person?.PersonId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // project_Person_Role1Db.Person?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        project_Person_Role1Db.Person.UserName = project_Person_Role1.Person.UserName; // Data field
                        project_Person_Role1Db.Person.Salary = project_Person_Role1.Person.Salary; // Data field
                        if (project_Person_Role1.Person != null && project_Person_Role1.Person.Department != null)
                            project_Person_Role1Db.Person.DepartmentId = project_Person_Role1.Person.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                        if (project_Person_Role1.Person != null && project_Person_Role1.Person.Gender != null)
                            project_Person_Role1Db.Person.GenderId = project_Person_Role1.Person.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                        project_Person_Role1Db.Person.ManagerId = project_Person_Role1.Person.Manager?.PersonId; // Nullable parent

                        if (project_Person_Role1Db.Person.PersonId != 0)
                        {
                            _ctx.Update(project_Person_Role1Db.Person);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            project_Person_Role1.Person.PersonId = project_Person_Role1Db.Person.PersonId;
                        }
                        project_Person_Role1.Person.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                    if (project_Person_Role1?.Person?.Department != null && project_Person_Role1.Person.Department.IsDeleted)
                    {
                        _ctx.Department.Remove(project_Person_Role1Db.Person.Department);
                    }
                    else if (project_Person_Role1?.Person?.Department != null && project_Person_Role1.Person.Department.IsTainted)
                    {
                        // Check if id has changed
                        if (project_Person_Role1Db.Person.Department?.DepartmentId != project_Person_Role1.Person.Department.DepartmentId && project_Person_Role1Db.Person.Department?.DepartmentId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // project_Person_Role1Db.Person.Department?.DepartmentId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        project_Person_Role1Db.Person.Department.DepartmentName = project_Person_Role1.Person.Department.DepartmentName; // Data field

                        if (project_Person_Role1Db.Person.Department.DepartmentId != 0)
                        {
                            _ctx.Update(project_Person_Role1Db.Person.Department);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            project_Person_Role1.Person.Department.DepartmentId = project_Person_Role1Db.Person.Department.DepartmentId;
                        }
                        project_Person_Role1.Person.Department.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                    if (project_Person_Role1?.Role != null && project_Person_Role1.Role.IsDeleted)
                    {
                        _ctx.Role.Remove(project_Person_Role1Db.Role);
                    }
                    else if (project_Person_Role1?.Role != null && project_Person_Role1.Role.IsTainted)
                    {
                        // Check if id has changed
                        if (project_Person_Role1Db.Role?.RoleId != project_Person_Role1.Role.RoleId && project_Person_Role1Db.Role?.RoleId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // project_Person_Role1Db.Role?.RoleId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        project_Person_Role1Db.Role.RoleName = project_Person_Role1.Role.RoleName; // Data field

                        if (project_Person_Role1Db.Role.RoleId != 0)
                        {
                            _ctx.Update(project_Person_Role1Db.Role);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            project_Person_Role1.Role.RoleId = project_Person_Role1Db.Role.RoleId;
                        }
                        project_Person_Role1.Role.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                }
            }

            // Before checking child
            if (person0 != null && person0.Clients != null)
            {
                foreach (var client1 in person0.Clients)
                {
                    var client1Db = person0Db.Clients.Where(p=>p.ClientId == client1.ClientId).SingleOrDefault();
                    if (client1Db == null && client1.IsDeleted != true)
                    {
                        client1Db = new EmptyProjectCore.Models.Client();
                        _ctx.Client.Add(client1Db);
                    }
                    // Above shall handle the fact that we have added a child

                    if (client1 != null && client1.IsDeleted)
                    {
                        _ctx.Client.Remove(client1Db);
                    }
                    else if (client1 != null && client1.IsTainted)
                    {
                        // Check if id has changed
                        if (client1Db?.ClientId != client1.ClientId && client1Db?.ClientId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // client1Db?.ClientId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        client1Db.ClientName = client1.ClientName; // Data field
                        if (client1 != null && client1.KeyAccountManager != null)
                            client1Db.PersonId = client1.KeyAccountManager.PersonId; // Non-nullable parent - if null, we shall not update...

                        if (client1Db.ClientId != 0)
                        {
                            _ctx.Update(client1Db);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            client1.ClientId = client1Db.ClientId;
                        }
                        client1.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                }
            }

        }

    }
}
