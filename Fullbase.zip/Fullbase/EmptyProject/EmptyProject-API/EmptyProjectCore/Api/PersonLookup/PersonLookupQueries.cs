
using EmptyProjectCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmptyProjectCore.Api.PersonLookup
{
    public class PersonLookupQueries
    {
        private ProjectContext _ctx { get; }

        public PersonLookupQueries(ProjectContext ctx)
        {
            _ctx = ctx;
        }


        /// <summary>
        /// Gets all data that is need to show the search criteria
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public PersonLookupFilterResponse GetFilter(PersonLookupFilterRequest request)
        {
            var retObj = new PersonLookupFilterResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            {
                var qDepartment0 = _ctx.Department
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Departments = qDepartment0.Select(p => retObj.Normalizer.LoadDepartment(p)).ToList();
            }
            {
                var qGender1 = _ctx.Gender
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Genders = qGender1.Select(p => retObj.Normalizer.LoadGender(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on search criteria, returns the search results.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public PersonLookupSearchResponse GetSearch(PersonLookupSearchRequest request)
        {
            var retObj = new PersonLookupSearchResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();
            {
                var qPerson0 = _ctx.Person
                    // Tree for Department (Parent)
                    .Include(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Gender)
                    // Tree for Manager (Parent)
                    .Include(p => p.Manager)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(request.QuickSearch))
                {
                    {
                        qPerson0 = qPerson0.Where(p =>
                        p.UserName.ToLower().Contains(request.QuickSearch.ToLower())
                        );
                    }
                }

                if (request.PersonId.ExactMatch.HasValue)
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.PersonId == request.PersonId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.UserName.ExactMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.UserName == request.UserName.ExactMatch
                    );
                }

                if (!string.IsNullOrEmpty(request.UserName.ContainsMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.UserName.Contains(request.UserName.ContainsMatch)
                    );
                }

                if (!string.IsNullOrEmpty(request.UserName.StartsWithMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.UserName.StartsWith(request.UserName.StartsWithMatch)
                    );
                }

                if (request.Salary.ExactMatch.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Salary == request.Salary.ExactMatch.Value
                    );
                }

                if (request.Salary.MoreThan.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Salary >= request.Salary.MoreThan.Value
                    );
                }

                if (request.Salary.LessThan.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Salary <= request.Salary.LessThan.Value
                    );
                }

                if (request.Department_DepartmentId.ExactMatch.HasValue)
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Department.DepartmentId == request.Department_DepartmentId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (request.Gender_GenderId.ExactMatch.HasValue)
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Gender.GenderId == request.Gender_GenderId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (request.Manager_PersonId.ExactMatch.HasValue)
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.PersonId == request.Manager_PersonId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (request.Manager_Salary.ExactMatch.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.Salary == request.Manager_Salary.ExactMatch.Value
                    );
                }

                if (request.Manager_Salary.MoreThan.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.Salary >= request.Manager_Salary.MoreThan.Value
                    );
                }

                if (request.Manager_Salary.LessThan.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.Salary <= request.Manager_Salary.LessThan.Value
                    );
                }

                //Add custom code here...
                retObj.Persons = qPerson0.Select(p => retObj.Normalizer.LoadPerson(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on selected item from search, gets the detail information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public PersonLookupDetailsResponse GetDetails(PersonLookupDetailsRequest request)
        {
            
            var retObj = new PersonLookupDetailsResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            if (request.Person.PersonId > 0)
            {
                var qPerson0 = _ctx.Person.Where(x => x.PersonId == request.Person.PersonId)
                    // Tree for Department (Parent)
                    .Include(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Gender)
                    // Tree for Department (Parent)
                    .Include(p => p.Manager)
                    .ThenInclude(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Manager)
                    .ThenInclude(p => p.Gender)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Person = retObj.Normalizer.LoadPerson(qPerson0);
            }
            else
            {
                retObj.Person = new PersonDto
                {
                    PersonId = -1
                };
            }
            {
                var qDepartment1 = _ctx.Department
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Departments = qDepartment1.Select(p => retObj.Normalizer.LoadDepartment(p)).ToList();
            }
            {
                var qGender2 = _ctx.Gender
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Genders = qGender2.Select(p => retObj.Normalizer.LoadGender(p)).ToList();
            }


            return retObj;
        }

        private PersonLookupDetailsResponseDb GetDetailsDb(PersonLookupDetailsRequest request)
        {
            
            var retObj = new PersonLookupDetailsResponseDb();

            {
                var qPerson0 = _ctx.Person.Where(x => x.PersonId == request.Person.PersonId)
                    // Tree for Department (Parent)
                    .Include(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Gender)
                    // Tree for Department (Parent)
                    .Include(p => p.Manager)
                    .ThenInclude(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Manager)
                    .ThenInclude(p => p.Gender)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Person = qPerson0;
            }
            {
                var qDepartment1 = _ctx.Department
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Departments = qDepartment1;
            }
            {
                var qGender2 = _ctx.Gender
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Genders = qGender2;
            }


            return retObj;
        }


        public void SaveDetails(PersonLookupDetailsResponse taintedResponse)
        {
            restart:
            var person0Db = GetDetailsDb(taintedResponse.Request).Person; // Get the same thing as request
            var person0 = taintedResponse.Person;


            if (person0Db == null)
            {
                // No row in db = insert!
                var d = new EmptyProjectCore.Models.Person();
                d.UserName = person0.UserName;
                d.Salary = person0.Salary;
                d.DepartmentId = person0.DepartmentId;
                d.GenderId = person0.GenderId;
                d.ManagerId = person0.ManagerId;

                _ctx.Person.Add(d);
                _ctx.SaveChanges();
                person0.PersonId = d.PersonId;
                goto restart;
            }




            if (person0 != null && person0.IsDeleted)
            {
                _ctx.Person.Remove(person0Db);
            }
            else if (person0 != null && person0.IsTainted)
            {
                // Check if id has changed
                if (person0Db?.PersonId != person0.PersonId && person0Db?.PersonId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.UserName = person0.UserName; // Data field
                person0Db.Salary = person0.Salary; // Data field
                if (person0 != null && person0.Department != null)
                    person0Db.DepartmentId = person0.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                if (person0 != null && person0.Gender != null)
                    person0Db.GenderId = person0.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                person0Db.ManagerId = person0.Manager?.PersonId; // Nullable parent

                if (person0Db.PersonId != 0)
                {
                    _ctx.Update(person0Db);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.PersonId = person0Db.PersonId;
                }
                person0.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Department != null && person0.Department.IsDeleted)
            {
                _ctx.Department.Remove(person0Db.Department);
            }
            else if (person0?.Department != null && person0.Department.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Department?.DepartmentId != person0.Department.DepartmentId && person0Db.Department?.DepartmentId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Department?.DepartmentId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Department.DepartmentName = person0.Department.DepartmentName; // Data field

                if (person0Db.Department.DepartmentId != 0)
                {
                    _ctx.Update(person0Db.Department);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Department.DepartmentId = person0Db.Department.DepartmentId;
                }
                person0.Department.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Gender != null && person0.Gender.IsDeleted)
            {
                _ctx.Gender.Remove(person0Db.Gender);
            }
            else if (person0?.Gender != null && person0.Gender.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Gender?.GenderId != person0.Gender.GenderId && person0Db.Gender?.GenderId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Gender?.GenderId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Gender.GenderDescription = person0.Gender.GenderDescription; // Data field

                if (person0Db.Gender.GenderId != 0)
                {
                    _ctx.Update(person0Db.Gender);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Gender.GenderId = person0Db.Gender.GenderId;
                }
                person0.Gender.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Manager != null && person0.Manager.IsDeleted)
            {
                _ctx.Person.Remove(person0Db.Manager);
            }
            else if (person0?.Manager != null && person0.Manager.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Manager?.PersonId != person0.Manager.PersonId && person0Db.Manager?.PersonId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Manager?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Manager.UserName = person0.Manager.UserName; // Data field
                person0Db.Manager.Salary = person0.Manager.Salary; // Data field
                if (person0.Manager != null && person0.Manager.Department != null)
                    person0Db.Manager.DepartmentId = person0.Manager.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                if (person0.Manager != null && person0.Manager.Gender != null)
                    person0Db.Manager.GenderId = person0.Manager.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                person0Db.Manager.ManagerId = person0.Manager.Manager?.PersonId; // Nullable parent

                if (person0Db.Manager.PersonId != 0)
                {
                    _ctx.Update(person0Db.Manager);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Manager.PersonId = person0Db.Manager.PersonId;
                }
                person0.Manager.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Manager?.Department != null && person0.Manager.Department.IsDeleted)
            {
                _ctx.Department.Remove(person0Db.Manager.Department);
            }
            else if (person0?.Manager?.Department != null && person0.Manager.Department.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Manager.Department?.DepartmentId != person0.Manager.Department.DepartmentId && person0Db.Manager.Department?.DepartmentId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Manager.Department?.DepartmentId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Manager.Department.DepartmentName = person0.Manager.Department.DepartmentName; // Data field

                if (person0Db.Manager.Department.DepartmentId != 0)
                {
                    _ctx.Update(person0Db.Manager.Department);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Manager.Department.DepartmentId = person0Db.Manager.Department.DepartmentId;
                }
                person0.Manager.Department.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Manager?.Gender != null && person0.Manager.Gender.IsDeleted)
            {
                _ctx.Gender.Remove(person0Db.Manager.Gender);
            }
            else if (person0?.Manager?.Gender != null && person0.Manager.Gender.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Manager.Gender?.GenderId != person0.Manager.Gender.GenderId && person0Db.Manager.Gender?.GenderId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Manager.Gender?.GenderId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Manager.Gender.GenderDescription = person0.Manager.Gender.GenderDescription; // Data field

                if (person0Db.Manager.Gender.GenderId != 0)
                {
                    _ctx.Update(person0Db.Manager.Gender);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Manager.Gender.GenderId = person0Db.Manager.Gender.GenderId;
                }
                person0.Manager.Gender.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

        }

    }
}
