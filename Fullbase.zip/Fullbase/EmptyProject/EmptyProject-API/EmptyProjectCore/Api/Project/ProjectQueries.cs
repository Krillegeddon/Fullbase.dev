
using EmptyProjectCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmptyProjectCore.Api.Project
{
    public class ProjectQueries
    {
        private ProjectContext _ctx { get; }

        public ProjectQueries(ProjectContext ctx)
        {
            _ctx = ctx;
        }


        /// <summary>
        /// Gets all data that is need to show the search criteria
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ProjectFilterResponse GetFilter(ProjectFilterRequest request)
        {
            var retObj = new ProjectFilterResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            {
                var qProjectType0 = _ctx.ProjectType
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.ProjectTypes = qProjectType0.Select(p => retObj.Normalizer.LoadProjectType(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on search criteria, returns the search results.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ProjectSearchResponse GetSearch(ProjectSearchRequest request)
        {
            var retObj = new ProjectSearchResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();
            {
                var qProject0 = _ctx.Project
                    // Tree for ProjectType (Parent)
                    .Include(p => p.ProjectType)
                    // Tree for ViewProjectAug (Parent)
                    .Include(p => p.ViewProjectAug)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(request.QuickSearch))
                {
                    {
                        qProject0 = qProject0.Where(p =>
                        p.ProjectName.ToLower().Contains(request.QuickSearch.ToLower())
                        );
                    }
                }

                if (request.ProjectId.ExactMatch.HasValue)
                {
                    qProject0 = qProject0.Where(p =>
                                p.ProjectId == request.ProjectId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.ProjectName.ExactMatch)) // One field, string
                {
                    qProject0 = qProject0.Where(p =>
                                p.ProjectName == request.ProjectName.ExactMatch
                    );
                }

                if (request.IsProBono.ExactMatch.HasValue) // One field, non-string
                {
                    qProject0 = qProject0.Where(p =>
                                p.IsProBono == request.IsProBono.ExactMatch.Value
                    );
                }

                if (request.Deadline.ExactMatch.HasValue) // One field, non-string
                {
                    qProject0 = qProject0.Where(p =>
                                p.Deadline == request.Deadline.ExactMatch.Value
                    );
                }

                if (request.ProjectType_ProjectTypeId.ExactMatch.HasValue)
                {
                    qProject0 = qProject0.Where(p =>
                                p.ProjectType.ProjectTypeId == request.ProjectType_ProjectTypeId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (request.ViewProjectAug_ProjectId.ExactMatch.HasValue)
                {
                    qProject0 = qProject0.Where(p =>
                                p.ViewProjectAug.ProjectId == request.ViewProjectAug_ProjectId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (request.ViewProjectAug_TempNum.ExactMatch.HasValue) // One field, non-string
                {
                    qProject0 = qProject0.Where(p =>
                                p.ViewProjectAug.TempNum == request.ViewProjectAug_TempNum.ExactMatch.Value
                    );
                }

                if (request.ViewProjectAug_Quadruple.ExactMatch.HasValue) // One field, non-string
                {
                    qProject0 = qProject0.Where(p =>
                                p.ViewProjectAug.Quadruple == request.ViewProjectAug_Quadruple.ExactMatch.Value
                    );
                }

                //Add custom code here...
                qPerson0 = qPerson0.Where(p => p.Department.DepartmentName == "Department A");
                
                
                retObj.Projects = qProject0.Select(p => retObj.Normalizer.LoadProject(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on selected item from search, gets the detail information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ProjectDetailsResponse GetDetails(ProjectDetailsRequest request)
        {
            
            var retObj = new ProjectDetailsResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            if (request.Project.ProjectId > 0)
            {
                var qProject0 = _ctx.Project.Where(x => x.ProjectId == request.Project.ProjectId)
                    // Tree for ProjectType (Parent)
                    .Include(p => p.ProjectType)
                    // Tree for ViewProjectAug (Parent)
                    .Include(p => p.ViewProjectAug)
                    // Tree for Department (Parent)
                    .Include(p => p.Project_Person_Roles)
                    .ThenInclude(p => p.Person)
                    .ThenInclude(p => p.Department)
                    // Tree for Role (Parent)
                    .Include(p => p.Project_Person_Roles)
                    .ThenInclude(p => p.Role)
                    // Tree for KeyAccountManager (Parent)
                    .Include(p => p.Project_Clients)
                    .ThenInclude(p => p.Client)
                    .ThenInclude(p => p.KeyAccountManager)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Project = retObj.Normalizer.LoadProject(qProject0);
            }
            else
            {
                retObj.Project = new ProjectDto
                {
                    ProjectId = -1
                };
            }
            {
                var qGender1 = _ctx.Gender
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Genders = qGender1.Select(p => retObj.Normalizer.LoadGender(p)).ToList();
            }
            {
                var qProjectType2 = _ctx.ProjectType
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.ProjectTypes = qProjectType2.Select(p => retObj.Normalizer.LoadProjectType(p)).ToList();
            }
            {
                var qDepartment3 = _ctx.Department
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Departments = qDepartment3.Select(p => retObj.Normalizer.LoadDepartment(p)).ToList();
            }
            {
                var qRole4 = _ctx.Role
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Roles = qRole4.Select(p => retObj.Normalizer.LoadRole(p)).ToList();
            }


            return retObj;
        }

        private ProjectDetailsResponseDb GetDetailsDb(ProjectDetailsRequest request)
        {
            
            var retObj = new ProjectDetailsResponseDb();

            {
                var qProject0 = _ctx.Project.Where(x => x.ProjectId == request.Project.ProjectId)
                    // Tree for ProjectType (Parent)
                    .Include(p => p.ProjectType)
                    // Tree for ViewProjectAug (Parent)
                    .Include(p => p.ViewProjectAug)
                    // Tree for Department (Parent)
                    .Include(p => p.Project_Person_Roles)
                    .ThenInclude(p => p.Person)
                    .ThenInclude(p => p.Department)
                    // Tree for Role (Parent)
                    .Include(p => p.Project_Person_Roles)
                    .ThenInclude(p => p.Role)
                    // Tree for KeyAccountManager (Parent)
                    .Include(p => p.Project_Clients)
                    .ThenInclude(p => p.Client)
                    .ThenInclude(p => p.KeyAccountManager)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Project = qProject0;
            }
            {
                var qGender1 = _ctx.Gender
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Genders = qGender1;
            }
            {
                var qProjectType2 = _ctx.ProjectType
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.ProjectTypes = qProjectType2;
            }
            {
                var qDepartment3 = _ctx.Department
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Departments = qDepartment3;
            }
            {
                var qRole4 = _ctx.Role
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Roles = qRole4;
            }


            return retObj;
        }


        public void SaveDetails(ProjectDetailsResponse taintedResponse)
        {
            restart:
            var project0Db = GetDetailsDb(taintedResponse.Request).Project; // Get the same thing as request
            var project0 = taintedResponse.Project;


            if (project0Db == null)
            {
                // No row in db = insert!
                var d = new EmptyProjectCore.Models.Project();
                d.ProjectName = project0.ProjectName;
                d.IsProBono = project0.IsProBono;
                d.Deadline = project0.Deadline;
                d.ProjectTypeId = project0.ProjectTypeId;

                _ctx.Project.Add(d);
                _ctx.SaveChanges();
                project0.ProjectId = d.ProjectId;
                goto restart;
            }




            if (project0 != null && project0.IsDeleted)
            {
                _ctx.Project.Remove(project0Db);
            }
            else if (project0 != null && project0.IsTainted)
            {
                // Check if id has changed
                if (project0Db?.ProjectId != project0.ProjectId && project0Db?.ProjectId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project0Db?.ProjectId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project0Db.ProjectName = project0.ProjectName; // Data field
                project0Db.IsProBono = project0.IsProBono; // Data field
                project0Db.Deadline = project0.Deadline; // Data field
                if (project0 != null && project0.ProjectType != null)
                    project0Db.ProjectTypeId = project0.ProjectType.ProjectTypeId; // Non-nullable parent - if null, we shall not update...

                if (project0Db.ProjectId != 0)
                {
                    _ctx.Update(project0Db);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project0.ProjectId = project0Db.ProjectId;
                }
                project0.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (project0?.ProjectType != null && project0.ProjectType.IsDeleted)
            {
                _ctx.ProjectType.Remove(project0Db.ProjectType);
            }
            else if (project0?.ProjectType != null && project0.ProjectType.IsTainted)
            {
                // Check if id has changed
                if (project0Db.ProjectType?.ProjectTypeId != project0.ProjectType.ProjectTypeId && project0Db.ProjectType?.ProjectTypeId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project0Db.ProjectType?.ProjectTypeId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project0Db.ProjectType.ProjectTypeName = project0.ProjectType.ProjectTypeName; // Data field

                if (project0Db.ProjectType.ProjectTypeId != 0)
                {
                    _ctx.Update(project0Db.ProjectType);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project0.ProjectType.ProjectTypeId = project0Db.ProjectType.ProjectTypeId;
                }
                project0.ProjectType.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            // This object ViewProjectAug is a view - hence, no save method.

            // Before checking child
            if (project0 != null && project0.Project_Person_Roles != null)
            {
                foreach (var project_Person_Role1 in project0.Project_Person_Roles)
                {
                    var project_Person_Role1Db = project0Db.Project_Person_Roles.Where(p=>p.Project_Person_RoleId == project_Person_Role1.Project_Person_RoleId).SingleOrDefault();
                    if (project_Person_Role1Db == null && project_Person_Role1.IsDeleted != true)
                    {
                        project_Person_Role1Db = new EmptyProjectCore.Models.Project_Person_Role();
                        _ctx.Project_Person_Role.Add(project_Person_Role1Db);
                    }
                    // Above shall handle the fact that we have added a child

                    if (project_Person_Role1 != null && project_Person_Role1.IsDeleted)
                    {
                        _ctx.Project_Person_Role.Remove(project_Person_Role1Db);
                    }
                    else if (project_Person_Role1 != null && project_Person_Role1.IsTainted)
                    {
                        // Check if id has changed
                        if (project_Person_Role1Db?.Project_Person_RoleId != project_Person_Role1.Project_Person_RoleId && project_Person_Role1Db?.Project_Person_RoleId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // project_Person_Role1Db?.Project_Person_RoleId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        if (project_Person_Role1 != null && project_Person_Role1.Person != null)
                            project_Person_Role1Db.PersonId = project_Person_Role1.Person.PersonId; // Non-nullable parent - if null, we shall not update...
                        if (project_Person_Role1 != null && project_Person_Role1.Project != null)
                            project_Person_Role1Db.ProjectId = project_Person_Role1.Project.ProjectId; // Non-nullable parent - if null, we shall not update...
                        if (project_Person_Role1 != null && project_Person_Role1.Role != null)
                            project_Person_Role1Db.RoleId = project_Person_Role1.Role.RoleId; // Non-nullable parent - if null, we shall not update...

                        if (project_Person_Role1Db.Project_Person_RoleId != 0)
                        {
                            _ctx.Update(project_Person_Role1Db);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            project_Person_Role1.Project_Person_RoleId = project_Person_Role1Db.Project_Person_RoleId;
                        }
                        project_Person_Role1.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                    if (project_Person_Role1?.Person != null && project_Person_Role1.Person.IsDeleted)
                    {
                        _ctx.Person.Remove(project_Person_Role1Db.Person);
                    }
                    else if (project_Person_Role1?.Person != null && project_Person_Role1.Person.IsTainted)
                    {
                        // Check if id has changed
                        if (project_Person_Role1Db.Person?.PersonId != project_Person_Role1.Person.PersonId && project_Person_Role1Db.Person?.PersonId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // project_Person_Role1Db.Person?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        project_Person_Role1Db.Person.UserName = project_Person_Role1.Person.UserName; // Data field
                        project_Person_Role1Db.Person.Salary = project_Person_Role1.Person.Salary; // Data field
                        if (project_Person_Role1.Person != null && project_Person_Role1.Person.Department != null)
                            project_Person_Role1Db.Person.DepartmentId = project_Person_Role1.Person.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                        if (project_Person_Role1.Person != null && project_Person_Role1.Person.Gender != null)
                            project_Person_Role1Db.Person.GenderId = project_Person_Role1.Person.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                        project_Person_Role1Db.Person.ManagerId = project_Person_Role1.Person.Manager?.PersonId; // Nullable parent

                        if (project_Person_Role1Db.Person.PersonId != 0)
                        {
                            _ctx.Update(project_Person_Role1Db.Person);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            project_Person_Role1.Person.PersonId = project_Person_Role1Db.Person.PersonId;
                        }
                        project_Person_Role1.Person.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                    if (project_Person_Role1?.Person?.Department != null && project_Person_Role1.Person.Department.IsDeleted)
                    {
                        _ctx.Department.Remove(project_Person_Role1Db.Person.Department);
                    }
                    else if (project_Person_Role1?.Person?.Department != null && project_Person_Role1.Person.Department.IsTainted)
                    {
                        // Check if id has changed
                        if (project_Person_Role1Db.Person.Department?.DepartmentId != project_Person_Role1.Person.Department.DepartmentId && project_Person_Role1Db.Person.Department?.DepartmentId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // project_Person_Role1Db.Person.Department?.DepartmentId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        project_Person_Role1Db.Person.Department.DepartmentName = project_Person_Role1.Person.Department.DepartmentName; // Data field

                        if (project_Person_Role1Db.Person.Department.DepartmentId != 0)
                        {
                            _ctx.Update(project_Person_Role1Db.Person.Department);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            project_Person_Role1.Person.Department.DepartmentId = project_Person_Role1Db.Person.Department.DepartmentId;
                        }
                        project_Person_Role1.Person.Department.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                    if (project_Person_Role1?.Role != null && project_Person_Role1.Role.IsDeleted)
                    {
                        _ctx.Role.Remove(project_Person_Role1Db.Role);
                    }
                    else if (project_Person_Role1?.Role != null && project_Person_Role1.Role.IsTainted)
                    {
                        // Check if id has changed
                        if (project_Person_Role1Db.Role?.RoleId != project_Person_Role1.Role.RoleId && project_Person_Role1Db.Role?.RoleId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // project_Person_Role1Db.Role?.RoleId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        project_Person_Role1Db.Role.RoleName = project_Person_Role1.Role.RoleName; // Data field

                        if (project_Person_Role1Db.Role.RoleId != 0)
                        {
                            _ctx.Update(project_Person_Role1Db.Role);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            project_Person_Role1.Role.RoleId = project_Person_Role1Db.Role.RoleId;
                        }
                        project_Person_Role1.Role.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                }
            }

            // Before checking child
            if (project0 != null && project0.Project_Clients != null)
            {
                foreach (var project_Client1 in project0.Project_Clients)
                {
                    var project_Client1Db = project0Db.Project_Clients.Where(p=>p.Project_ClientId == project_Client1.Project_ClientId).SingleOrDefault();
                    if (project_Client1Db == null && project_Client1.IsDeleted != true)
                    {
                        project_Client1Db = new EmptyProjectCore.Models.Project_Client();
                        _ctx.Project_Client.Add(project_Client1Db);
                    }
                    // Above shall handle the fact that we have added a child

                    if (project_Client1 != null && project_Client1.IsDeleted)
                    {
                        _ctx.Project_Client.Remove(project_Client1Db);
                    }
                    else if (project_Client1 != null && project_Client1.IsTainted)
                    {
                        // Check if id has changed
                        if (project_Client1Db?.Project_ClientId != project_Client1.Project_ClientId && project_Client1Db?.Project_ClientId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // project_Client1Db?.Project_ClientId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        if (project_Client1 != null && project_Client1.Project != null)
                            project_Client1Db.ProjectId = project_Client1.Project.ProjectId; // Non-nullable parent - if null, we shall not update...
                        if (project_Client1 != null && project_Client1.Client != null)
                            project_Client1Db.ClientId = project_Client1.Client.ClientId; // Non-nullable parent - if null, we shall not update...

                        if (project_Client1Db.Project_ClientId != 0)
                        {
                            _ctx.Update(project_Client1Db);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            project_Client1.Project_ClientId = project_Client1Db.Project_ClientId;
                        }
                        project_Client1.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                    if (project_Client1?.Client != null && project_Client1.Client.IsDeleted)
                    {
                        _ctx.Client.Remove(project_Client1Db.Client);
                    }
                    else if (project_Client1?.Client != null && project_Client1.Client.IsTainted)
                    {
                        // Check if id has changed
                        if (project_Client1Db.Client?.ClientId != project_Client1.Client.ClientId && project_Client1Db.Client?.ClientId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // project_Client1Db.Client?.ClientId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        project_Client1Db.Client.ClientName = project_Client1.Client.ClientName; // Data field
                        if (project_Client1.Client != null && project_Client1.Client.KeyAccountManager != null)
                            project_Client1Db.Client.PersonId = project_Client1.Client.KeyAccountManager.PersonId; // Non-nullable parent - if null, we shall not update...

                        if (project_Client1Db.Client.ClientId != 0)
                        {
                            _ctx.Update(project_Client1Db.Client);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            project_Client1.Client.ClientId = project_Client1Db.Client.ClientId;
                        }
                        project_Client1.Client.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                    if (project_Client1?.Client?.KeyAccountManager != null && project_Client1.Client.KeyAccountManager.IsDeleted)
                    {
                        _ctx.Person.Remove(project_Client1Db.Client.KeyAccountManager);
                    }
                    else if (project_Client1?.Client?.KeyAccountManager != null && project_Client1.Client.KeyAccountManager.IsTainted)
                    {
                        // Check if id has changed
                        if (project_Client1Db.Client.KeyAccountManager?.PersonId != project_Client1.Client.KeyAccountManager.PersonId && project_Client1Db.Client.KeyAccountManager?.PersonId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // project_Client1Db.Client.KeyAccountManager?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        project_Client1Db.Client.KeyAccountManager.UserName = project_Client1.Client.KeyAccountManager.UserName; // Data field
                        project_Client1Db.Client.KeyAccountManager.Salary = project_Client1.Client.KeyAccountManager.Salary; // Data field
                        if (project_Client1.Client.KeyAccountManager != null && project_Client1.Client.KeyAccountManager.Department != null)
                            project_Client1Db.Client.KeyAccountManager.DepartmentId = project_Client1.Client.KeyAccountManager.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                        if (project_Client1.Client.KeyAccountManager != null && project_Client1.Client.KeyAccountManager.Gender != null)
                            project_Client1Db.Client.KeyAccountManager.GenderId = project_Client1.Client.KeyAccountManager.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                        project_Client1Db.Client.KeyAccountManager.ManagerId = project_Client1.Client.KeyAccountManager.Manager?.PersonId; // Nullable parent

                        if (project_Client1Db.Client.KeyAccountManager.PersonId != 0)
                        {
                            _ctx.Update(project_Client1Db.Client.KeyAccountManager);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            project_Client1.Client.KeyAccountManager.PersonId = project_Client1Db.Client.KeyAccountManager.PersonId;
                        }
                        project_Client1.Client.KeyAccountManager.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                }
            }

        }

    }
}
