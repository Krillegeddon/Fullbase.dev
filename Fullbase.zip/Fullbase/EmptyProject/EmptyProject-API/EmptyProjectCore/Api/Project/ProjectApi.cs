
using EmptyProjectCore.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace EmptyProjectCore.Api.Project
{

    public partial class ProjectFilterRequestExtraObject
    {
    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    public partial class ProjectFilterRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public ProjectFilterRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class ProjectFilterResponseExtraObject
    {
    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    public partial class ProjectFilterResponse : TransferBase
    {
        // Properties to be transfered

        public List<ProjectTypeDto> ProjectTypes { get; set; }

        public ProjectFilterRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ProjectFilterResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0; i < ProjectTypes?.Count; i++)
            {
                var x = ProjectTypes[i];
                var projectTypeKey = "ProjectType_" + x.ProjectTypeId;
                var possibleProjectType = normalizer.DtoObjects.Where(p => p.Key == projectTypeKey).SingleOrDefault();
                if (possibleProjectType != null)
                    ProjectTypes[i] = (ProjectTypeDto) possibleProjectType.Object;
                else
                    Normalizer.NormalizeProjectType(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < ProjectTypes?.Count; i++)
            {
                this.ProjectTypes[i] = Normalizer.DenormalizeProjectType(ProjectTypes[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class ProjectSearchRequestExtraObject
    {
    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    public partial class ProjectSearchRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public ProjectSearchRequestExtraObject ExtraObject { get; set; }

        public string QuickSearch { get; set; }

        public IntClause ProjectId { get; set; }

        public StringClause ProjectName { get; set; }

        public BoolClause IsProBono { get; set; }

        public DateTimeClause Deadline { get; set; }

        public IntClause ProjectType_ProjectTypeId { get; set; }

        public StringClause ProjectType_ProjectTypeName { get; set; }

        public IntClause ViewProjectAug_ProjectId { get; set; }

        public IntClause ViewProjectAug_TempNum { get; set; }

        public IntClause ViewProjectAug_Quadruple { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class ProjectSearchResponseExtraObject
    {
    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    public partial class ProjectSearchResponse : TransferBase
    {
        // Properties to be transfered

        public List<ProjectDto> Projects { get; set; }

        public ProjectSearchRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ProjectSearchResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0; i < Projects?.Count; i++)
            {
                var x = Projects[i];
                var projectKey = "Project_" + x.ProjectId;
                var possibleProject = normalizer.DtoObjects.Where(p => p.Key == projectKey).SingleOrDefault();
                if (possibleProject != null)
                    Projects[i] = (ProjectDto) possibleProject.Object;
                else
                    Normalizer.NormalizeProject(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < Projects?.Count; i++)
            {
                this.Projects[i] = Normalizer.DenormalizeProject(Projects[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class ProjectDetailsRequestExtraObject
    {
    }

    /// <summary>
    /// Detail request, basically one item from the AugView Project, that user clicked after search was performed.
    /// </summary>
    public partial class ProjectDetailsRequest : TransferBase
    {
        // Properties to be transfered

        public ProjectDto Project { get; set; }


        // Custom properties, not to be transfered
        public ProjectDetailsRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var projectKey = "Project_" + Project.ProjectId;
                var possibleProject = normalizer.DtoObjects.Where(p => p.Key == projectKey).SingleOrDefault();
                if (possibleProject != null)
                    Project = (ProjectDto)possibleProject.Object;
                else
                    Normalizer.NormalizeProject(Project);
            }

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Project = Normalizer.DenormalizeProject(Project);

        }


    }

    public partial class ProjectDetailsResponseExtraObject
    {
    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    public partial class ProjectDetailsResponse : TransferBase
    {
        // Properties to be transfered

        public ProjectDto Project { get; set; }

        public List<GenderDto> Genders { get; set; }

        public List<ProjectTypeDto> ProjectTypes { get; set; }

        public List<DepartmentDto> Departments { get; set; }

        public List<RoleDto> Roles { get; set; }

        public ProjectDetailsRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ProjectDetailsResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var projectKey = "Project_" + Project.ProjectId;
                var possibleProject = normalizer.DtoObjects.Where(p => p.Key == projectKey).SingleOrDefault();
                if (possibleProject != null)
                    Project = (ProjectDto)possibleProject.Object;
                else
                    Normalizer.NormalizeProject(Project);
            }

            for (int i = 0; i < Genders?.Count; i++)
            {
                var x = Genders[i];
                var genderKey = "Gender_" + x.GenderId;
                var possibleGender = normalizer.DtoObjects.Where(p => p.Key == genderKey).SingleOrDefault();
                if (possibleGender != null)
                    Genders[i] = (GenderDto) possibleGender.Object;
                else
                    Normalizer.NormalizeGender(x); ;
            }

            for (int i = 0; i < ProjectTypes?.Count; i++)
            {
                var x = ProjectTypes[i];
                var projectTypeKey = "ProjectType_" + x.ProjectTypeId;
                var possibleProjectType = normalizer.DtoObjects.Where(p => p.Key == projectTypeKey).SingleOrDefault();
                if (possibleProjectType != null)
                    ProjectTypes[i] = (ProjectTypeDto) possibleProjectType.Object;
                else
                    Normalizer.NormalizeProjectType(x); ;
            }

            for (int i = 0; i < Departments?.Count; i++)
            {
                var x = Departments[i];
                var departmentKey = "Department_" + x.DepartmentId;
                var possibleDepartment = normalizer.DtoObjects.Where(p => p.Key == departmentKey).SingleOrDefault();
                if (possibleDepartment != null)
                    Departments[i] = (DepartmentDto) possibleDepartment.Object;
                else
                    Normalizer.NormalizeDepartment(x); ;
            }

            for (int i = 0; i < Roles?.Count; i++)
            {
                var x = Roles[i];
                var roleKey = "Role_" + x.RoleId;
                var possibleRole = normalizer.DtoObjects.Where(p => p.Key == roleKey).SingleOrDefault();
                if (possibleRole != null)
                    Roles[i] = (RoleDto) possibleRole.Object;
                else
                    Normalizer.NormalizeRole(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Project = Normalizer.DenormalizeProject(Project);

            for (int i = 0; i < Genders?.Count; i++)
            {
                this.Genders[i] = Normalizer.DenormalizeGender(Genders[i]);
            }

            for (int i = 0; i < ProjectTypes?.Count; i++)
            {
                this.ProjectTypes[i] = Normalizer.DenormalizeProjectType(ProjectTypes[i]);
            }

            for (int i = 0; i < Departments?.Count; i++)
            {
                this.Departments[i] = Normalizer.DenormalizeDepartment(Departments[i]);
            }

            for (int i = 0; i < Roles?.Count; i++)
            {
                this.Roles[i] = Normalizer.DenormalizeRole(Roles[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    /// <summary>
    /// Details response - internal DB representation of Details.
    /// </summary>
    public class ProjectDetailsResponseDb
    {
        // Properties in db class

        public Models.Project Project { get; set; }

        public List<Models.Gender> Genders { get; set; }

        public List<Models.ProjectType> ProjectTypes { get; set; }

        public List<Models.Department> Departments { get; set; }

        public List<Models.Role> Roles { get; set; }


        // Custom properties, not to be transfered

    }

}
