
using EmptyProjectCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmptyProjectCore.Api.ClientLookup
{
    public class ClientLookupQueries
    {
        private ProjectContext _ctx { get; }

        public ClientLookupQueries(ProjectContext ctx)
        {
            _ctx = ctx;
        }



            /// <summary>
            /// Based on search criteria, returns the search results.
            /// </summary>
            /// <param name="request"></param>
            /// <returns></returns>
            public ClientLookupSearchResponse GetSearch(ClientLookupSearchRequest request)
            {
                var retObj = new ClientLookupSearchResponse();
                retObj.Normalizer = new Normalizer();
                retObj.Normalizer.DtoObjects = new List<NormKey>();
            var qClient0 = _ctx.Client
                  // Tree for Gender (Parent)
                  .Include(p => p.KeyAccountManager)
                  .ThenInclude(p => p.Gender)
                  // Tree for Department (Parent)
                  .Include(p => p.KeyAccountManager)
                  .ThenInclude(p => p.Department)
                .AsQueryable();

                if (!string.IsNullOrEmpty(request.QuickSearch))
                {
                    {
                        qClient0 = qClient0.Where( p =>
                        p.ClientName.ToLower().Contains(request.QuickSearch.ToLower()) ||
                        p.KeyAccountManager.UserName.ToLower().Contains(request.QuickSearch.ToLower()) ||
                        p.KeyAccountManager.Gender.GenderDescription.ToLower().Contains(request.QuickSearch.ToLower()) ||
                        p.KeyAccountManager.Department.DepartmentName.ToLower().Contains(request.QuickSearch.ToLower())
                        );
                    }
                }

                        if (request.ClientId.ExactMatch.HasValue)
                        {
                            qClient0 = qClient0.Where(p =>
                                       p.ClientId == request.ClientId.ExactMatch.Value  // Foreign key search
                            );
                        }

                        if (!string.IsNullOrEmpty(request.ClientName.ExactMatch)) // One field, string
                        {
                            qClient0 = qClient0.Where(p =>
                                       p.ClientName == request.ClientName.ExactMatch
                            );
                        }

                        if (request.KeyAccountManager_PersonId.ExactMatch.HasValue)
                        {
                            qClient0 = qClient0.Where(p =>
                                       p.KeyAccountManager.PersonId == request.KeyAccountManager_PersonId.ExactMatch.Value  // Foreign key search
                            );
                        }

                        if (!string.IsNullOrEmpty(request.KeyAccountManager_UserName.ExactMatch)) // One field, string
                        {
                            qClient0 = qClient0.Where(p =>
                                       p.KeyAccountManager.UserName == request.KeyAccountManager_UserName.ExactMatch
                            );
                        }

                        if (request.KeyAccountManager_Salary.ExactMatch.HasValue) // One field, non-string
                        {
                            qClient0 = qClient0.Where(p =>
                                       p.KeyAccountManager.Salary == request.KeyAccountManager_Salary.ExactMatch.Value
                            );
                        }

                        if (request.KeyAccountManager_Gender_GenderId.ExactMatch.HasValue)
                        {
                            qClient0 = qClient0.Where(p =>
                                       p.KeyAccountManager.Gender.GenderId == request.KeyAccountManager_Gender_GenderId.ExactMatch.Value  // Foreign key search
                            );
                        }

                        if (!string.IsNullOrEmpty(request.KeyAccountManager_Gender_GenderDescription.ExactMatch)) // One field, string
                        {
                            qClient0 = qClient0.Where(p =>
                                       p.KeyAccountManager.Gender.GenderDescription == request.KeyAccountManager_Gender_GenderDescription.ExactMatch
                            );
                        }

                        if (request.KeyAccountManager_Department_DepartmentId.ExactMatch.HasValue)
                        {
                            qClient0 = qClient0.Where(p =>
                                       p.KeyAccountManager.Department.DepartmentId == request.KeyAccountManager_Department_DepartmentId.ExactMatch.Value  // Foreign key search
                            );
                        }

                        if (!string.IsNullOrEmpty(request.KeyAccountManager_Department_DepartmentName.ExactMatch)) // One field, string
                        {
                            qClient0 = qClient0.Where(p =>
                                       p.KeyAccountManager.Department.DepartmentName == request.KeyAccountManager_Department_DepartmentName.ExactMatch
                            );
                        }

            retObj.Clients = qClient0.Select(p => retObj.Normalizer.LoadClient(p)).ToList();



            return retObj;
            }


        /// <summary>
        /// Based on selected item from search, gets the detail information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ClientLookupDetailsResponse GetDetails(ClientLookupDetailsRequest request)
        {
            
            var retObj = new ClientLookupDetailsResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

if (request.Client.ClientId > 0) {
            var qClient0 = _ctx.Client.Where(x => x.ClientId == request.Client.ClientId)
                  // Tree for Gender (Parent)
                  .Include(p => p.KeyAccountManager)
                  .ThenInclude(p => p.Gender)
                  // Tree for Department (Parent)
                  .Include(p => p.KeyAccountManager)
                  .ThenInclude(p => p.Department)
                  .FirstOrDefault();

            retObj.Client = retObj.Normalizer.LoadClient(qClient0);


            }
            else
            {
                retObj.Client = new ClientDto
                {
                    ClientId = -1
                };
            }

            return retObj;
        }

        private ClientLookupDetailsResponseDb GetDetailsDb(ClientLookupDetailsRequest request)
        {
            
            var retObj = new ClientLookupDetailsResponseDb();

            var qClient0 = _ctx.Client.Where(x => x.ClientId == request.Client.ClientId)
                  // Tree for Gender (Parent)
                  .Include(p => p.KeyAccountManager)
                  .ThenInclude(p => p.Gender)
                  // Tree for Department (Parent)
                  .Include(p => p.KeyAccountManager)
                  .ThenInclude(p => p.Department)
                  .FirstOrDefault();

            retObj.Client = qClient0;



            return retObj;
        }


        public void SaveDetails(ClientLookupDetailsResponse taintedResponse)
        {
            restart:
            var client0Db = GetDetailsDb(taintedResponse.Request).Client; // Get the same thing as request
            var client0 = taintedResponse.Client;


            if (client0Db == null)
            {
                // No row in db = insert!
                var d = new EmptyProjectCore.Models.Client();
                d.ClientName = client0.ClientName;
                d.PersonId = client0.PersonId;

                _ctx.Client.Add(d);
                _ctx.SaveChanges();
                client0.ClientId = d.ClientId;
                goto restart;
            }




            if (client0 != null && client0.IsDeleted)
            {
                _ctx.Client.Remove(client0Db);
            }
            else if (client0 != null && client0.IsTainted)
            {
                // Check if id has changed
                if (client0Db?.ClientId != client0.ClientId && client0Db?.ClientId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // client0Db?.ClientId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                client0Db.ClientName = client0.ClientName; // Data field
                if (client0 != null && client0.KeyAccountManager != null)
                    client0Db.PersonId = client0.KeyAccountManager.PersonId; // Non-nullable parent - if null, we shall not update...

                if (client0Db.ClientId != 0)
                {
                    _ctx.Update(client0Db);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    client0.ClientId = client0Db.ClientId;
                }
                client0.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (client0?.KeyAccountManager != null && client0.KeyAccountManager.IsDeleted)
            {
                _ctx.Person.Remove(client0Db.KeyAccountManager);
            }
            else if (client0?.KeyAccountManager != null && client0.KeyAccountManager.IsTainted)
            {
                // Check if id has changed
                if (client0Db.KeyAccountManager?.PersonId != client0.KeyAccountManager.PersonId && client0Db.KeyAccountManager?.PersonId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // client0Db.KeyAccountManager?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                client0Db.KeyAccountManager.UserName = client0.KeyAccountManager.UserName; // Data field
                client0Db.KeyAccountManager.Salary = client0.KeyAccountManager.Salary; // Data field
                if (client0.KeyAccountManager != null && client0.KeyAccountManager.Department != null)
                    client0Db.KeyAccountManager.DepartmentId = client0.KeyAccountManager.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                if (client0.KeyAccountManager != null && client0.KeyAccountManager.Gender != null)
                    client0Db.KeyAccountManager.GenderId = client0.KeyAccountManager.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                client0Db.KeyAccountManager.ManagerId = client0.KeyAccountManager.Manager?.PersonId; // Nullable parent

                if (client0Db.KeyAccountManager.PersonId != 0)
                {
                    _ctx.Update(client0Db.KeyAccountManager);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    client0.KeyAccountManager.PersonId = client0Db.KeyAccountManager.PersonId;
                }
                client0.KeyAccountManager.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (client0?.KeyAccountManager?.Gender != null && client0.KeyAccountManager.Gender.IsDeleted)
            {
                _ctx.Gender.Remove(client0Db.KeyAccountManager.Gender);
            }
            else if (client0?.KeyAccountManager?.Gender != null && client0.KeyAccountManager.Gender.IsTainted)
            {
                // Check if id has changed
                if (client0Db.KeyAccountManager.Gender?.GenderId != client0.KeyAccountManager.Gender.GenderId && client0Db.KeyAccountManager.Gender?.GenderId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // client0Db.KeyAccountManager.Gender?.GenderId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                client0Db.KeyAccountManager.Gender.GenderDescription = client0.KeyAccountManager.Gender.GenderDescription; // Data field

                if (client0Db.KeyAccountManager.Gender.GenderId != 0)
                {
                    _ctx.Update(client0Db.KeyAccountManager.Gender);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    client0.KeyAccountManager.Gender.GenderId = client0Db.KeyAccountManager.Gender.GenderId;
                }
                client0.KeyAccountManager.Gender.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (client0?.KeyAccountManager?.Department != null && client0.KeyAccountManager.Department.IsDeleted)
            {
                _ctx.Department.Remove(client0Db.KeyAccountManager.Department);
            }
            else if (client0?.KeyAccountManager?.Department != null && client0.KeyAccountManager.Department.IsTainted)
            {
                // Check if id has changed
                if (client0Db.KeyAccountManager.Department?.DepartmentId != client0.KeyAccountManager.Department.DepartmentId && client0Db.KeyAccountManager.Department?.DepartmentId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // client0Db.KeyAccountManager.Department?.DepartmentId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                client0Db.KeyAccountManager.Department.DepartmentName = client0.KeyAccountManager.Department.DepartmentName; // Data field

                if (client0Db.KeyAccountManager.Department.DepartmentId != 0)
                {
                    _ctx.Update(client0Db.KeyAccountManager.Department);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    client0.KeyAccountManager.Department.DepartmentId = client0Db.KeyAccountManager.Department.DepartmentId;
                }
                client0.KeyAccountManager.Department.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

        }

    }
}
