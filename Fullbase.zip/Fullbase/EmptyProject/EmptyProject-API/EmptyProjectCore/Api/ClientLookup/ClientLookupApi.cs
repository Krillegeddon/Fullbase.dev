
using EmptyProjectCore.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace EmptyProjectCore.Api.ClientLookup
{

    public partial class ClientLookupFilterRequestExtraObject
    {
    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    public partial class ClientLookupFilterRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public ClientLookupFilterRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class ClientLookupFilterResponseExtraObject
    {
    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    public partial class ClientLookupFilterResponse : TransferBase
    {
        // Properties to be transfered

        public ClientLookupFilterRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ClientLookupFilterResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Request.Denormalize(Normalizer);

        }


    }

    public partial class ClientLookupSearchRequestExtraObject
    {
    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    public partial class ClientLookupSearchRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public ClientLookupSearchRequestExtraObject ExtraObject { get; set; }

        public string QuickSearch { get; set; }

        public NumberClause<int> ClientId { get; set; }

        public StringClause ClientName { get; set; }

        public NumberClause<int> KeyAccountManager_PersonId { get; set; }

        public StringClause KeyAccountManager_UserName { get; set; }

        public NumberClause<int> KeyAccountManager_Salary { get; set; }

        public NumberClause<int> KeyAccountManager_Gender_GenderId { get; set; }

        public StringClause KeyAccountManager_Gender_GenderDescription { get; set; }

        public NumberClause<int> KeyAccountManager_Department_DepartmentId { get; set; }

        public StringClause KeyAccountManager_Department_DepartmentName { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class ClientLookupSearchResponseExtraObject
    {
    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    public partial class ClientLookupSearchResponse : TransferBase
    {
        // Properties to be transfered

        public List<ClientDto> Clients { get; set; }

        public ClientLookupSearchRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ClientLookupSearchResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0; i < Clients?.Count; i++)
            {
                var x = Clients[i];
                var clientKey = "Client_" + x.ClientId;
                var possibleClient = normalizer.DtoObjects.Where(p => p.Key == clientKey).SingleOrDefault();
                if (possibleClient != null)
                    Clients[i] = (ClientDto) possibleClient.Object;
                else
                    Normalizer.NormalizeClient(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < Clients?.Count; i++)
            {
                this.Clients[i] = Normalizer.DenormalizeClient(Clients[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class ClientLookupDetailsRequestExtraObject
    {
    }

    /// <summary>
    /// Detail request, basically one item from the AugView Client, that user clicked after search was performed.
    /// </summary>
    public partial class ClientLookupDetailsRequest : TransferBase
    {
        // Properties to be transfered

        public ClientDto Client { get; set; }


        // Custom properties, not to be transfered
        public ClientLookupDetailsRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var clientKey = "Client_" + Client.ClientId;
                var possibleClient = normalizer.DtoObjects.Where(p => p.Key == clientKey).SingleOrDefault();
                if (possibleClient != null)
                    Client = (ClientDto)possibleClient.Object;
                else
                    Normalizer.NormalizeClient(Client);
            }

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Client = Normalizer.DenormalizeClient(Client);

        }


    }

    public partial class ClientLookupDetailsResponseExtraObject
    {
    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    public partial class ClientLookupDetailsResponse : TransferBase
    {
        // Properties to be transfered

        public ClientDto Client { get; set; }

        public ClientLookupDetailsRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ClientLookupDetailsResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var clientKey = "Client_" + Client.ClientId;
                var possibleClient = normalizer.DtoObjects.Where(p => p.Key == clientKey).SingleOrDefault();
                if (possibleClient != null)
                    Client = (ClientDto)possibleClient.Object;
                else
                    Normalizer.NormalizeClient(Client);
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Client = Normalizer.DenormalizeClient(Client);

            Request.Denormalize(Normalizer);

        }


    }

    /// <summary>
    /// Details response - internal DB representation of Details.
    /// </summary>
    public class ClientLookupDetailsResponseDb
    {
        // Properties in db class

        public Models.Client Client { get; set; }


        // Custom properties, not to be transfered

    }

}
