
using EmptyProjectCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmptyProjectCore.Api.Project_ClientExtended
{
    public class Project_ClientExtendedQueries
    {
        private ProjectContext _ctx { get; }

        public Project_ClientExtendedQueries(ProjectContext ctx)
        {
            _ctx = ctx;
        }



        /// <summary>
        /// Based on search criteria, returns the search results.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public Project_ClientExtendedSearchResponse GetSearch(Project_ClientExtendedSearchRequest request)
        {
            var retObj = new Project_ClientExtendedSearchResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();
            {
                var qProject_Client0 = _ctx.Project_Client
                    // Tree for  (Parent)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(request.QuickSearch))
                {
                    {
                        qProject_Client0 = qProject_Client0.Where(p =>
                            true /* nothing to search for, probably a Extended query? */
                        );
                    }
                }

                if (request.Project_ClientId.ExactMatch.HasValue)
                {
                    qProject_Client0 = qProject_Client0.Where(p =>
                                p.Project_ClientId == request.Project_ClientId.ExactMatch.Value  // Foreign key search
                    );
                }

                //Add custom code here...
                qPerson0 = qPerson0.Where(p => p.Department.DepartmentName == "Department A");
                
                
                retObj.Project_Clients = qProject_Client0.Select(p => retObj.Normalizer.LoadProject_Client(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on selected item from search, gets the detail information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public Project_ClientExtendedDetailsResponse GetDetails(Project_ClientExtendedDetailsRequest request)
        {
            
            var retObj = new Project_ClientExtendedDetailsResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            if (request.Project_Client.Project_ClientId > 0)
            {
                var qProject_Client0 = _ctx.Project_Client.Where(x => x.Project_ClientId == request.Project_Client.Project_ClientId)
                    // Tree for ProjectType (Parent)
                    .Include(p => p.Project)
                    .ThenInclude(p => p.ProjectType)
                    // Tree for KeyAccountManager (Parent)
                    .Include(p => p.Client)
                    .ThenInclude(p => p.KeyAccountManager)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Project_Client = retObj.Normalizer.LoadProject_Client(qProject_Client0);
            }
            else
            {
                retObj.Project_Client = new Project_ClientDto
                {
                    Project_ClientId = -1
                };
            }


            return retObj;
        }

        private Project_ClientExtendedDetailsResponseDb GetDetailsDb(Project_ClientExtendedDetailsRequest request)
        {
            
            var retObj = new Project_ClientExtendedDetailsResponseDb();

            {
                var qProject_Client0 = _ctx.Project_Client.Where(x => x.Project_ClientId == request.Project_Client.Project_ClientId)
                    // Tree for ProjectType (Parent)
                    .Include(p => p.Project)
                    .ThenInclude(p => p.ProjectType)
                    // Tree for KeyAccountManager (Parent)
                    .Include(p => p.Client)
                    .ThenInclude(p => p.KeyAccountManager)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Project_Client = qProject_Client0;
            }


            return retObj;
        }


        public void SaveDetails(Project_ClientExtendedDetailsResponse taintedResponse)
        {
            restart:
            var project_Client0Db = GetDetailsDb(taintedResponse.Request).Project_Client; // Get the same thing as request
            var project_Client0 = taintedResponse.Project_Client;


            if (project_Client0Db == null)
            {
                // No row in db = insert!
                var d = new EmptyProjectCore.Models.Project_Client();
                d.ProjectId = project_Client0.ProjectId;
                d.ClientId = project_Client0.ClientId;

                _ctx.Project_Client.Add(d);
                _ctx.SaveChanges();
                project_Client0.Project_ClientId = d.Project_ClientId;
                goto restart;
            }




            if (project_Client0 != null && project_Client0.IsDeleted)
            {
                _ctx.Project_Client.Remove(project_Client0Db);
            }
            else if (project_Client0 != null && project_Client0.IsTainted)
            {
                // Check if id has changed
                if (project_Client0Db?.Project_ClientId != project_Client0.Project_ClientId && project_Client0Db?.Project_ClientId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project_Client0Db?.Project_ClientId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                if (project_Client0 != null && project_Client0.Project != null)
                    project_Client0Db.ProjectId = project_Client0.Project.ProjectId; // Non-nullable parent - if null, we shall not update...
                if (project_Client0 != null && project_Client0.Client != null)
                    project_Client0Db.ClientId = project_Client0.Client.ClientId; // Non-nullable parent - if null, we shall not update...

                if (project_Client0Db.Project_ClientId != 0)
                {
                    _ctx.Update(project_Client0Db);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project_Client0.Project_ClientId = project_Client0Db.Project_ClientId;
                }
                project_Client0.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (project_Client0?.Project != null && project_Client0.Project.IsDeleted)
            {
                _ctx.Project.Remove(project_Client0Db.Project);
            }
            else if (project_Client0?.Project != null && project_Client0.Project.IsTainted)
            {
                // Check if id has changed
                if (project_Client0Db.Project?.ProjectId != project_Client0.Project.ProjectId && project_Client0Db.Project?.ProjectId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project_Client0Db.Project?.ProjectId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project_Client0Db.Project.ProjectName = project_Client0.Project.ProjectName; // Data field
                project_Client0Db.Project.IsProBono = project_Client0.Project.IsProBono; // Data field
                project_Client0Db.Project.Deadline = project_Client0.Project.Deadline; // Data field
                if (project_Client0.Project != null && project_Client0.Project.ProjectType != null)
                    project_Client0Db.Project.ProjectTypeId = project_Client0.Project.ProjectType.ProjectTypeId; // Non-nullable parent - if null, we shall not update...

                if (project_Client0Db.Project.ProjectId != 0)
                {
                    _ctx.Update(project_Client0Db.Project);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project_Client0.Project.ProjectId = project_Client0Db.Project.ProjectId;
                }
                project_Client0.Project.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (project_Client0?.Project?.ProjectType != null && project_Client0.Project.ProjectType.IsDeleted)
            {
                _ctx.ProjectType.Remove(project_Client0Db.Project.ProjectType);
            }
            else if (project_Client0?.Project?.ProjectType != null && project_Client0.Project.ProjectType.IsTainted)
            {
                // Check if id has changed
                if (project_Client0Db.Project.ProjectType?.ProjectTypeId != project_Client0.Project.ProjectType.ProjectTypeId && project_Client0Db.Project.ProjectType?.ProjectTypeId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project_Client0Db.Project.ProjectType?.ProjectTypeId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project_Client0Db.Project.ProjectType.ProjectTypeName = project_Client0.Project.ProjectType.ProjectTypeName; // Data field

                if (project_Client0Db.Project.ProjectType.ProjectTypeId != 0)
                {
                    _ctx.Update(project_Client0Db.Project.ProjectType);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project_Client0.Project.ProjectType.ProjectTypeId = project_Client0Db.Project.ProjectType.ProjectTypeId;
                }
                project_Client0.Project.ProjectType.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (project_Client0?.Client != null && project_Client0.Client.IsDeleted)
            {
                _ctx.Client.Remove(project_Client0Db.Client);
            }
            else if (project_Client0?.Client != null && project_Client0.Client.IsTainted)
            {
                // Check if id has changed
                if (project_Client0Db.Client?.ClientId != project_Client0.Client.ClientId && project_Client0Db.Client?.ClientId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project_Client0Db.Client?.ClientId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project_Client0Db.Client.ClientName = project_Client0.Client.ClientName; // Data field
                if (project_Client0.Client != null && project_Client0.Client.KeyAccountManager != null)
                    project_Client0Db.Client.PersonId = project_Client0.Client.KeyAccountManager.PersonId; // Non-nullable parent - if null, we shall not update...

                if (project_Client0Db.Client.ClientId != 0)
                {
                    _ctx.Update(project_Client0Db.Client);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project_Client0.Client.ClientId = project_Client0Db.Client.ClientId;
                }
                project_Client0.Client.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (project_Client0?.Client?.KeyAccountManager != null && project_Client0.Client.KeyAccountManager.IsDeleted)
            {
                _ctx.Person.Remove(project_Client0Db.Client.KeyAccountManager);
            }
            else if (project_Client0?.Client?.KeyAccountManager != null && project_Client0.Client.KeyAccountManager.IsTainted)
            {
                // Check if id has changed
                if (project_Client0Db.Client.KeyAccountManager?.PersonId != project_Client0.Client.KeyAccountManager.PersonId && project_Client0Db.Client.KeyAccountManager?.PersonId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project_Client0Db.Client.KeyAccountManager?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project_Client0Db.Client.KeyAccountManager.UserName = project_Client0.Client.KeyAccountManager.UserName; // Data field
                project_Client0Db.Client.KeyAccountManager.Salary = project_Client0.Client.KeyAccountManager.Salary; // Data field
                if (project_Client0.Client.KeyAccountManager != null && project_Client0.Client.KeyAccountManager.Department != null)
                    project_Client0Db.Client.KeyAccountManager.DepartmentId = project_Client0.Client.KeyAccountManager.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                if (project_Client0.Client.KeyAccountManager != null && project_Client0.Client.KeyAccountManager.Gender != null)
                    project_Client0Db.Client.KeyAccountManager.GenderId = project_Client0.Client.KeyAccountManager.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                project_Client0Db.Client.KeyAccountManager.ManagerId = project_Client0.Client.KeyAccountManager.Manager?.PersonId; // Nullable parent

                if (project_Client0Db.Client.KeyAccountManager.PersonId != 0)
                {
                    _ctx.Update(project_Client0Db.Client.KeyAccountManager);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project_Client0.Client.KeyAccountManager.PersonId = project_Client0Db.Client.KeyAccountManager.PersonId;
                }
                project_Client0.Client.KeyAccountManager.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

        }

    }
}
