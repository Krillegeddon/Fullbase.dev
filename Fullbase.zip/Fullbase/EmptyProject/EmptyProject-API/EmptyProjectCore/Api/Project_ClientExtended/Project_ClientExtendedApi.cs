
using EmptyProjectCore.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace EmptyProjectCore.Api.Project_ClientExtended
{

    public partial class Project_ClientExtendedFilterRequestExtraObject
    {
    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    public partial class Project_ClientExtendedFilterRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public Project_ClientExtendedFilterRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class Project_ClientExtendedFilterResponseExtraObject
    {
    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    public partial class Project_ClientExtendedFilterResponse : TransferBase
    {
        // Properties to be transfered

        public Project_ClientExtendedFilterRequest Request { get; set; }


        // Custom properties, not to be transfered
        public Project_ClientExtendedFilterResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Request.Denormalize(Normalizer);

        }


    }

    public partial class Project_ClientExtendedSearchRequestExtraObject
    {
    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    public partial class Project_ClientExtendedSearchRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public Project_ClientExtendedSearchRequestExtraObject ExtraObject { get; set; }

        public string QuickSearch { get; set; }

        public NumberClause<int> Project_ClientId { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class Project_ClientExtendedSearchResponseExtraObject
    {
    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    public partial class Project_ClientExtendedSearchResponse : TransferBase
    {
        // Properties to be transfered

        public List<Project_ClientDto> Project_Clients { get; set; }

        public Project_ClientExtendedSearchRequest Request { get; set; }


        // Custom properties, not to be transfered
        public Project_ClientExtendedSearchResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0; i < Project_Clients?.Count; i++)
            {
                var x = Project_Clients[i];
                var project_ClientKey = "Project_Client_" + x.Project_ClientId;
                var possibleProject_Client = normalizer.DtoObjects.Where(p => p.Key == project_ClientKey).SingleOrDefault();
                if (possibleProject_Client != null)
                    Project_Clients[i] = (Project_ClientDto) possibleProject_Client.Object;
                else
                    Normalizer.NormalizeProject_Client(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < Project_Clients?.Count; i++)
            {
                this.Project_Clients[i] = Normalizer.DenormalizeProject_Client(Project_Clients[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class Project_ClientExtendedDetailsRequestExtraObject
    {
    }

    /// <summary>
    /// Detail request, basically one item from the AugView Project_Client, that user clicked after search was performed.
    /// </summary>
    public partial class Project_ClientExtendedDetailsRequest : TransferBase
    {
        // Properties to be transfered

        public Project_ClientDto Project_Client { get; set; }


        // Custom properties, not to be transfered
        public Project_ClientExtendedDetailsRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var project_ClientKey = "Project_Client_" + Project_Client.Project_ClientId;
                var possibleProject_Client = normalizer.DtoObjects.Where(p => p.Key == project_ClientKey).SingleOrDefault();
                if (possibleProject_Client != null)
                    Project_Client = (Project_ClientDto)possibleProject_Client.Object;
                else
                    Normalizer.NormalizeProject_Client(Project_Client);
            }

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Project_Client = Normalizer.DenormalizeProject_Client(Project_Client);

        }


    }

    public partial class Project_ClientExtendedDetailsResponseExtraObject
    {
    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    public partial class Project_ClientExtendedDetailsResponse : TransferBase
    {
        // Properties to be transfered

        public Project_ClientDto Project_Client { get; set; }

        public Project_ClientExtendedDetailsRequest Request { get; set; }


        // Custom properties, not to be transfered
        public Project_ClientExtendedDetailsResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            {
                var project_ClientKey = "Project_Client_" + Project_Client.Project_ClientId;
                var possibleProject_Client = normalizer.DtoObjects.Where(p => p.Key == project_ClientKey).SingleOrDefault();
                if (possibleProject_Client != null)
                    Project_Client = (Project_ClientDto)possibleProject_Client.Object;
                else
                    Normalizer.NormalizeProject_Client(Project_Client);
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Project_Client = Normalizer.DenormalizeProject_Client(Project_Client);

            Request.Denormalize(Normalizer);

        }


    }

    /// <summary>
    /// Details response - internal DB representation of Details.
    /// </summary>
    public class Project_ClientExtendedDetailsResponseDb
    {
        // Properties in db class

        public Models.Project_Client Project_Client { get; set; }


        // Custom properties, not to be transfered

    }

}
