
using EmptyProjectCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmptyProjectCore.Api.PersonMini
{
    public class PersonMiniQueries
    {
        private ProjectContext _ctx { get; }

        public PersonMiniQueries(ProjectContext ctx)
        {
            _ctx = ctx;
        }


        /// <summary>
        /// Gets all data that is need to show the search criteria
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public PersonMiniFilterResponse GetFilter(PersonMiniFilterRequest request)
        {
            var retObj = new PersonMiniFilterResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            {
                var qDepartment0 = _ctx.Department
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Departments = qDepartment0.Select(p => retObj.Normalizer.LoadDepartment(p)).ToList();
            }
            {
                var qGender1 = _ctx.Gender
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Genders = qGender1.Select(p => retObj.Normalizer.LoadGender(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on search criteria, returns the search results.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public PersonMiniSearchResponse GetSearch(PersonMiniSearchRequest request)
        {
            var retObj = new PersonMiniSearchResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();
            {
                var qPerson0 = _ctx.Person
                    // Tree for Gender (Parent)
                    .Include(p => p.Gender)
                    // Tree for Department (Parent)
                    .Include(p => p.Department)
                    // Tree for Manager (Parent)
                    .Include(p => p.Manager)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(request.QuickSearch))
                {
                    {
                        qPerson0 = qPerson0.Where(p =>
                        p.UserName.ToLower().Contains(request.QuickSearch.ToLower()) ||
                        p.Gender.GenderDescription.ToLower().Contains(request.QuickSearch.ToLower()) ||
                        p.Department.DepartmentName.ToLower().Contains(request.QuickSearch.ToLower()) ||
                        p.Manager.UserName.ToLower().Contains(request.QuickSearch.ToLower())
                        );
                    }
                }

                if (request.PersonId.ExactMatch.HasValue)
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.PersonId == request.PersonId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.UserName.ExactMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.UserName == request.UserName.ExactMatch
                    );
                }

                if (request.Salary.ExactMatch.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Salary == request.Salary.ExactMatch.Value
                    );
                }

                if (request.Gender_GenderId.ExactMatch.HasValue)
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Gender.GenderId == request.Gender_GenderId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.Gender_GenderDescription.ExactMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Gender.GenderDescription == request.Gender_GenderDescription.ExactMatch
                    );
                }

                if (request.Department_DepartmentId.ExactMatch.HasValue)
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Department.DepartmentId == request.Department_DepartmentId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.Department_DepartmentName.ExactMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Department.DepartmentName == request.Department_DepartmentName.ExactMatch
                    );
                }

                if (request.Manager_PersonId.ExactMatch.HasValue)
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.PersonId == request.Manager_PersonId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.Manager_UserName.ExactMatch)) // One field, string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.UserName == request.Manager_UserName.ExactMatch
                    );
                }

                if (request.Manager_Salary.ExactMatch.HasValue) // One field, non-string
                {
                    qPerson0 = qPerson0.Where(p =>
                                p.Manager.Salary == request.Manager_Salary.ExactMatch.Value
                    );
                }

            qPerson0 = qPerson0.OrderBy(p => p.Department.DepartmentName);

                retObj.Persons = qPerson0.Select(p => retObj.Normalizer.LoadPerson(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on selected item from search, gets the detail information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public PersonMiniDetailsResponse GetDetails(PersonMiniDetailsRequest request)
        {
            
            var retObj = new PersonMiniDetailsResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            if (request.Person.PersonId > 0)
            {
                var qPerson0 = _ctx.Person.Where(x => x.PersonId == request.Person.PersonId)
                    // Tree for Gender (Parent)
                    .Include(p => p.Gender)
                    // Tree for Department (Parent)
                    .Include(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Manager)
                    .ThenInclude(p => p.Gender)
                    // Tree for Department (Parent)
                    .Include(p => p.Manager)
                    .ThenInclude(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Employees)
                    .ThenInclude(p => p.Gender)
                    // Tree for Department (Parent)
                    .Include(p => p.Employees)
                    .ThenInclude(p => p.Department)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Person = retObj.Normalizer.LoadPerson(qPerson0);
            }
            else
            {
                retObj.Person = new PersonDto
                {
                    PersonId = -1
                };
            }
            {
                var qGender1 = _ctx.Gender
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Genders = qGender1.Select(p => retObj.Normalizer.LoadGender(p)).ToList();
            }
            {
                var qDepartment2 = _ctx.Department
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Departments = qDepartment2.Select(p => retObj.Normalizer.LoadDepartment(p)).ToList();
            }


            return retObj;
        }

        private PersonMiniDetailsResponseDb GetDetailsDb(PersonMiniDetailsRequest request)
        {
            
            var retObj = new PersonMiniDetailsResponseDb();

            {
                var qPerson0 = _ctx.Person.Where(x => x.PersonId == request.Person.PersonId)
                    // Tree for Gender (Parent)
                    .Include(p => p.Gender)
                    // Tree for Department (Parent)
                    .Include(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Manager)
                    .ThenInclude(p => p.Gender)
                    // Tree for Department (Parent)
                    .Include(p => p.Manager)
                    .ThenInclude(p => p.Department)
                    // Tree for Gender (Parent)
                    .Include(p => p.Employees)
                    .ThenInclude(p => p.Gender)
                    // Tree for Department (Parent)
                    .Include(p => p.Employees)
                    .ThenInclude(p => p.Department)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Person = qPerson0;
            }
            {
                var qGender1 = _ctx.Gender
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Genders = qGender1;
            }
            {
                var qDepartment2 = _ctx.Department
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.Departments = qDepartment2;
            }


            return retObj;
        }


        public void SaveDetails(PersonMiniDetailsResponse taintedResponse)
        {
            restart:
            var person0Db = GetDetailsDb(taintedResponse.Request).Person; // Get the same thing as request
            var person0 = taintedResponse.Person;


            if (person0Db == null)
            {
                // No row in db = insert!
                var d = new EmptyProjectCore.Models.Person();
                d.UserName = person0.UserName;
                d.Salary = person0.Salary;
                d.DepartmentId = person0.DepartmentId;
                d.GenderId = person0.GenderId;
                d.ManagerId = person0.ManagerId;

                _ctx.Person.Add(d);
                _ctx.SaveChanges();
                person0.PersonId = d.PersonId;
                goto restart;
            }




            if (person0 != null && person0.IsDeleted)
            {
                _ctx.Person.Remove(person0Db);
            }
            else if (person0 != null && person0.IsTainted)
            {
                // Check if id has changed
                if (person0Db?.PersonId != person0.PersonId && person0Db?.PersonId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.UserName = person0.UserName; // Data field
                person0Db.Salary = person0.Salary; // Data field
                if (person0 != null && person0.Department != null)
                    person0Db.DepartmentId = person0.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                if (person0 != null && person0.Gender != null)
                    person0Db.GenderId = person0.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                person0Db.ManagerId = person0.Manager?.PersonId; // Nullable parent

                if (person0Db.PersonId != 0)
                {
                    _ctx.Update(person0Db);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.PersonId = person0Db.PersonId;
                }
                person0.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Gender != null && person0.Gender.IsDeleted)
            {
                _ctx.Gender.Remove(person0Db.Gender);
            }
            else if (person0?.Gender != null && person0.Gender.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Gender?.GenderId != person0.Gender.GenderId && person0Db.Gender?.GenderId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Gender?.GenderId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Gender.GenderDescription = person0.Gender.GenderDescription; // Data field

                if (person0Db.Gender.GenderId != 0)
                {
                    _ctx.Update(person0Db.Gender);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Gender.GenderId = person0Db.Gender.GenderId;
                }
                person0.Gender.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Department != null && person0.Department.IsDeleted)
            {
                _ctx.Department.Remove(person0Db.Department);
            }
            else if (person0?.Department != null && person0.Department.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Department?.DepartmentId != person0.Department.DepartmentId && person0Db.Department?.DepartmentId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Department?.DepartmentId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Department.DepartmentName = person0.Department.DepartmentName; // Data field

                if (person0Db.Department.DepartmentId != 0)
                {
                    _ctx.Update(person0Db.Department);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Department.DepartmentId = person0Db.Department.DepartmentId;
                }
                person0.Department.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Manager != null && person0.Manager.IsDeleted)
            {
                _ctx.Person.Remove(person0Db.Manager);
            }
            else if (person0?.Manager != null && person0.Manager.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Manager?.PersonId != person0.Manager.PersonId && person0Db.Manager?.PersonId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Manager?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Manager.UserName = person0.Manager.UserName; // Data field
                person0Db.Manager.Salary = person0.Manager.Salary; // Data field
                if (person0.Manager != null && person0.Manager.Department != null)
                    person0Db.Manager.DepartmentId = person0.Manager.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                if (person0.Manager != null && person0.Manager.Gender != null)
                    person0Db.Manager.GenderId = person0.Manager.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                person0Db.Manager.ManagerId = person0.Manager.Manager?.PersonId; // Nullable parent

                if (person0Db.Manager.PersonId != 0)
                {
                    _ctx.Update(person0Db.Manager);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Manager.PersonId = person0Db.Manager.PersonId;
                }
                person0.Manager.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Manager?.Gender != null && person0.Manager.Gender.IsDeleted)
            {
                _ctx.Gender.Remove(person0Db.Manager.Gender);
            }
            else if (person0?.Manager?.Gender != null && person0.Manager.Gender.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Manager.Gender?.GenderId != person0.Manager.Gender.GenderId && person0Db.Manager.Gender?.GenderId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Manager.Gender?.GenderId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Manager.Gender.GenderDescription = person0.Manager.Gender.GenderDescription; // Data field

                if (person0Db.Manager.Gender.GenderId != 0)
                {
                    _ctx.Update(person0Db.Manager.Gender);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Manager.Gender.GenderId = person0Db.Manager.Gender.GenderId;
                }
                person0.Manager.Gender.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (person0?.Manager?.Department != null && person0.Manager.Department.IsDeleted)
            {
                _ctx.Department.Remove(person0Db.Manager.Department);
            }
            else if (person0?.Manager?.Department != null && person0.Manager.Department.IsTainted)
            {
                // Check if id has changed
                if (person0Db.Manager.Department?.DepartmentId != person0.Manager.Department.DepartmentId && person0Db.Manager.Department?.DepartmentId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // person0Db.Manager.Department?.DepartmentId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                person0Db.Manager.Department.DepartmentName = person0.Manager.Department.DepartmentName; // Data field

                if (person0Db.Manager.Department.DepartmentId != 0)
                {
                    _ctx.Update(person0Db.Manager.Department);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    person0.Manager.Department.DepartmentId = person0Db.Manager.Department.DepartmentId;
                }
                person0.Manager.Department.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            // Before checking child
            if (person0 != null && person0.Employees != null)
            {
                foreach (var person1 in person0.Employees)
                {
                    var person1Db = person0Db.Employees.Where(p=>p.PersonId == person1.PersonId).SingleOrDefault();
                    if (person1Db == null && person1.IsDeleted != true)
                    {
                        person1Db = new EmptyProjectCore.Models.Person();
                        _ctx.Person.Add(person1Db);
                    }
                    // Above shall handle the fact that we have added a child

                    if (person1 != null && person1.IsDeleted)
                    {
                        _ctx.Person.Remove(person1Db);
                    }
                    else if (person1 != null && person1.IsTainted)
                    {
                        // Check if id has changed
                        if (person1Db?.PersonId != person1.PersonId && person1Db?.PersonId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // person1Db?.PersonId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        person1Db.UserName = person1.UserName; // Data field
                        person1Db.Salary = person1.Salary; // Data field
                        if (person1 != null && person1.Department != null)
                            person1Db.DepartmentId = person1.Department.DepartmentId; // Non-nullable parent - if null, we shall not update...
                        if (person1 != null && person1.Gender != null)
                            person1Db.GenderId = person1.Gender.GenderId; // Non-nullable parent - if null, we shall not update...
                        person1Db.ManagerId = person1.Manager?.PersonId; // Nullable parent

                        if (person1Db.PersonId != 0)
                        {
                            _ctx.Update(person1Db);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            person1.PersonId = person1Db.PersonId;
                        }
                        person1.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                    if (person1?.Gender != null && person1.Gender.IsDeleted)
                    {
                        _ctx.Gender.Remove(person1Db.Gender);
                    }
                    else if (person1?.Gender != null && person1.Gender.IsTainted)
                    {
                        // Check if id has changed
                        if (person1Db.Gender?.GenderId != person1.Gender.GenderId && person1Db.Gender?.GenderId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // person1Db.Gender?.GenderId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        person1Db.Gender.GenderDescription = person1.Gender.GenderDescription; // Data field

                        if (person1Db.Gender.GenderId != 0)
                        {
                            _ctx.Update(person1Db.Gender);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            person1.Gender.GenderId = person1Db.Gender.GenderId;
                        }
                        person1.Gender.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                    if (person1?.Department != null && person1.Department.IsDeleted)
                    {
                        _ctx.Department.Remove(person1Db.Department);
                    }
                    else if (person1?.Department != null && person1.Department.IsTainted)
                    {
                        // Check if id has changed
                        if (person1Db.Department?.DepartmentId != person1.Department.DepartmentId && person1Db.Department?.DepartmentId != 0)
                        {
                            // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                            // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                            // id=2 can be updated without this if-statment being matched.
                            // person1Db.Department?.DepartmentId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                            _ctx.SaveChanges();
                            goto restart;
                        }
                        person1Db.Department.DepartmentName = person1.Department.DepartmentName; // Data field

                        if (person1Db.Department.DepartmentId != 0)
                        {
                            _ctx.Update(person1Db.Department);
                        }
                        else
                        {
                            // Need to save now since we are inserting.
                            _ctx.SaveChanges();
                            person1.Department.DepartmentId = person1Db.Department.DepartmentId;
                        }
                        person1.Department.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
                    }

                }
            }

        }

    }
}
