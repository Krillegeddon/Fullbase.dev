
using EmptyProjectCore.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace EmptyProjectCore.Api.PersonMini
{

    public partial class PersonMiniFilterRequestExtraObject
    {
    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    public partial class PersonMiniFilterRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public PersonMiniFilterRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class PersonMiniFilterResponseExtraObject
    {
    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    public partial class PersonMiniFilterResponse : TransferBase
    {
        // Properties to be transfered

        public List<DepartmentDto> Departments { get; set; }

        public List<GenderDto> Genders { get; set; }

        public PersonMiniFilterRequest Request { get; set; }


        // Custom properties, not to be transfered
        public PersonMiniFilterResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0 ; i < Departments?.Count ; i++)
            {
                var x = Departments[i];
                var departmentKey = "Department_" + x.DepartmentId;
                var possibleDepartment = normalizer.DtoObjects.Where(p => p.Key == departmentKey).SingleOrDefault();
                if (possibleDepartment != null)
                    Departments[i] = (DepartmentDto) possibleDepartment.Object;
                else
                    Normalizer.NormalizeDepartment(x); ;
            }

            for (int i = 0 ; i < Genders?.Count ; i++)
            {
                var x = Genders[i];
                var genderKey = "Gender_" + x.GenderId;
                var possibleGender = normalizer.DtoObjects.Where(p => p.Key == genderKey).SingleOrDefault();
                if (possibleGender != null)
                    Genders[i] = (GenderDto) possibleGender.Object;
                else
                    Normalizer.NormalizeGender(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < Departments?.Count; i++)
            {
                this.Departments[i] = Normalizer.DenormalizeDepartment(Departments[i]);
            }

            for (int i = 0; i < Genders?.Count; i++)
            {
                this.Genders[i] = Normalizer.DenormalizeGender(Genders[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class PersonMiniSearchRequestExtraObject
    {
    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    public partial class PersonMiniSearchRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public PersonMiniSearchRequestExtraObject ExtraObject { get; set; }

        public string QuickSearch { get; set; }

        public IntClause PersonId { get; set; }

        public StringClause UserName { get; set; }

        public IntClause Salary { get; set; }

        public IntClause Gender_GenderId { get; set; }

        public StringClause Gender_GenderDescription { get; set; }

        public IntClause Department_DepartmentId { get; set; }

        public StringClause Department_DepartmentName { get; set; }

        public IntClause Manager_PersonId { get; set; }

        public StringClause Manager_UserName { get; set; }

        public IntClause Manager_Salary { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class PersonMiniSearchResponseExtraObject
    {
    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    public partial class PersonMiniSearchResponse : TransferBase
    {
        // Properties to be transfered

        public List<PersonDto> Persons { get; set; }

        public PersonMiniSearchRequest Request { get; set; }


        // Custom properties, not to be transfered
        public PersonMiniSearchResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0 ; i < Persons?.Count ; i++)
            {
                var x = Persons[i];
                var personKey = "Person_" + x.PersonId;
                var possiblePerson = normalizer.DtoObjects.Where(p => p.Key == personKey).SingleOrDefault();
                if (possiblePerson != null)
                    Persons[i] = (PersonDto) possiblePerson.Object;
                else
                    Normalizer.NormalizePerson(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < Persons?.Count; i++)
            {
                this.Persons[i] = Normalizer.DenormalizePerson(Persons[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class PersonMiniDetailsRequestExtraObject
    {
    }

    /// <summary>
    /// Detail request, basically one item from the AugView Person, that user clicked after search was performed.
    /// </summary>
    public partial class PersonMiniDetailsRequest : TransferBase
    {
        // Properties to be transfered

        public PersonDto Person { get; set; }


        // Custom properties, not to be transfered
        public PersonMiniDetailsRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            var personKey = "Person_" + Person.PersonId;
            var possiblePerson = normalizer.DtoObjects.Where(p => p.Key == personKey).SingleOrDefault();
            if (possiblePerson != null)
                Person = (PersonDto)possiblePerson.Object;
            else
                Normalizer.NormalizePerson(Person);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Person = Normalizer.DenormalizePerson(Person);

        }


    }

    public partial class PersonMiniDetailsResponseExtraObject
    {
    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    public partial class PersonMiniDetailsResponse : TransferBase
    {
        // Properties to be transfered

        public PersonDto Person { get; set; }

        public List<GenderDto> Genders { get; set; }

        public List<DepartmentDto> Departments { get; set; }

        public PersonMiniDetailsRequest Request { get; set; }


        // Custom properties, not to be transfered
        public PersonMiniDetailsResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            var personKey = "Person_" + Person.PersonId;
            var possiblePerson = normalizer.DtoObjects.Where(p => p.Key == personKey).SingleOrDefault();
            if (possiblePerson != null)
                Person = (PersonDto)possiblePerson.Object;
            else
                Normalizer.NormalizePerson(Person);

            for (int i = 0 ; i < Genders?.Count ; i++)
            {
                var x = Genders[i];
                var genderKey = "Gender_" + x.GenderId;
                var possibleGender = normalizer.DtoObjects.Where(p => p.Key == genderKey).SingleOrDefault();
                if (possibleGender != null)
                    Genders[i] = (GenderDto) possibleGender.Object;
                else
                    Normalizer.NormalizeGender(x); ;
            }

            for (int i = 0 ; i < Departments?.Count ; i++)
            {
                var x = Departments[i];
                var departmentKey = "Department_" + x.DepartmentId;
                var possibleDepartment = normalizer.DtoObjects.Where(p => p.Key == departmentKey).SingleOrDefault();
                if (possibleDepartment != null)
                    Departments[i] = (DepartmentDto) possibleDepartment.Object;
                else
                    Normalizer.NormalizeDepartment(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Person = Normalizer.DenormalizePerson(Person);

            for (int i = 0; i < Genders?.Count; i++)
            {
                this.Genders[i] = Normalizer.DenormalizeGender(Genders[i]);
            }

            for (int i = 0; i < Departments?.Count; i++)
            {
                this.Departments[i] = Normalizer.DenormalizeDepartment(Departments[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    /// <summary>
    /// Details response - internal DB representation of Details.
    /// </summary>
    public class PersonMiniDetailsResponseDb
    {
        // Properties in db class

        public Models.Person Person { get; set; }

        public List<Models.Gender> Genders { get; set; }

        public List<Models.Department> Departments { get; set; }


        // Custom properties, not to be transfered

    }

}
