
using EmptyProjectCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmptyProjectCore.Api.ProjectLookup
{
    public class ProjectLookupQueries
    {
        private ProjectContext _ctx { get; }

        public ProjectLookupQueries(ProjectContext ctx)
        {
            _ctx = ctx;
        }


        /// <summary>
        /// Gets all data that is need to show the search criteria
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ProjectLookupFilterResponse GetFilter(ProjectLookupFilterRequest request)
        {
            var retObj = new ProjectLookupFilterResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            {
                var qProjectType0 = _ctx.ProjectType
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.ProjectTypes = qProjectType0.Select(p => retObj.Normalizer.LoadProjectType(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on search criteria, returns the search results.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ProjectLookupSearchResponse GetSearch(ProjectLookupSearchRequest request)
        {
            var retObj = new ProjectLookupSearchResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();
            {
                var qProject0 = _ctx.Project
                    // Tree for ProjectType (Parent)
                    .Include(p => p.ProjectType)
                    .AsQueryable();

                if (!string.IsNullOrEmpty(request.QuickSearch))
                {
                    {
                        qProject0 = qProject0.Where(p =>
                        p.ProjectName.ToLower().Contains(request.QuickSearch.ToLower()) ||
                        p.ProjectType.ProjectTypeName.ToLower().Contains(request.QuickSearch.ToLower())
                        );
                    }
                }

                if (request.ProjectId.ExactMatch.HasValue)
                {
                    qProject0 = qProject0.Where(p =>
                                p.ProjectId == request.ProjectId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.ProjectName.ExactMatch)) // One field, string
                {
                    qProject0 = qProject0.Where(p =>
                                p.ProjectName == request.ProjectName.ExactMatch
                    );
                }

                if (request.IsProBono.ExactMatch.HasValue) // One field, non-string
                {
                    qProject0 = qProject0.Where(p =>
                                p.IsProBono == request.IsProBono.ExactMatch.Value
                    );
                }

                if (request.Deadline.ExactMatch.HasValue) // One field, non-string
                {
                    qProject0 = qProject0.Where(p =>
                                p.Deadline == request.Deadline.ExactMatch.Value
                    );
                }

                if (request.ProjectType_ProjectTypeId.ExactMatch.HasValue)
                {
                    qProject0 = qProject0.Where(p =>
                                p.ProjectType.ProjectTypeId == request.ProjectType_ProjectTypeId.ExactMatch.Value  // Foreign key search
                    );
                }

                if (!string.IsNullOrEmpty(request.ProjectType_ProjectTypeName.ExactMatch)) // One field, string
                {
                    qProject0 = qProject0.Where(p =>
                                p.ProjectType.ProjectTypeName == request.ProjectType_ProjectTypeName.ExactMatch
                    );
                }

                //Add custom code here...
                qPerson0 = qPerson0.Where(p => p.Department.DepartmentName == "Department A");
                
                
                retObj.Projects = qProject0.Select(p => retObj.Normalizer.LoadProject(p)).ToList();
            }


            return retObj;
        }


        /// <summary>
        /// Based on selected item from search, gets the detail information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ProjectLookupDetailsResponse GetDetails(ProjectLookupDetailsRequest request)
        {
            
            var retObj = new ProjectLookupDetailsResponse();
            retObj.Normalizer = new Normalizer();
            retObj.Normalizer.DtoObjects = new List<NormKey>();

            if (request.Project.ProjectId > 0)
            {
                var qProject0 = _ctx.Project.Where(x => x.ProjectId == request.Project.ProjectId)
                    // Tree for ProjectType (Parent)
                    .Include(p => p.ProjectType)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Project = retObj.Normalizer.LoadProject(qProject0);
            }
            else
            {
                retObj.Project = new ProjectDto
                {
                    ProjectId = -1
                };
            }
            {
                var qProjectType1 = _ctx.ProjectType
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.ProjectTypes = qProjectType1.Select(p => retObj.Normalizer.LoadProjectType(p)).ToList();
            }


            return retObj;
        }

        private ProjectLookupDetailsResponseDb GetDetailsDb(ProjectLookupDetailsRequest request)
        {
            
            var retObj = new ProjectLookupDetailsResponseDb();

            {
                var qProject0 = _ctx.Project.Where(x => x.ProjectId == request.Project.ProjectId)
                    // Tree for ProjectType (Parent)
                    .Include(p => p.ProjectType)
                    .FirstOrDefault();

                //Add custom code here...
                retObj.Project = qProject0;
            }
            {
                var qProjectType1 = _ctx.ProjectType
                    // Tree for  (Parent)
                      .ToList();

                //Add custom code here...
                retObj.ProjectTypes = qProjectType1;
            }


            return retObj;
        }


        public void SaveDetails(ProjectLookupDetailsResponse taintedResponse)
        {
            restart:
            var project0Db = GetDetailsDb(taintedResponse.Request).Project; // Get the same thing as request
            var project0 = taintedResponse.Project;


            if (project0Db == null)
            {
                // No row in db = insert!
                var d = new EmptyProjectCore.Models.Project();
                d.ProjectName = project0.ProjectName;
                d.IsProBono = project0.IsProBono;
                d.Deadline = project0.Deadline;
                d.ProjectTypeId = project0.ProjectTypeId;

                _ctx.Project.Add(d);
                _ctx.SaveChanges();
                project0.ProjectId = d.ProjectId;
                goto restart;
            }




            if (project0 != null && project0.IsDeleted)
            {
                _ctx.Project.Remove(project0Db);
            }
            else if (project0 != null && project0.IsTainted)
            {
                // Check if id has changed
                if (project0Db?.ProjectId != project0.ProjectId && project0Db?.ProjectId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project0Db?.ProjectId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project0Db.ProjectName = project0.ProjectName; // Data field
                project0Db.IsProBono = project0.IsProBono; // Data field
                project0Db.Deadline = project0.Deadline; // Data field
                if (project0 != null && project0.ProjectType != null)
                    project0Db.ProjectTypeId = project0.ProjectType.ProjectTypeId; // Non-nullable parent - if null, we shall not update...

                if (project0Db.ProjectId != 0)
                {
                    _ctx.Update(project0Db);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project0.ProjectId = project0Db.ProjectId;
                }
                project0.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

            if (project0?.ProjectType != null && project0.ProjectType.IsDeleted)
            {
                _ctx.ProjectType.Remove(project0Db.ProjectType);
            }
            else if (project0?.ProjectType != null && project0.ProjectType.IsTainted)
            {
                // Check if id has changed
                if (project0Db.ProjectType?.ProjectTypeId != project0.ProjectType.ProjectTypeId && project0Db.ProjectType?.ProjectTypeId != 0)
                {
                    // Oh, okay, our ref ID has been updated, and now we're on the child entity itself. I.e. you change the refId from id=1=user1 to id=2=user2,
                    // and we also have made changes to user2, then (INTERIM), save changes (so we use id=2) and reload + start over... than the information on
                    // id=2 can be updated without this if-statment being matched.
                    // project0Db.ProjectType?.ProjectTypeId != 0 means that if we have handled it with child-logic, we shall not save just yet...
                    _ctx.SaveChanges();
                    goto restart;
                }
                project0Db.ProjectType.ProjectTypeName = project0.ProjectType.ProjectTypeName; // Data field

                if (project0Db.ProjectType.ProjectTypeId != 0)
                {
                    _ctx.Update(project0Db.ProjectType);
                }
                else
                {
                    // Need to save now since we are inserting.
                    _ctx.SaveChanges();
                    project0.ProjectType.ProjectTypeId = project0Db.ProjectType.ProjectTypeId;
                }
                project0.ProjectType.IsTainted = false; // If same object occurs several time in the same structure - only update it once.
            }

        }

    }
}
