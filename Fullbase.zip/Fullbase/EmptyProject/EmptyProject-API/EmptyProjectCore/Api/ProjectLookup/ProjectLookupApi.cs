
using EmptyProjectCore.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace EmptyProjectCore.Api.ProjectLookup
{

    public partial class ProjectLookupFilterRequestExtraObject
    {
    }

    /// <summary>
    /// Filter request, to be sent to initiate filter queries, make it possible to add stuff from local storage.
    /// </summary>
    public partial class ProjectLookupFilterRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public ProjectLookupFilterRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class ProjectLookupFilterResponseExtraObject
    {
    }

    /// <summary>
    /// Filter response, i.e. data to be used to populate drop downs etc. in the filter view
    /// </summary>
    public partial class ProjectLookupFilterResponse : TransferBase
    {
        // Properties to be transfered

        public List<ProjectTypeDto> ProjectTypes { get; set; }

        public ProjectLookupFilterRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ProjectLookupFilterResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0 ; i < ProjectTypes?.Count ; i++)
            {
                var x = ProjectTypes[i];
                var projectTypeKey = "ProjectType_" + x.ProjectTypeId;
                var possibleProjectType = normalizer.DtoObjects.Where(p => p.Key == projectTypeKey).SingleOrDefault();
                if (possibleProjectType != null)
                    ProjectTypes[i] = (ProjectTypeDto) possibleProjectType.Object;
                else
                    Normalizer.NormalizeProjectType(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < ProjectTypes?.Count; i++)
            {
                this.ProjectTypes[i] = Normalizer.DenormalizeProjectType(ProjectTypes[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class ProjectLookupSearchRequestExtraObject
    {
    }

    /// <summary>
    /// Search request - when searching view Search, these props can be set to filter the result.
    /// </summary>
    public partial class ProjectLookupSearchRequest : TransferBase
    {
        // Properties to be transfered


        // Custom properties, not to be transfered
        public ProjectLookupSearchRequestExtraObject ExtraObject { get; set; }

        public string QuickSearch { get; set; }

        public IntClause ProjectId { get; set; }

        public StringClause ProjectName { get; set; }

        public BoolClause IsProBono { get; set; }

        public DateTimeClause Deadline { get; set; }

        public IntClause ProjectType_ProjectTypeId { get; set; }

        public StringClause ProjectType_ProjectTypeName { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

        }


    }

    public partial class ProjectLookupSearchResponseExtraObject
    {
    }

    /// <summary>
    /// Search response - a list of AugView Search, that matches the search request.
    /// </summary>
    public partial class ProjectLookupSearchResponse : TransferBase
    {
        // Properties to be transfered

        public List<ProjectDto> Projects { get; set; }

        public ProjectLookupSearchRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ProjectLookupSearchResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            for (int i = 0 ; i < Projects?.Count ; i++)
            {
                var x = Projects[i];
                var projectKey = "Project_" + x.ProjectId;
                var possibleProject = normalizer.DtoObjects.Where(p => p.Key == projectKey).SingleOrDefault();
                if (possibleProject != null)
                    Projects[i] = (ProjectDto) possibleProject.Object;
                else
                    Normalizer.NormalizeProject(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            for (int i = 0; i < Projects?.Count; i++)
            {
                this.Projects[i] = Normalizer.DenormalizeProject(Projects[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    public partial class ProjectLookupDetailsRequestExtraObject
    {
    }

    /// <summary>
    /// Detail request, basically one item from the AugView Project, that user clicked after search was performed.
    /// </summary>
    public partial class ProjectLookupDetailsRequest : TransferBase
    {
        // Properties to be transfered

        public ProjectDto Project { get; set; }


        // Custom properties, not to be transfered
        public ProjectLookupDetailsRequestExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            var projectKey = "Project_" + Project.ProjectId;
            var possibleProject = normalizer.DtoObjects.Where(p => p.Key == projectKey).SingleOrDefault();
            if (possibleProject != null)
                Project = (ProjectDto)possibleProject.Object;
            else
                Normalizer.NormalizeProject(Project);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Project = Normalizer.DenormalizeProject(Project);

        }


    }

    public partial class ProjectLookupDetailsResponseExtraObject
    {
    }

    /// <summary>
    /// Details response - the details of Details.
    /// </summary>
    public partial class ProjectLookupDetailsResponse : TransferBase
    {
        // Properties to be transfered

        public ProjectDto Project { get; set; }

        public List<ProjectTypeDto> ProjectTypes { get; set; }

        public ProjectLookupDetailsRequest Request { get; set; }


        // Custom properties, not to be transfered
        public ProjectLookupDetailsResponseExtraObject ExtraObject { get; set; }

        
        public void Normalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Normalize(normalizer);
        }

        public void Normalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

            // Data objects

            var projectKey = "Project_" + Project.ProjectId;
            var possibleProject = normalizer.DtoObjects.Where(p => p.Key == projectKey).SingleOrDefault();
            if (possibleProject != null)
                Project = (ProjectDto)possibleProject.Object;
            else
                Normalizer.NormalizeProject(Project);

            for (int i = 0 ; i < ProjectTypes?.Count ; i++)
            {
                var x = ProjectTypes[i];
                var projectTypeKey = "ProjectType_" + x.ProjectTypeId;
                var possibleProjectType = normalizer.DtoObjects.Where(p => p.Key == projectTypeKey).SingleOrDefault();
                if (possibleProjectType != null)
                    ProjectTypes[i] = (ProjectTypeDto) possibleProjectType.Object;
                else
                    Normalizer.NormalizeProjectType(x); ;
            }

            Request.Normalize(normalizer);

        }

        public void Denormalize()
        {
            var normalizer = new Normalizer
            {
                DtoObjects = new List<NormKey>()
            };
            Denormalize(normalizer);
        }

        public void Denormalize(Normalizer normalizer)
        {
            Normalizer = normalizer;

           // Data objects

            Project = Normalizer.DenormalizeProject(Project);

            for (int i = 0; i < ProjectTypes?.Count; i++)
            {
                this.ProjectTypes[i] = Normalizer.DenormalizeProjectType(ProjectTypes[i]);
            }

            Request.Denormalize(Normalizer);

        }


    }

    /// <summary>
    /// Details response - internal DB representation of Details.
    /// </summary>
    public class ProjectLookupDetailsResponseDb
    {
        // Properties in db class

        public Models.Project Project { get; set; }

        public List<Models.ProjectType> ProjectTypes { get; set; }


        // Custom properties, not to be transfered

    }

}
