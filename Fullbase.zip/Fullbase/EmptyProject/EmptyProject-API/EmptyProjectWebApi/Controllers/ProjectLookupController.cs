
using EmptyProjectCore.Api.ProjectLookup;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class ProjectLookupController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getprojectlookupfilter")]
        [Consumes("application/json")]
        public ProjectLookupFilterResponse GetProjectLookupFilter([FromBody] ProjectLookupFilterRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new ProjectLookupApi();
            return retObj.GetFilter(request);
        }



        [HttpPost]
        [Route("api/empty/getprojectlookupsearch")]
        [Consumes("application/json")]
        public ProjectLookupSearchResponse GetProjectLookupSearch([FromBody] ProjectLookupSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new ProjectLookupApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getprojectlookupdetails")]
        [Consumes("application/json")]
        public ProjectLookupDetailsResponse GetProjectLookupDetails([FromBody] ProjectLookupDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new ProjectLookupApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/saveprojectlookupdetails")]
        [Consumes("application/json")]
        public ProjectLookupDetailsResponse SaveProjectLookupDetails([FromBody] ProjectLookupDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new ProjectLookupApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
