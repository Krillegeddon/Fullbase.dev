
using EmptyProjectCore.Api.ProjectTypeLookup;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class ProjectTypeLookupController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getprojecttypelookupsearch")]
        [Consumes("application/json")]
        public ProjectTypeLookupSearchResponse GetProjectTypeLookupSearch([FromBody] ProjectTypeLookupSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new ProjectTypeLookupApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getprojecttypelookupdetails")]
        [Consumes("application/json")]
        public ProjectTypeLookupDetailsResponse GetProjectTypeLookupDetails([FromBody] ProjectTypeLookupDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new ProjectTypeLookupApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/saveprojecttypelookupdetails")]
        [Consumes("application/json")]
        public ProjectTypeLookupDetailsResponse SaveProjectTypeLookupDetails([FromBody] ProjectTypeLookupDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new ProjectTypeLookupApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
