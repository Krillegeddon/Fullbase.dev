
using EmptyProjectCore.Api.RoleLookup;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class RoleLookupController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getrolelookupsearch")]
        [Consumes("application/json")]
        public RoleLookupSearchResponse GetRoleLookupSearch([FromBody] RoleLookupSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new RoleLookupApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getrolelookupdetails")]
        [Consumes("application/json")]
        public RoleLookupDetailsResponse GetRoleLookupDetails([FromBody] RoleLookupDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new RoleLookupApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/saverolelookupdetails")]
        [Consumes("application/json")]
        public RoleLookupDetailsResponse SaveRoleLookupDetails([FromBody] RoleLookupDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new RoleLookupApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
