
using EmptyProjectCore.Api.Project;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class ProjectController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getprojectfilter")]
        [Consumes("application/json")]
        public ProjectFilterResponse GetProjectFilter([FromBody] ProjectFilterRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new ProjectApi();
            return retObj.GetFilter(request);
        }



        [HttpPost]
        [Route("api/empty/getprojectsearch")]
        [Consumes("application/json")]
        public ProjectSearchResponse GetProjectSearch([FromBody] ProjectSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new ProjectApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getprojectdetails")]
        [Consumes("application/json")]
        public ProjectDetailsResponse GetProjectDetails([FromBody] ProjectDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new ProjectApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/saveprojectdetails")]
        [Consumes("application/json")]
        public ProjectDetailsResponse SaveProjectDetails([FromBody] ProjectDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new ProjectApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
