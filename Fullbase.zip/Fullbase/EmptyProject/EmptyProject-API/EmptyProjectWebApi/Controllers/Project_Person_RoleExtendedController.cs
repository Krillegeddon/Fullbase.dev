
using EmptyProjectCore.Api.Project_Person_RoleExtended;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class Project_Person_RoleExtendedController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getproject_person_roleextendedsearch")]
        [Consumes("application/json")]
        public Project_Person_RoleExtendedSearchResponse GetProject_Person_RoleExtendedSearch([FromBody] Project_Person_RoleExtendedSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new Project_Person_RoleExtendedApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getproject_person_roleextendeddetails")]
        [Consumes("application/json")]
        public Project_Person_RoleExtendedDetailsResponse GetProject_Person_RoleExtendedDetails([FromBody] Project_Person_RoleExtendedDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new Project_Person_RoleExtendedApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/saveproject_person_roleextendeddetails")]
        [Consumes("application/json")]
        public Project_Person_RoleExtendedDetailsResponse SaveProject_Person_RoleExtendedDetails([FromBody] Project_Person_RoleExtendedDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new Project_Person_RoleExtendedApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
