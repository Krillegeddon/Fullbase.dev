
using EmptyProjectCore.Api.GenderLookup;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class GenderLookupController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getgenderlookupsearch")]
        [Consumes("application/json")]
        public GenderLookupSearchResponse GetGenderLookupSearch([FromBody] GenderLookupSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new GenderLookupApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getgenderlookupdetails")]
        [Consumes("application/json")]
        public GenderLookupDetailsResponse GetGenderLookupDetails([FromBody] GenderLookupDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new GenderLookupApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/savegenderlookupdetails")]
        [Consumes("application/json")]
        public GenderLookupDetailsResponse SaveGenderLookupDetails([FromBody] GenderLookupDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new GenderLookupApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
