
using EmptyProjectCore.Api.DepartmentLookup;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class DepartmentLookupController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getdepartmentlookupsearch")]
        [Consumes("application/json")]
        public DepartmentLookupSearchResponse GetDepartmentLookupSearch([FromBody] DepartmentLookupSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new DepartmentLookupApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getdepartmentlookupdetails")]
        [Consumes("application/json")]
        public DepartmentLookupDetailsResponse GetDepartmentLookupDetails([FromBody] DepartmentLookupDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new DepartmentLookupApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/savedepartmentlookupdetails")]
        [Consumes("application/json")]
        public DepartmentLookupDetailsResponse SaveDepartmentLookupDetails([FromBody] DepartmentLookupDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new DepartmentLookupApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
