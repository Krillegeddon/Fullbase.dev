
using EmptyProjectCore.Api.ClientLookup;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class ClientLookupController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getclientlookupsearch")]
        [Consumes("application/json")]
        public ClientLookupSearchResponse GetClientLookupSearch([FromBody] ClientLookupSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new ClientLookupApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getclientlookupdetails")]
        [Consumes("application/json")]
        public ClientLookupDetailsResponse GetClientLookupDetails([FromBody] ClientLookupDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new ClientLookupApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/saveclientlookupdetails")]
        [Consumes("application/json")]
        public ClientLookupDetailsResponse SaveClientLookupDetails([FromBody] ClientLookupDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new ClientLookupApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
