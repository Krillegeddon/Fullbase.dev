
using EmptyProjectCore.Api.Client;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class ClientController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getclientsearch")]
        [Consumes("application/json")]
        public ClientSearchResponse GetClientSearch([FromBody] ClientSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new ClientApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getclientdetails")]
        [Consumes("application/json")]
        public ClientDetailsResponse GetClientDetails([FromBody] ClientDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new ClientApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/saveclientdetails")]
        [Consumes("application/json")]
        public ClientDetailsResponse SaveClientDetails([FromBody] ClientDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new ClientApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
