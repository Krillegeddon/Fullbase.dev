
using EmptyProjectCore.Api.PersonMini;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class PersonMiniController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getpersonminifilter")]
        [Consumes("application/json")]
        public PersonMiniFilterResponse GetPersonMiniFilter([FromBody] PersonMiniFilterRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new PersonMiniApi();
            return retObj.GetFilter(request);
        }



        [HttpPost]
        [Route("api/empty/getpersonminisearch")]
        [Consumes("application/json")]
        public PersonMiniSearchResponse GetPersonMiniSearch([FromBody] PersonMiniSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new PersonMiniApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getpersonminidetails")]
        [Consumes("application/json")]
        public PersonMiniDetailsResponse GetPersonMiniDetails([FromBody] PersonMiniDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new PersonMiniApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/savepersonminidetails")]
        [Consumes("application/json")]
        public PersonMiniDetailsResponse SavePersonMiniDetails([FromBody] PersonMiniDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new PersonMiniApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
