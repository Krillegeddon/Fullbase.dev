
using EmptyProjectCore.Api.Person;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class PersonController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getpersonfilter")]
        [Consumes("application/json")]
        public PersonFilterResponse GetPersonFilter([FromBody] PersonFilterRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new PersonApi();
            return retObj.GetFilter(request);
        }



        [HttpPost]
        [Route("api/empty/getpersonsearch")]
        [Consumes("application/json")]
        public PersonSearchResponse GetPersonSearch([FromBody] PersonSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new PersonApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getpersondetails")]
        [Consumes("application/json")]
        public PersonDetailsResponse GetPersonDetails([FromBody] PersonDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new PersonApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/savepersondetails")]
        [Consumes("application/json")]
        public PersonDetailsResponse SavePersonDetails([FromBody] PersonDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new PersonApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
