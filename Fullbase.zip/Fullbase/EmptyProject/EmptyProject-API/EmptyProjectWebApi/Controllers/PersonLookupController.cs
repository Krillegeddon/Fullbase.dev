
using EmptyProjectCore.Api.PersonLookup;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class PersonLookupController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getpersonlookupfilter")]
        [Consumes("application/json")]
        public PersonLookupFilterResponse GetPersonLookupFilter([FromBody] PersonLookupFilterRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new PersonLookupApi();
            return retObj.GetFilter(request);
        }



        [HttpPost]
        [Route("api/empty/getpersonlookupsearch")]
        [Consumes("application/json")]
        public PersonLookupSearchResponse GetPersonLookupSearch([FromBody] PersonLookupSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new PersonLookupApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getpersonlookupdetails")]
        [Consumes("application/json")]
        public PersonLookupDetailsResponse GetPersonLookupDetails([FromBody] PersonLookupDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new PersonLookupApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/savepersonlookupdetails")]
        [Consumes("application/json")]
        public PersonLookupDetailsResponse SavePersonLookupDetails([FromBody] PersonLookupDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new PersonLookupApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
