
using EmptyProjectCore.Api.Project_ClientExtended;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class Project_ClientExtendedController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getproject_clientextendedsearch")]
        [Consumes("application/json")]
        public Project_ClientExtendedSearchResponse GetProject_ClientExtendedSearch([FromBody] Project_ClientExtendedSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new Project_ClientExtendedApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getproject_clientextendeddetails")]
        [Consumes("application/json")]
        public Project_ClientExtendedDetailsResponse GetProject_ClientExtendedDetails([FromBody] Project_ClientExtendedDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new Project_ClientExtendedApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/saveproject_clientextendeddetails")]
        [Consumes("application/json")]
        public Project_ClientExtendedDetailsResponse SaveProject_ClientExtendedDetails([FromBody] Project_ClientExtendedDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new Project_ClientExtendedApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
