
using EmptyProjectCore.Api.PersonLookupForManager;
using Microsoft.AspNetCore.Mvc;
using EmptyProjectCore.Utils;

namespace EmptyProjectWebApi.Controllers
{
    /// <summary>
    /// Automatically generarated by Fullbase, all edits will be lost upon regeneration.
    /// </summary>
    [ApiController]
    public class PersonLookupForManagerController : ControllerBase
    {

        [HttpPost]
        [Route("api/empty/getpersonlookupformanagersearch")]
        [Consumes("application/json")]
        public PersonLookupForManagerSearchResponse GetPersonLookupForManagerSearch([FromBody] PersonLookupForManagerSearchRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new PersonLookupForManagerApi();
            return retObj.GetSearch(request);
        }



        [HttpPost]
        [Route("api/empty/getpersonlookupformanagerdetails")]
        [Consumes("application/json")]
        public PersonLookupForManagerDetailsResponse GetPersonLookupForManagerDetails([FromBody] PersonLookupForManagerDetailsRequest request)
        {
            AuthHandler.CheckRequest(request.UserAuthentication);
            var retObj = new PersonLookupForManagerApi();
            return retObj.GetDetails(request);
        }



        [HttpPost]
        [Route("api/empty/savepersonlookupformanagerdetails")]
        [Consumes("application/json")]
        public PersonLookupForManagerDetailsResponse SavePersonLookupForManagerDetails([FromBody] PersonLookupForManagerDetailsResponse taintedResponse)
        {
            AuthHandler.CheckRequest(taintedResponse.UserAuthentication);
            var retObj = new PersonLookupForManagerApi();
            return retObj.SaveDetails(taintedResponse);
        }

    }
}
