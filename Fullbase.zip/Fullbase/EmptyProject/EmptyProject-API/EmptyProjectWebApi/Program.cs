using EmptyProjectCore.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmptyProjectWebApi
{

    /*
    Scaffold-DbContext "Data Source=DESKTOP-E08JPQ0;Initial Catalog=EmptyProject;Integrated Security=True;" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models\Database -Tables ProjectClient,ProjectPersonRole,Role,Department,Client,ProjectType,Person,Project,ViewProjectAux,ViewPersonAux -Context DummyContext -Force
     */


    public class Program
    {
        public static void Main(string[] args)
        {
            ProjectContext.QueryString = "Data Source=DESKTOP-E08JPQ0;Initial Catalog=EmptyProject;Integrated Security=True;";
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
