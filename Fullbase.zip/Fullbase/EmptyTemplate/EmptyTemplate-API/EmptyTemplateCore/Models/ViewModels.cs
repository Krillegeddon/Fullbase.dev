
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EmptyTemplateCore.Utils;
using EmptyTemplateCore.Models;

namespace EmptyTemplateCore.Models
{
    public class DtoBase
    {
        public bool IsDeleted { get; set; }
        public bool IsTainted { get; set; }
        public virtual string _myName { get; }
    }

    public class IntClause
    {
        public int? ExactMatch { get; set; }
        public int? MoreThan { get; set; }
        public int? LessThan { get; set; }
        //public List<int> AnyOf { get; set; }
    }

    public class DateTimeClause
    {
        public DateTime? ExactMatch { get; set; }
        public DateTime? MoreThan { get; set; }
        public DateTime? LessThan { get; set; }
    }

    public class StringClause
    {
        public string ExactMatch { get; set; }
        public string ContainsMatch { get; set; }
        public string StartsWithMatch { get; set; }
        //public List<string> AnyOf { get; set; }
    }

    public class BoolClause
    {
        public bool? ExactMatch { get; set; }
    }

    public class TransferBase
    {
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public string StackTrace { get; set; }
        public Normalizer Normalizer { get; set; }
        public UserAuthentication UserAuthentication { get; set; }
    }

    public class NormKey
    {
        public string Key { get; set; }
        public object Object { get; set; }
        public string Jansson { get; set; }
        public bool IsDenormalized { get; set; }
    }

    public class Normalizer
    {
        public List<NormKey> DtoObjects { get; set; }

        public void CastDtoObjects(List<NormKey> dtoObjects)
        {
            foreach (var v in dtoObjects)
            {
                var k = v.Key;
                var s = k.Split('_');
                var s2 = new string[s.Length - 1];
                for (int i = 0; i < s.Length - 1; i++)
                {
                    s2[i] = s[i];
                }
                var t = string.Join('_', s2);

                v.Jansson = null;
            }
        }

        /* ***   Normalizers.cs   *** */


    } // End normalizers

        // DtoClasses.cs


} // End namespace
