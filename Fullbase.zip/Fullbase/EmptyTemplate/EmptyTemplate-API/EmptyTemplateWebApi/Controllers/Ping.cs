using EmptyTemplateCore.Api.ProjectLookup;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EmptyTemplateWebApi.Controllers
{
    [ApiController]
    public class Ping : ControllerBase
    {
        // GET: api/<ValuesController>
        [HttpGet]
        [Route("api/empty/ping")]
        public string GetPing()
        {
            return "Jajjemen";
        }
    }
}
