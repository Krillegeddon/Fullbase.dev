using EmptyTemplateCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmptyTemplateWebApi.Controllers
{
    public class AuthHandler
    {
        public static void CheckRequest(UserAuthentication auth)
        {
            if ("myVerifyToken" != "myVerifyToken")
            {
                throw new Exception("An exception that makes senese...");
            }
        }
    }
}
