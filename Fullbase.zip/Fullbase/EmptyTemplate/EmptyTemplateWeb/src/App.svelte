<script lang="ts">
	import AppDemo from "./AppDemo.svelte";
	import { fetchers, userAuthentication } from "./WebApi";

	userAuthentication.userId = 1;
	userAuthentication.firstName = "Christian";
	userAuthentication.lastName = "Jansson";
	userAuthentication.isAdmin = true;
	userAuthentication.token = "tbd";

	fetchers.ApiBaseUrl = "https://localhost:44326/";
</script>

<div>
	{userAuthentication.firstName}
	{userAuthentication.lastName} ({userAuthentication.userId})&nbsp;&nbsp;&nbsp;
	<input type="checkbox" bind:checked={userAuthentication.isDefault} /> Default&nbsp;&nbsp;
	<input type="checkbox" bind:checked={userAuthentication.isAdmin} /> Admin&nbsp;&nbsp;
	<input type="checkbox" bind:checked={userAuthentication.isGuest} /> Guest
</div>

<AppDemo />
