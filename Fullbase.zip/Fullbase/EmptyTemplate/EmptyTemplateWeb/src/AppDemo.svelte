
<script lang="ts">


    import Tabs from "./Components/Tabs.svelte";

    let tabs = [];
    let activeTab: string = tabs[0];
</script>
<svelte:head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="/demo.min.css" />
</svelte:head>

<Tabs bind:activeTab {tabs} />



