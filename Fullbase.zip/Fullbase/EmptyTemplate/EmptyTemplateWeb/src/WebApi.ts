import { UserAuthentication } from "./UserAuthentication";

export class TransferBase {
    isSuccess: boolean;
    errorMessage: string;
    stackTrace: string;

    // Properties for normalization/denormalization
    normalizer: Normalizer;
    userAuthentication: UserAuthentication
}


export class DtoBase {
    isDeleted: boolean;
    isTainted: boolean;
    myKey: string;
}

export class IntClause {
        exactMatch?: number;
        moreThan?: number;
        lessThan?: number;
        //anyOf: Array<number>;
}

export class DateTimeClause {
        exactMatch?: Date;
        moreThan?: Date;
        lessThan?: Date;
        //anyOf: Array<number>;
}


export class StringClause {
        exactMatch?: string;
        containsMatch?: string;
        startsWithMatch?: string;
        //anyOf: Array<string>;
}

export class BoolClause {
        exactMatch?: boolean;
}

export class KeyValuePair {
    key: string;
    value: any;
}

// Assumes that server sends datetime on UTC format
function GetLocalFromUtc(dateinX) {
    var datein = dateinX.toString().replace("Z", ""); // Sometimes, newtonsoft adds a Z at the end and sometimes not...
    var dateRaw = new Date(datein);
    dateRaw = new Date(Date.UTC(
        dateRaw.getFullYear(),
        dateRaw.getMonth(),
        dateRaw.getDate(),
        dateRaw.getHours(),
        dateRaw.getMinutes(),
        dateRaw.getSeconds(),
    ));
    return dateRaw;
}


export class Dictionary {
    kvps: Array<KeyValuePair>;

    containsKey(key: string): boolean {
        if (!this.kvps)
            this.kvps = new Array<KeyValuePair>();

        for (var i = 0; i < this.kvps.length; i++) {
            if (this.kvps[i].key == key) {
                return true;
            }
        }
        return false;
    }

    add(key: string, value: any) {
        if (!this.kvps)
            this.kvps = new Array<KeyValuePair>();

        for (var i = 0; i < this.kvps.length; i++) {
            if (this.kvps[i].key == key) {
                this.kvps[i].value = value;
            }
        }
        var kvp = new KeyValuePair();
        kvp.key = key;
        kvp.value = value;
        this.kvps.push(kvp);
    }

    get(key: string): any {
        if (!this.kvps)
            this.kvps = new Array<KeyValuePair>();

        for (var i = 0; i < this.kvps.length; i++) {
            if (this.kvps[i].key == key) {
                return this.kvps[i].value;
            }
        }
        return null;
    }
}








    export class NormKey {
        key: string;
        object: any;
        jansson: string;
        isDenormalized: boolean;
        isNormalized: boolean;
    }

    export class Normalizer {
        dtoObjects: Array<NormKey>;
        iscasted: boolean;

        constructor() {
            this.dtoObjects = new Array<NormKey>();
            this.iscasted = false;
        }

        CastDtoObjects(dtoObjects: Array<NormKey>) {
        if (this.iscasted)
            return;
        this.iscasted = true;
            for (var i = 0; i<dtoObjects.length ; i++) {
                //console.log(dtoObjects[i]);
                var v = dtoObjects[i];
            var ttemp = v.key;
            var sp = ttemp.split("_");
            var idx = "_" + sp[sp.length - 1];
            var t = ttemp.replace(idx, "");

                v.jansson = null;
            }
        }

        /* ***   Normalizers.ts   *** */


    } // End normalizers

        // DtoClasses.cs



export class Fetchers {
    ApiBaseUrl: string = "https://localhost:44326/";

    IsControlDown: boolean = false;
    DebugMessages: Array<string>;

    Debug(name: string) {
        if (!this.IsControlDown) return;
        console.log("DEBUG: " + name);
        if (!this.DebugMessages) this.DebugMessages = new Array<string>();
        this.DebugMessages.push(name);
        //setTimeout("this.DebugDone", 100);
        var that = this;
        setTimeout(function () {
            that.DebugDone();
        }, 20);
    }

    DebugDone() {
        if (!this.DebugMessages) return;
        var s: string = "";
        for (var i = 0; i < this.DebugMessages.length; i++) {
            s += this.DebugMessages[i] + " - ";
        }
        this.DebugMessages = null;
        console.log("Tutti: " + s);
        navigator.clipboard.writeText(s);
    }

    async CallRestPost(method: any, obj: any) {
        var url = this.ApiBaseUrl + method;

        const f = await fetch(url, {
            method: 'POST',
            body: JSON.stringify(obj),
            headers: {
                'Content-Type': 'application/json; charset=utf-8'
            }
        });

        let r = await f.json();
        return r;
    }



} // end fetchers class

export const fetchers = new Fetchers();
export const userAuthentication = new UserAuthentication();
