﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FullbaseTemplateCore.Models
{
    public class ProjectContext
    {
        public static string QueryString { get; set; }
    }
}
