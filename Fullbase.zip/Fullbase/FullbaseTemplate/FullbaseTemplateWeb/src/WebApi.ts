import { UserAuthentication } from "./UserAuthentication";

export const userAuthentication = new UserAuthentication();
