
<script lang="ts">
    import ProjectDemo from "./Demo/Project/Pages/ProjectDemo.svelte";
        import PersonLookupDemo from "./Demo/PersonLookup/Pages/PersonLookupDemo.svelte";
        import RoleLookupDemo from "./Demo/RoleLookup/Pages/RoleLookupDemo.svelte";
        import ProjectTypeLookupDemo from "./Demo/ProjectTypeLookup/Pages/ProjectTypeLookupDemo.svelte";
        import GenderLookupDemo from "./Demo/GenderLookup/Pages/GenderLookupDemo.svelte";
        import DepartmentLookupDemo from "./Demo/DepartmentLookup/Pages/DepartmentLookupDemo.svelte";
        import ClientLookupDemo from "./Demo/ClientLookup/Pages/ClientLookupDemo.svelte";
        import ProjectLookupDemo from "./Demo/ProjectLookup/Pages/ProjectLookupDemo.svelte";
        import PersonExpansionDemo from "./Demo/PersonExpansion/Pages/PersonExpansionDemo.svelte";

    import Tabs from "./Components/Tabs.svelte";

    let tabs = ["Project", "PersonLookup", "RoleLookup", "ProjectTypeLookup", "GenderLookup", "DepartmentLookup", "ClientLookup", "ProjectLookup", "PersonExpansion"];
    let activeTab: string = tabs[0];
</script>

<Tabs bind:activeTab {tabs} />


{#if activeTab == "Project"}
    <ProjectDemo  isModal={false} />
{/if}



{#if activeTab == "PersonLookup"}
    <PersonLookupDemo  isModal={false} />
{/if}



{#if activeTab == "RoleLookup"}
    <RoleLookupDemo  isModal={false} />
{/if}



{#if activeTab == "ProjectTypeLookup"}
    <ProjectTypeLookupDemo  isModal={false} />
{/if}



{#if activeTab == "GenderLookup"}
    <GenderLookupDemo  isModal={false} />
{/if}



{#if activeTab == "DepartmentLookup"}
    <DepartmentLookupDemo  isModal={false} />
{/if}



{#if activeTab == "ClientLookup"}
    <ClientLookupDemo  isModal={false} />
{/if}



{#if activeTab == "ProjectLookup"}
    <ProjectLookupDemo  isModal={false} />
{/if}



{#if activeTab == "PersonExpansion"}
    <PersonExpansionDemo  isModal={false} />
{/if}


