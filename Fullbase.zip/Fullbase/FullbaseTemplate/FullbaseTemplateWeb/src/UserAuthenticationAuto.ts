export class UserAuthenticationAuto {
    isDefault: boolean;
    isAdmin: boolean;
    isGuest: boolean;
}